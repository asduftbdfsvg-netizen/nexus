import AuthForm from "@/components/AuthForm";

export default async function ResetPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  if (!token) return <AuthForm mode="forgot" />;
  return <AuthForm mode="reset" token={token} />;
}
