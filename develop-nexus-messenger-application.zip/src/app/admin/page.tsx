import { notFound, redirect } from "next/navigation";
import AdminPanel from "@/components/AdminPanel";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

// Server-side access check: only accounts with the admin role can even receive the panel.
// Every /api/admin/* endpoint re-checks the role independently.
export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") notFound();
  return <AdminPanel adminName={user.displayName} adminId={user.id} />;
}
