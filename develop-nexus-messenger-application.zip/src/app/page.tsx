import { redirect } from "next/navigation";
import Messenger from "@/components/Messenger";
import { getCurrentUser } from "@/lib/auth";
import { selfDTO } from "@/lib/chat";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return <Messenger initialMe={selfDTO(user)} />;
}
