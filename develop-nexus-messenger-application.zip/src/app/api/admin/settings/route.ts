import { db } from "@/db";
import { platformSettings } from "@/db/schema";
import { ApiError, readJson, route, str } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getSettings, logAdmin } from "@/lib/platform";

export const GET = route(async () => {
  await requireAdmin();
  return { settings: await getSettings() };
});

function intIn(v: unknown, name: string, min: number, max: number) {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new ApiError(400, `«${name}»: число от ${min} до ${max}`);
  return String(n);
}

export const PUT = route(async (req) => {
  const admin = await requireAdmin();
  const body = await readJson(req);
  const next: Record<string, string> = {};
  if (body.rules !== undefined) next.rules = str(body.rules, "Правила", { min: 10, max: 5000 });
  if (body.registrationOpen !== undefined) next.registrationOpen = body.registrationOpen === true || body.registrationOpen === "true" ? "true" : "false";
  if (body.maxUploadMb !== undefined) next.maxUploadMb = intIn(body.maxUploadMb, "Лимит файла, МБ", 1, 200);
  if (body.maxGroupMembers !== undefined) next.maxGroupMembers = intIn(body.maxGroupMembers, "Участников в группе", 2, 1000);
  if (body.warningsBeforeBan !== undefined) next.warningsBeforeBan = intIn(body.warningsBeforeBan, "Предупреждений до бана", 1, 20);
  for (const [key, value] of Object.entries(next)) {
    await db
      .insert(platformSettings)
      .values({ key, value })
      .onConflictDoUpdate({ target: platformSettings.key, set: { value, updatedAt: new Date() } });
  }
  await logAdmin(admin.id, "update_settings", "settings", "", Object.keys(next).join(", "));
  return { settings: await getSettings() };
});
