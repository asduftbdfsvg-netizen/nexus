import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { adminLogs, users } from "@/db/schema";
import { route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";

export const GET = route(async () => {
  await requireAdmin();
  const rows = await db
    .select({ id: adminLogs.id, action: adminLogs.action, targetType: adminLogs.targetType, targetId: adminLogs.targetId, details: adminLogs.details, createdAt: adminLogs.createdAt, admin: users.username })
    .from(adminLogs)
    .leftJoin(users, eq(users.id, adminLogs.adminId))
    .orderBy(desc(adminLogs.createdAt))
    .limit(300);
  return { logs: rows };
});
