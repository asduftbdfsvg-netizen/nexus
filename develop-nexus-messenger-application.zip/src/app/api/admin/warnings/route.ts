import { desc, eq, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db } from "@/db";
import { sessions, users, warnings } from "@/db/schema";
import { ApiError, readJson, route, str, uuid } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { notify } from "@/lib/chat";
import { publish } from "@/lib/events";
import { getSetting, logAdmin } from "@/lib/platform";

export const GET = route(async () => {
  await requireAdmin();
  const target = alias(users, "target");
  const issuer = alias(users, "issuer");
  const rows = await db
    .select({ id: warnings.id, reason: warnings.reason, createdAt: warnings.createdAt, user: target.username, userId: target.id, issuedBy: issuer.username })
    .from(warnings)
    .leftJoin(target, eq(target.id, warnings.userId))
    .leftJoin(issuer, eq(issuer.id, warnings.issuedBy))
    .orderBy(desc(warnings.createdAt))
    .limit(200);
  return { warnings: rows };
});

export const POST = route(async (req) => {
  const admin = await requireAdmin();
  const body = await readJson(req);
  const userId = uuid(body.userId, "userId");
  const reason = str(body.reason, "Причина", { min: 3, max: 300 });
  const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!target) throw new ApiError(404, "Пользователь не найден");
  if (target.role === "admin") throw new ApiError(400, "Нельзя выдать предупреждение администратору");
  await db.insert(warnings).values({ userId, issuedBy: admin.id, reason });
  await notify(userId, { type: "warning", title: "Предупреждение от администрации", body: reason });
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(warnings).where(eq(warnings.userId, userId));
  const limit = Number(await getSetting("warningsBeforeBan")) || 3;
  let banned = false;
  if (n >= limit && !target.isBanned) {
    await db.update(users).set({ isBanned: true, banReason: `Автоблокировка: ${n} предупреждений`, status: "invisible" }).where(eq(users.id, userId));
    await db.delete(sessions).where(eq(sessions.userId, userId));
    publish([userId], { type: "banned" });
    await logAdmin(admin.id, "auto_ban", "user", userId, `@${target.username}: ${n} предупреждений`);
    banned = true;
  }
  await logAdmin(admin.id, "warn", "user", userId, `@${target.username}: ${reason}`);
  return { ok: true, count: n, banned };
});

export const DELETE = route(async (req) => {
  const admin = await requireAdmin();
  const id = uuid(new URL(req.url).searchParams.get("id"));
  await db.delete(warnings).where(eq(warnings.id, id));
  await logAdmin(admin.id, "delete_warning", "warning", id);
  return { ok: true };
});
