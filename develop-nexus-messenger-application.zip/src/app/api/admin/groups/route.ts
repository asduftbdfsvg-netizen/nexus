import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { chats } from "@/db/schema";
import { ApiError, route, uuid } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { memberIds } from "@/lib/chat";
import { publish } from "@/lib/events";
import { logAdmin } from "@/lib/platform";

export const GET = route(async () => {
  await requireAdmin();
  const rows = await db
    .select({
      id: chats.id,
      title: chats.title,
      description: chats.description,
      createdAt: chats.createdAt,
      lastMessageAt: chats.lastMessageAt,
      members: sql<number>`(select count(*)::int from chat_members cm where cm.chat_id = ${chats.id})`,
      messages: sql<number>`(select count(*)::int from messages m where m.chat_id = ${chats.id} and m.type <> 'system')`,
      owner: sql<string | null>`(select u.username from chat_members cm join users u on u.id = cm.user_id where cm.chat_id = ${chats.id} and cm.role = 'owner' limit 1)`,
    })
    .from(chats)
    .where(eq(chats.type, "group"))
    .orderBy(desc(chats.lastMessageAt))
    .limit(300);
  return { groups: rows };
});

export const DELETE = route(async (req) => {
  const admin = await requireAdmin();
  const id = uuid(new URL(req.url).searchParams.get("id"));
  const [chat] = await db.select().from(chats).where(eq(chats.id, id)).limit(1);
  if (!chat || chat.type !== "group") throw new ApiError(404, "Группа не найдена");
  const members = await memberIds(id);
  await db.delete(chats).where(eq(chats.id, id));
  publish(members, { type: "chats" });
  await logAdmin(admin.id, "delete_group", "chat", id, chat.title ?? "");
  return { ok: true };
});
