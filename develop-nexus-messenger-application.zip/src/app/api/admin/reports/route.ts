import { desc, eq, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db } from "@/db";
import { messages, reports, users } from "@/db/schema";
import { ApiError, oneOf, readJson, route, str, uuid } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { logAdmin } from "@/lib/platform";

export const GET = route(async (req) => {
  await requireAdmin();
  const status = new URL(req.url).searchParams.get("status");
  const reporter = alias(users, "reporter");
  const target = alias(users, "target");
  const rows = await db
    .select({
      id: reports.id,
      reason: reports.reason,
      status: reports.status,
      note: reports.resolutionNote,
      createdAt: reports.createdAt,
      reporter: reporter.username,
      targetId: target.id,
      target: target.username,
      targetBanned: target.isBanned,
      messageBody: messages.body,
      messageDeleted: messages.deletedAt,
      messageType: messages.type,
    })
    .from(reports)
    .leftJoin(reporter, eq(reporter.id, reports.reporterId))
    .leftJoin(target, eq(target.id, reports.targetUserId))
    .leftJoin(messages, eq(messages.id, reports.messageId))
    .where(status === "open" || status === "resolved" || status === "dismissed" ? eq(reports.status, status) : sql`true`)
    .orderBy(desc(reports.createdAt))
    .limit(200);
  return { reports: rows };
});

export const PATCH = route(async (req) => {
  const admin = await requireAdmin();
  const body = await readJson(req);
  const id = uuid(body.id);
  const status = oneOf(body.status, ["resolved", "dismissed", "open"] as const, "status");
  const note = str(body.note, "Комментарий", { max: 300, optional: true });
  const [r] = await db
    .update(reports)
    .set({ status, resolvedBy: status === "open" ? null : admin.id, resolutionNote: note || null })
    .where(eq(reports.id, id))
    .returning();
  if (!r) throw new ApiError(404, "Жалоба не найдена");
  await logAdmin(admin.id, `report_${status}`, "report", id, note);
  return { ok: true };
});
