import { sql } from "drizzle-orm";
import { db } from "@/db";
import { route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";

export const GET = route(async () => {
  await requireAdmin();
  const one = async (q: ReturnType<typeof sql>) => Number(((await db.execute(q)).rows[0] as { n: number }).n);
  const [users, messages, groups, directs, active24, active5m, msg24, newWeek, banned, openReports, admins, calls] = await Promise.all([
    one(sql`select count(*)::int n from users`),
    one(sql`select count(*)::int n from messages where type <> 'system'`),
    one(sql`select count(*)::int n from chats where type = 'group'`),
    one(sql`select count(*)::int n from chats where type = 'direct'`),
    one(sql`select count(*)::int n from users where last_seen > now() - interval '24 hours'`),
    one(sql`select count(*)::int n from users where last_seen > now() - interval '5 minutes' and status <> 'invisible'`),
    one(sql`select count(*)::int n from messages where type <> 'system' and created_at > now() - interval '24 hours'`),
    one(sql`select count(*)::int n from users where created_at > now() - interval '7 days'`),
    one(sql`select count(*)::int n from users where is_banned`),
    one(sql`select count(*)::int n from reports where status = 'open'`),
    one(sql`select count(*)::int n from users where role = 'admin'`),
    one(sql`select count(*)::int n from calls`),
  ]);
  const daily = await db.execute(sql`
    select to_char(d, 'DD.MM') as day, coalesce(c.n, 0)::int as n
    from generate_series(current_date - interval '6 days', current_date, interval '1 day') d
    left join (select date_trunc('day', created_at) as day, count(*) n from messages where type <> 'system' group by 1) c on c.day = d
    order by d`);
  return {
    users, messages, groups, directs, active24, active5m, msg24, newWeek, banned, openReports, admins, calls,
    daily: daily.rows as { day: string; n: number }[],
  };
});
