import { desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, sessions, users } from "@/db/schema";
import { ApiError, oneOf, readJson, route, str, uuid } from "@/lib/api";
import { newToken, requireAdmin } from "@/lib/auth";
import { notify } from "@/lib/chat";
import { publish } from "@/lib/events";
import { logAdmin } from "@/lib/platform";

export const GET = route(async (req) => {
  await requireAdmin();
  const sp = new URL(req.url).searchParams;
  const q = (sp.get("q") ?? "").trim().slice(0, 60);
  const page = Math.max(Number(sp.get("page")) || 0, 0);
  const like = `%${q.replace(/[%_\\]/g, "\\$&")}%`;
  const where = q ? or(ilike(users.username, like), ilike(users.email, like), ilike(users.displayName, like)) : undefined;
  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      username: users.username,
      displayName: users.displayName,
      avatarUrl: users.avatarUrl,
      role: users.role,
      isBanned: users.isBanned,
      banReason: users.banReason,
      lastSeen: users.lastSeen,
      createdAt: users.createdAt,
      warnings: sql<number>`(select count(*)::int from warnings w where w.user_id = ${users.id})`,
      messages: sql<number>`(select count(*)::int from messages m where m.sender_id = ${users.id})`,
    })
    .from(users)
    .where(where)
    .orderBy(desc(users.createdAt))
    .limit(30)
    .offset(page * 30);
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(users).where(where);
  return { users: rows, total: n };
});

export const PATCH = route(async (req) => {
  const admin = await requireAdmin();
  const body = await readJson(req);
  const userId = uuid(body.userId, "userId");
  const action = oneOf(body.action, ["ban", "unban", "makeAdmin", "removeAdmin", "resetLink"] as const, "action");
  const [target] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!target) throw new ApiError(404, "Пользователь не найден");
  if (target.id === admin.id && action !== "resetLink") throw new ApiError(400, "Нельзя применить это действие к себе");

  if (action === "ban") {
    if (target.role === "admin") throw new ApiError(400, "Сначала снимите права администратора");
    const reason = str(body.reason, "Причина", { max: 300, optional: true });
    await db.update(users).set({ isBanned: true, banReason: reason || null, status: "invisible" }).where(eq(users.id, userId));
    await db.delete(sessions).where(eq(sessions.userId, userId));
    publish([userId], { type: "banned" });
    await logAdmin(admin.id, "ban", "user", userId, `@${target.username}${reason ? `: ${reason}` : ""}`);
    return { ok: true };
  }
  if (action === "unban") {
    await db.update(users).set({ isBanned: false, banReason: null, status: "online" }).where(eq(users.id, userId));
    await logAdmin(admin.id, "unban", "user", userId, `@${target.username}`);
    return { ok: true };
  }
  if (action === "makeAdmin") {
    if (target.isBanned) throw new ApiError(400, "Пользователь заблокирован");
    await db.update(users).set({ role: "admin" }).where(eq(users.id, userId));
    await notify(userId, { type: "system", title: "Права администратора", body: "Вам выданы права администратора" });
    await logAdmin(admin.id, "grant_admin", "user", userId, `@${target.username}`);
    return { ok: true };
  }
  if (action === "removeAdmin") {
    await db.update(users).set({ role: "user" }).where(eq(users.id, userId));
    await logAdmin(admin.id, "revoke_admin", "user", userId, `@${target.username}`);
    return { ok: true };
  }
  // resetLink: one-time password reset link that the admin hands to the user over a trusted channel
  const token = newToken(24);
  await db.insert(passwordResets).values({ token, userId, expiresAt: new Date(Date.now() + 3600_000) });
  await logAdmin(admin.id, "reset_link", "user", userId, `@${target.username}`);
  const origin = process.env.APP_URL || req.headers.get("origin") || new URL(req.url).origin;
  return { ok: true, link: `${origin}/reset?token=${token}` };
});
