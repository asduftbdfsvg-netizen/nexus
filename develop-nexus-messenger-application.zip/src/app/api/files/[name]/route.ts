import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { getCurrentUser } from "@/lib/auth";
import { INLINE_MIME, UPLOAD_DIR } from "@/lib/storage";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  if (!/^[a-zA-Z0-9_-]+\.[a-z0-9]{1,8}$/.test(name)) return new Response("Not found", { status: 404 });
  // Avatars are public (needed on the login-adjacent screens); other files need a valid session.
  if (!name.startsWith("av-")) {
    const user = await getCurrentUser();
    if (!user) return new Response("Unauthorized", { status: 401 });
  }
  const file = path.join(UPLOAD_DIR, name);
  let size: number;
  try {
    size = (await stat(file)).size;
  } catch {
    return new Response("Not found", { status: 404 });
  }
  const ext = name.split(".").pop() ?? "";
  const inline = INLINE_MIME[ext];
  const headers: Record<string, string> = {
    "Content-Type": inline ?? "application/octet-stream",
    "X-Content-Type-Options": "nosniff",
    "Accept-Ranges": "bytes",
    "Cache-Control": "private, max-age=86400",
    "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
  };
  if (!inline) headers["Content-Disposition"] = "attachment";
  const q = req.headers.get("range")?.match(/bytes=(\d*)-(\d*)/);
  if (q) {
    const start = q[1] ? parseInt(q[1], 10) : 0;
    const end = q[2] ? Math.min(parseInt(q[2], 10), size - 1) : size - 1;
    if (start > end || start >= size) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${size}` } });
    const stream = Readable.toWeb(createReadStream(file, { start, end })) as ReadableStream;
    return new Response(stream, {
      status: 206,
      headers: { ...headers, "Content-Range": `bytes ${start}-${end}/${size}`, "Content-Length": String(end - start + 1) },
    });
  }
  const stream = Readable.toWeb(createReadStream(file)) as ReadableStream;
  return new Response(stream, { headers: { ...headers, "Content-Length": String(size) } });
}
