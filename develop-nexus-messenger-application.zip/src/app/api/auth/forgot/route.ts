import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { clientIp, rateLimit, readJson, route, str } from "@/lib/api";
import { newToken } from "@/lib/auth";

// Sends a reset link by e-mail via Resend (RESEND_API_KEY + MAIL_FROM) when configured.
// Without a mail provider the link is written to the server log (and admins can generate it from the admin panel).
export const POST = route(async (req) => {
  rateLimit(`forgot:${clientIp(req)}`, 5, 15 * 60_000);
  const body = await readJson(req);
  const email = str(body.email, "Email", { max: 200 }).toLowerCase();
  const delivery: "email" | "log" = process.env.RESEND_API_KEY && process.env.MAIL_FROM ? "email" : "log";

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (user && !user.isBanned) {
    const token = newToken(24);
    await db.insert(passwordResets).values({ token, userId: user.id, expiresAt: new Date(Date.now() + 3600_000) });
    const origin = process.env.APP_URL || req.headers.get("origin") || new URL(req.url).origin;
    const link = `${origin}/reset?token=${token}`;
    if (delivery === "email") {
      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            from: process.env.MAIL_FROM,
            to: email,
            subject: "NEXUS — восстановление пароля",
            text: `Чтобы задать новый пароль, перейдите по ссылке (действует 1 час):\n${link}`,
          }),
        });
      } catch (e) {
        console.error("[mail]", e);
      }
    } else {
      console.log(`[NEXUS] Password reset link for ${email}: ${link}`);
    }
  }
  // Always the same answer — do not reveal whether the account exists.
  return { ok: true, delivery };
});
