import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { route } from "@/lib/api";
import { destroySession, getCurrentUser } from "@/lib/auth";

export const POST = route(async () => {
  const user = await getCurrentUser();
  if (user) await db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, user.id));
  await destroySession();
  return { ok: true };
});
