import { eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, defaultSettings } from "@/db/schema";
import { ApiError, USERNAME_RE, clientIp, rateLimit, readJson, route, str } from "@/lib/api";
import { createSession, hashPassword } from "@/lib/auth";
import { getSetting } from "@/lib/platform";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const POST = route(async (req) => {
  rateLimit(`reg:${clientIp(req)}`, 10, 15 * 60_000);
  const body = await readJson(req);
  const email = str(body.email, "Email", { max: 200 }).toLowerCase();
  const password = str(body.password, "Пароль", { min: 8, max: 128 });
  const username = str(body.username, "Никнейм", { max: 24 }).toLowerCase().replace(/^@/, "");
  const displayName = str(body.displayName || username, "Имя", { min: 1, max: 50 });
  if (!EMAIL_RE.test(email)) throw new ApiError(400, "Некорректный email");
  if (!USERNAME_RE.test(username)) throw new ApiError(400, "Никнейм: 3–24 символа, латиница, цифры и _");

  if ((await getSetting("registrationOpen")) !== "true") throw new ApiError(403, "Регистрация временно закрыта");

  const [exists] = await db
    .select({ email: users.email, username: users.username })
    .from(users)
    .where(or(eq(users.email, email), eq(users.username, username)))
    .limit(1);
  if (exists) throw new ApiError(409, exists.email === email ? "Этот email уже зарегистрирован" : "Этот никнейм уже занят");

  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
  const isAdmin = n === 0 || (!!process.env.ADMIN_EMAIL && process.env.ADMIN_EMAIL.toLowerCase() === email);

  const [user] = await db
    .insert(users)
    .values({
      email,
      username,
      displayName,
      passwordHash: hashPassword(password),
      role: isAdmin ? "admin" : "user",
      settings: defaultSettings,
    })
    .returning({ id: users.id });
  await createSession(user.id);
  return { ok: true };
});
