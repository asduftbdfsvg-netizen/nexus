import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, sessions, users } from "@/db/schema";
import { ApiError, clientIp, rateLimit, readJson, route, str } from "@/lib/api";
import { hashPassword } from "@/lib/auth";

export const POST = route(async (req) => {
  rateLimit(`reset:${clientIp(req)}`, 10, 15 * 60_000);
  const body = await readJson(req);
  const token = str(body.token, "Токен", { max: 200 });
  const password = str(body.password, "Пароль", { min: 8, max: 128 });
  const [r] = await db
    .select()
    .from(passwordResets)
    .where(and(eq(passwordResets.token, token), isNull(passwordResets.usedAt), gt(passwordResets.expiresAt, new Date())))
    .limit(1);
  if (!r) throw new ApiError(400, "Ссылка недействительна или устарела");
  await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, r.userId));
  await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.token, token));
  await db.delete(sessions).where(eq(sessions.userId, r.userId));
  return { ok: true };
});
