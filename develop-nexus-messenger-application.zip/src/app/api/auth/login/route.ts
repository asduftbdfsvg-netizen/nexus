import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ApiError, clientIp, rateLimit, readJson, route, str } from "@/lib/api";
import { createSession, verifyPassword } from "@/lib/auth";

export const POST = route(async (req) => {
  const body = await readJson(req);
  const login = str(body.login, "Логин", { max: 200 }).toLowerCase().replace(/^@/, "");
  const password = str(body.password, "Пароль", { max: 128 });
  rateLimit(`login:${clientIp(req)}:${login}`, 8, 10 * 60_000);

  const [user] = await db
    .select()
    .from(users)
    .where(or(eq(users.email, login), eq(users.username, login)))
    .limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) throw new ApiError(401, "Неверный логин или пароль");
  if (user.isBanned) throw new ApiError(403, `Аккаунт заблокирован${user.banReason ? `: ${user.banReason}` : ""}`);
  await db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, user.id));
  await createSession(user.id);
  return { ok: true };
});
