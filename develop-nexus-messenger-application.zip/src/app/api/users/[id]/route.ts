import { and, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { blocks, friendships, users } from "@/db/schema";
import { ApiError, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { friendIdsOf, presentUser } from "@/lib/chat";

export const GET = route<{ id: string }>(async (_req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const [u] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!u || u.isBanned) throw new ApiError(404, "Пользователь не найден");
  const friends = await friendIdsOf(me.id);
  const [pending] = await db
    .select()
    .from(friendships)
    .where(and(eq(friendships.status, "pending"), or(and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, id)), and(eq(friendships.requesterId, id), eq(friendships.addresseeId, me.id)))))
    .limit(1);
  const [blocked] = await db.select().from(blocks).where(and(eq(blocks.blockerId, me.id), eq(blocks.blockedId, id))).limit(1);
  return {
    user: {
      ...presentUser(u, me.id, friends),
      joinedAt: u.createdAt.toISOString(),
      relation: friends.has(id) ? "friend" : pending ? (pending.requesterId === me.id ? "outgoing" : "incoming") : "none",
      blockedByMe: !!blocked,
    },
  };
});
