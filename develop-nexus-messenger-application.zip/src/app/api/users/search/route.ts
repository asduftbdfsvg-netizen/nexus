import { and, eq, ilike, notInArray, or } from "drizzle-orm";
import { db } from "@/db";
import { blocks, friendships, users } from "@/db/schema";
import { route } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { friendIdsOf, presentUser } from "@/lib/chat";

export const GET = route(async (req) => {
  const me = await requireUser();
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim().replace(/^@/, "").slice(0, 50);
  if (q.length < 2) return { users: [] };
  const like = `%${q.replace(/[%_\\]/g, "\\$&")}%`;
  const blockedMe = await db.select({ id: blocks.blockerId }).from(blocks).where(eq(blocks.blockedId, me.id));
  const exclude = [me.id, ...blockedMe.map((b) => b.id)];
  const rows = await db
    .select()
    .from(users)
    .where(and(eq(users.isBanned, false), notInArray(users.id, exclude), or(ilike(users.username, like), ilike(users.displayName, like))))
    .limit(20);
  const friends = await friendIdsOf(me.id);
  const pend = await db.select().from(friendships).where(and(eq(friendships.status, "pending"), or(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, me.id))));
  const mine = await db.select().from(blocks).where(eq(blocks.blockerId, me.id));
  return {
    users: rows.map((u) => ({
      ...presentUser(u, me.id, friends),
      relation: friends.has(u.id)
        ? "friend"
        : pend.some((p) => p.requesterId === me.id && p.addresseeId === u.id)
          ? "outgoing"
          : pend.some((p) => p.addresseeId === me.id && p.requesterId === u.id)
            ? "incoming"
            : mine.some((b) => b.blockedId === u.id)
              ? "blocked"
              : "none",
    })),
  };
});
