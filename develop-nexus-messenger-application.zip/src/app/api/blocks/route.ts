import { and, eq, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { blocks, friendships, users } from "@/db/schema";
import { ApiError, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { presentUsers } from "@/lib/chat";
import { publish } from "@/lib/events";

export const GET = route(async () => {
  const me = await requireUser();
  const rows = await db.select().from(blocks).where(eq(blocks.blockerId, me.id));
  const ids = rows.map((r) => r.blockedId);
  const people = ids.length ? await db.select().from(users).where(inArray(users.id, ids)) : [];
  return { users: await presentUsers(people, me.id) };
});

export const POST = route(async (req) => {
  const me = await requireUser();
  const userId = uuid((await readJson(req)).userId, "userId");
  if (userId === me.id) throw new ApiError(400, "Нельзя заблокировать себя");
  const [u] = await db.select({ id: users.id }).from(users).where(eq(users.id, userId)).limit(1);
  if (!u) throw new ApiError(404, "Пользователь не найден");
  await db.insert(blocks).values({ blockerId: me.id, blockedId: userId }).onConflictDoNothing();
  await db
    .delete(friendships)
    .where(or(and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, userId)), and(eq(friendships.requesterId, userId), eq(friendships.addresseeId, me.id))));
  publish([me.id, userId], { type: "chats" });
  publish([me.id, userId], { type: "friends" });
  return { ok: true };
});

export const DELETE = route(async (req) => {
  const me = await requireUser();
  const userId = uuid(new URL(req.url).searchParams.get("userId"), "userId");
  await db.delete(blocks).where(and(eq(blocks.blockerId, me.id), eq(blocks.blockedId, userId)));
  publish([me.id, userId], { type: "chats" });
  return { ok: true };
});
