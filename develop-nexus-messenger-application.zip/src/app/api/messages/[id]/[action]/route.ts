import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, favorites, messages, reactions, users } from "@/db/schema";
import { ApiError, isUuid, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { can, memberIds, requireMember, serializeMessages } from "@/lib/chat";
import { publish } from "@/lib/events";
import { createMessage, loadMessage } from "@/lib/messages";

type P = { id: string; action: string };

export const POST = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const { msg, chat, member } = await loadMessage(uuid(params.id), me.id);
  const body = await readJson(req).catch(() => ({}) as Record<string, unknown>);
  if (msg.deletedAt && params.action !== "favorite") throw new ApiError(400, "Сообщение удалено");
  const touch = async () => publish(await memberIds(msg.chatId), { type: "message-update", chatId: msg.chatId, messageId: msg.id });

  switch (params.action) {
    case "react": {
      const emoji = typeof body.emoji === "string" ? body.emoji.trim() : "";
      if (!emoji || emoji.length > 16) throw new ApiError(400, "Некорректная реакция");
      if (msg.type === "system") throw new ApiError(400, "Нельзя реагировать на системное сообщение");
      const where = and(eq(reactions.messageId, msg.id), eq(reactions.userId, me.id), eq(reactions.emoji, emoji));
      const [ex] = await db.select().from(reactions).where(where).limit(1);
      if (ex) await db.delete(reactions).where(where);
      else await db.insert(reactions).values({ messageId: msg.id, userId: me.id, emoji });
      await touch();
      return { ok: true };
    }
    case "pin": {
      if (!can(chat, member.role, "membersCanPin")) throw new ApiError(403, "Недостаточно прав для закрепления");
      const pinned = body.pinned !== false;
      await db
        .update(messages)
        .set({ pinnedAt: pinned ? new Date() : null, pinnedBy: pinned ? me.id : null })
        .where(eq(messages.id, msg.id));
      await touch();
      return { ok: true };
    }
    case "favorite": {
      const where = and(eq(favorites.userId, me.id), eq(favorites.messageId, msg.id));
      const [ex] = await db.select().from(favorites).where(where).limit(1);
      if (ex) await db.delete(favorites).where(where);
      else await db.insert(favorites).values({ userId: me.id, messageId: msg.id });
      return { favorite: !ex };
    }
    case "forward": {
      if (msg.type === "system") throw new ApiError(400, "Нельзя переслать системное сообщение");
      const targets = Array.isArray(body.chatIds) ? [...new Set(body.chatIds.filter(isUuid))].slice(0, 10) : [];
      if (!targets.length) throw new ApiError(400, "Выберите чат");
      const [src] = await db.select({ n: users.displayName }).from(users).where(eq(users.id, msg.senderId ?? me.id)).limit(1);
      let sent = 0;
      for (const t of targets) {
        const [m] = await db.select().from(chatMembers).where(and(eq(chatMembers.chatId, t), eq(chatMembers.userId, me.id))).limit(1);
        if (!m) continue;
        const { chat: tc, member: tm } = await requireMember(t, me.id);
        if (!can(tc, tm.role, "membersCanSend")) continue;
        await createMessage({
          chatId: t,
          senderId: me.id,
          type: msg.type,
          body: msg.body,
          attachmentUrl: msg.attachmentUrl,
          attachmentName: msg.attachmentName,
          attachmentSize: msg.attachmentSize,
          attachmentMime: msg.attachmentMime,
          forwardedFrom: msg.forwardedFrom ?? src?.n ?? "Неизвестно",
        });
        sent++;
      }
      if (!sent) throw new ApiError(403, "Не удалось переслать сообщение");
      return { ok: true, sent };
    }
    default:
      throw new ApiError(404, "Неизвестное действие");
  }
});

export const GET = route<P>(async (_req, { params }) => {
  const me = await requireUser();
  const { msg } = await loadMessage(uuid(params.id), me.id);
  return { message: (await serializeMessages([msg], me.id))[0] };
});
