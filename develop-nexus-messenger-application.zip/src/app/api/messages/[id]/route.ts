import { eq } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { ApiError, readJson, route, str, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { isStaff, memberIds, serializeMessages } from "@/lib/chat";
import { loadMessage } from "@/lib/messages";
import { publish } from "@/lib/events";

type P = { id: string };

export const GET = route<P>(async (_req, { params }) => {
  const me = await requireUser();
  const { msg } = await loadMessage(uuid(params.id), me.id);
  return { message: (await serializeMessages([msg], me.id))[0] };
});

export const PATCH = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const { msg } = await loadMessage(uuid(params.id), me.id);
  if (msg.senderId !== me.id) throw new ApiError(403, "Можно редактировать только свои сообщения");
  if (msg.deletedAt) throw new ApiError(400, "Сообщение удалено");
  if (msg.type === "sticker" || msg.type === "gif" || msg.type === "system") throw new ApiError(400, "Это сообщение нельзя редактировать");
  const body = await readJson(req);
  const text = str(body.text, "Текст", { max: 4000, min: msg.attachmentUrl ? 0 : 1 });
  const [row] = await db.update(messages).set({ body: text, editedAt: new Date() }).where(eq(messages.id, msg.id)).returning();
  publish(await memberIds(msg.chatId), { type: "message-update", chatId: msg.chatId, messageId: msg.id });
  return { message: (await serializeMessages([row], me.id))[0] };
});

export const DELETE = route<P>(async (_req, { params }) => {
  const me = await requireUser();
  const { msg, member, chat } = await loadMessage(uuid(params.id), me.id);
  const mayModerate = chat.type === "group" && isStaff(member.role);
  if (msg.senderId !== me.id && !mayModerate) throw new ApiError(403, "Недостаточно прав для удаления");
  await db.update(messages).set({ deletedAt: new Date(), pinnedAt: null, pinnedBy: null }).where(eq(messages.id, msg.id));
  publish(await memberIds(msg.chatId), { type: "message-update", chatId: msg.chatId, messageId: msg.id });
  return { ok: true };
});
