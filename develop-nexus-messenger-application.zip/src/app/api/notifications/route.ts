import { and, desc, eq, inArray, isNull } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { isUuid, readJson, route } from "@/lib/api";
import { requireUser } from "@/lib/auth";

export const GET = route(async () => {
  const me = await requireUser();
  const items = await db.select().from(notifications).where(eq(notifications.userId, me.id)).orderBy(desc(notifications.createdAt)).limit(50);
  return { notifications: items, unread: items.filter((n) => !n.readAt).length };
});

export const POST = route(async (req) => {
  const me = await requireUser();
  const body = await readJson(req);
  const ids = Array.isArray(body.ids) ? body.ids.filter(isUuid) : [];
  const cond = body.all === true ? eq(notifications.userId, me.id) : inArray(notifications.id, ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
  await db
    .update(notifications)
    .set({ readAt: new Date() })
    .where(and(eq(notifications.userId, me.id), isNull(notifications.readAt), cond));
  return { ok: true };
});

export const DELETE = route(async () => {
  const me = await requireUser();
  await db.delete(notifications).where(eq(notifications.userId, me.id));
  return { ok: true };
});
