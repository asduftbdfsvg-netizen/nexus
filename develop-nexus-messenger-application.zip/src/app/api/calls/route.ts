import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { calls } from "@/db/schema";
import { ApiError, oneOf, rateLimit, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { activeParticipants, endStaleCalls, joinCall } from "@/lib/calls";
import { can, isBlockedBetween, memberIds, requireMember } from "@/lib/chat";
import { publish } from "@/lib/events";

// Start a call in a chat (or join the one that is already running — group voice rooms).
export const POST = route(async (req) => {
  const me = await requireUser();
  rateLimit(`call:${me.id}`, 30, 10 * 60_000);
  const body = await readJson(req);
  const chatId = uuid(body.chatId, "chatId");
  const kind = oneOf(body.kind, ["voice", "video"] as const, "kind");
  const { chat, member } = await requireMember(chatId, me.id);
  if (!can(chat, member.role, "membersCanStartCalls")) throw new ApiError(403, "Звонки в этом чате доступны только администраторам");

  const ids = await memberIds(chatId);
  const others = ids.filter((i) => i !== me.id);
  if (chat.type === "direct") {
    if (others[0] && (await isBlockedBetween(me.id, others[0]))) throw new ApiError(403, "Звонок невозможен: пользователь заблокирован");
    if (!others[0]) throw new ApiError(400, "Собеседник покинул чат");
  }

  await endStaleCalls(chatId);
  let [call] = await db.select().from(calls).where(and(eq(calls.chatId, chatId), isNull(calls.endedAt))).limit(1);
  let created = false;
  if (!call) {
    [call] = await db.insert(calls).values({ chatId, kind, startedBy: me.id }).returning();
    created = true;
  }
  const participants = await joinCall(call.id, me.id, me.displayName);
  if (created) {
    publish(others, {
      type: "call-incoming",
      call: {
        id: call.id,
        chatId,
        kind: call.kind,
        isGroup: chat.type === "group",
        chatTitle: chat.title,
        from: { id: me.id, name: me.displayName, avatarUrl: me.avatarUrl },
      },
    });
  }
  publish(ids, { type: "chats" });
  return { call: { id: call.id, chatId, kind: call.kind, isGroup: chat.type === "group", title: chat.title }, participants };
});

export const GET = route(async (req) => {
  const me = await requireUser();
  const chatId = uuid(new URL(req.url).searchParams.get("chatId"), "chatId");
  await requireMember(chatId, me.id);
  const [call] = await db.select().from(calls).where(and(eq(calls.chatId, chatId), isNull(calls.endedAt))).limit(1);
  return { call: call ?? null, participants: call ? await activeParticipants(call.id) : [] };
});
