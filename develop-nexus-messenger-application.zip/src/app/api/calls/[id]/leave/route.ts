import { route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { leaveCall } from "@/lib/calls";

// Also called through navigator.sendBeacon on tab close.
export const POST = route<{ id: string }>(async (_req, { params }) => {
  const me = await requireUser();
  await leaveCall(uuid(params.id), me.id);
  return { ok: true };
});
