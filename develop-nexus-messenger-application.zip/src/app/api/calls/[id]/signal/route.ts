import { ApiError, rateLimit, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { activeParticipants, requireActiveCall } from "@/lib/calls";
import { publish } from "@/lib/events";

// WebRTC signaling relay (offer / answer / ICE candidates / media state) between call participants.
export const POST = route<{ id: string }>(async (req, { params }) => {
  const me = await requireUser();
  rateLimit(`signal:${me.id}`, 1500, 60_000);
  const id = uuid(params.id);
  await requireActiveCall(id, me.id);
  const body = await readJson(req);
  const to = uuid(body.to, "to");
  const data = body.data;
  if (typeof data !== "object" || data === null || JSON.stringify(data).length > 20000) throw new ApiError(400, "Некорректный сигнал");
  const participants = await activeParticipants(id);
  if (!participants.some((p) => p.id === me.id) || !participants.some((p) => p.id === to)) throw new ApiError(403, "Нет доступа к звонку");
  publish([to], { type: "signal", callId: id, from: me.id, data });
  return { ok: true };
});
