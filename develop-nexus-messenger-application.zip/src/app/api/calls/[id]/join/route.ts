import { route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { joinCall, requireActiveCall } from "@/lib/calls";

export const POST = route<{ id: string }>(async (_req, { params }) => {
  const me = await requireUser();
  const { call, chat } = await requireActiveCall(uuid(params.id), me.id);
  const participants = await joinCall(call.id, me.id, me.displayName);
  return { call: { id: call.id, chatId: call.chatId, kind: call.kind, isGroup: chat.type === "group", title: chat.title }, participants };
});
