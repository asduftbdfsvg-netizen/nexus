import { eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { broadcastPresence, coMemberIds } from "@/lib/chat";
import { isConnected, publish, subscribe, type ServerEvent } from "@/lib/events";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

// Server-Sent Events stream: realtime messages, typing, presence, notifications, call signaling.
export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return new Response("Unauthorized", { status: 401 });
  const enc = new TextEncoder();
  let cleanup = () => {};

  const stream = new ReadableStream({
    start(controller) {
      let closed = false;
      const send = (e: ServerEvent) => {
        if (closed) return;
        try {
          controller.enqueue(enc.encode(`data: ${JSON.stringify(e)}\n\n`));
        } catch {
          /* stream closed */
        }
      };
      const unsub = subscribe(user.id, send);
      send({ type: "ready" });

      // Everything pending is now "delivered" to this user.
      void (async () => {
        await db.update(chatMembers).set({ lastDeliveredAt: new Date() }).where(eq(chatMembers.userId, user.id));
        const others = await coMemberIds(user.id);
        publish(others, { type: "presence", userId: user.id });
        publish(others, { type: "receipt", userId: user.id });
      })().catch(() => {});

      const ping = setInterval(() => {
        if (closed) return;
        try {
          controller.enqueue(enc.encode(": ping\n\n"));
        } catch {
          /* ignore */
        }
        void db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, user.id)).catch(() => {});
      }, 25_000);

      cleanup = () => {
        if (closed) return;
        closed = true;
        clearInterval(ping);
        unsub();
        void (async () => {
          await db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, user.id));
          if (!isConnected(user.id)) await broadcastPresence(user.id);
        })().catch(() => {});
        try {
          controller.close();
        } catch {
          /* ignore */
        }
      };
      req.signal.addEventListener("abort", cleanup);
    },
    cancel() {
      cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
