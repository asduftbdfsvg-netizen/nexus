import { route } from "@/lib/api";
import { requireUser } from "@/lib/auth";

type Giphy = { data?: { id: string; images: { fixed_height: { url: string }; fixed_height_small?: { url: string }; downsized?: { url: string } } }[] };

// GIF search via GIPHY (set GIPHY_API_KEY). Without a key the client falls back to pasting a GIF link.
export const GET = route(async (req) => {
  await requireUser();
  const key = process.env.GIPHY_API_KEY;
  if (!key) return { enabled: false, gifs: [] };
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim().slice(0, 60);
  const url = q
    ? `https://api.giphy.com/v1/gifs/search?api_key=${key}&q=${encodeURIComponent(q)}&limit=24&rating=pg-13`
    : `https://api.giphy.com/v1/gifs/trending?api_key=${key}&limit=24&rating=pg-13`;
  try {
    const res = await fetch(url, { next: { revalidate: 300 } });
    const json = (await res.json()) as Giphy;
    return {
      enabled: true,
      gifs: (json.data ?? []).map((g) => ({
        id: g.id,
        url: g.images.fixed_height.url,
        preview: g.images.fixed_height_small?.url ?? g.images.fixed_height.url,
      })),
    };
  } catch {
    return { enabled: true, gifs: [] };
  }
});
