import { randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { ApiError, rateLimit, route } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { getSetting } from "@/lib/platform";
import { INLINE_MIME, kindOf, UPLOAD_DIR } from "@/lib/storage";

export const POST = route(async (req) => {
  const me = await requireUser();
  rateLimit(`upload:${me.id}`, 40, 10 * 60_000);
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw new ApiError(400, "Некорректная загрузка");
  }
  const file = form.get("file");
  const purpose = form.get("purpose") === "avatar" ? "avatar" : "attachment";
  if (!(file instanceof File) || file.size === 0) throw new ApiError(400, "Файл не выбран");

  const maxMb = purpose === "avatar" ? 5 : Number(await getSetting("maxUploadMb")) || 25;
  if (file.size > maxMb * 1024 * 1024) throw new ApiError(413, `Файл больше ${maxMb} МБ`);

  const rawExt = (file.name.split(".").pop() ?? "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
  const ext = rawExt || "bin";
  const mime = INLINE_MIME[ext] ?? "application/octet-stream";
  if (purpose === "avatar" && kindOf(mime) !== "image") throw new ApiError(400, "Аватар должен быть изображением (png, jpg, gif, webp)");

  const name = `${purpose === "avatar" ? "av-" : ""}${randomBytes(16).toString("hex")}.${ext}`;
  await mkdir(UPLOAD_DIR, { recursive: true });
  await writeFile(path.join(UPLOAD_DIR, name), Buffer.from(await file.arrayBuffer()));
  return {
    url: `/api/files/${name}`,
    name: file.name.slice(0, 200),
    size: file.size,
    mime,
    kind: kindOf(mime),
  };
});
