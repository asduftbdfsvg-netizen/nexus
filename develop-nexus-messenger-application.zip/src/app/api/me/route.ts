import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { users, defaultSettings, type UserSettings } from "@/db/schema";
import { ApiError, USERNAME_RE, oneOf, readJson, route, safeFileUrl, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { broadcastPresence, selfDTO } from "@/lib/chat";

const ACCENTS = ["violet", "blue", "emerald", "rose", "amber", "cyan"] as const;

function bool(v: unknown, fallback: boolean) {
  return typeof v === "boolean" ? v : fallback;
}

function mergeSettings(cur: UserSettings, input: Record<string, Record<string, unknown>>): UserSettings {
  const base = {
    privacy: { ...defaultSettings.privacy, ...cur.privacy },
    notifications: { ...defaultSettings.notifications, ...cur.notifications },
    appearance: { ...defaultSettings.appearance, ...cur.appearance },
  };
  const p = input.privacy ?? {};
  const n = input.notifications ?? {};
  const a = input.appearance ?? {};
  return {
    privacy: {
      lastSeen: p.lastSeen !== undefined ? oneOf(p.lastSeen, ["everyone", "friends", "nobody"] as const, "lastSeen") : base.privacy.lastSeen,
      avatar: p.avatar !== undefined ? oneOf(p.avatar, ["everyone", "friends", "nobody"] as const, "avatar") : base.privacy.avatar,
      messages: p.messages !== undefined ? oneOf(p.messages, ["everyone", "friends"] as const, "messages") : base.privacy.messages,
      readReceipts: bool(p.readReceipts, base.privacy.readReceipts),
      typing: bool(p.typing, base.privacy.typing),
    },
    notifications: {
      sound: bool(n.sound, base.notifications.sound),
      desktop: bool(n.desktop, base.notifications.desktop),
      messages: bool(n.messages, base.notifications.messages),
      friendRequests: bool(n.friendRequests, base.notifications.friendRequests),
      groups: bool(n.groups, base.notifications.groups),
      preview: bool(n.preview, base.notifications.preview),
    },
    appearance: {
      theme: a.theme !== undefined ? oneOf(a.theme, ["dark", "light", "system"] as const, "theme") : base.appearance.theme,
      accent: a.accent !== undefined ? oneOf(a.accent, ACCENTS, "accent") : base.appearance.accent,
      fontSize: a.fontSize !== undefined ? oneOf(a.fontSize, ["sm", "md", "lg"] as const, "fontSize") : base.appearance.fontSize,
      compact: bool(a.compact, base.appearance.compact),
      bubbles: a.bubbles !== undefined ? oneOf(a.bubbles, ["round", "square"] as const, "bubbles") : base.appearance.bubbles,
    },
  };
}

export const GET = route(async () => selfDTO(await requireUser()));

export const PATCH = route(async (req) => {
  const me = await requireUser();
  const body = await readJson(req);
  const patch: Partial<typeof users.$inferInsert> = {};
  if (body.displayName !== undefined) patch.displayName = str(body.displayName, "Имя", { min: 1, max: 50 });
  if (body.bio !== undefined) patch.bio = str(body.bio, "Описание", { max: 300, optional: true });
  if (body.username !== undefined) {
    const username = str(body.username, "Никнейм", { max: 24 }).toLowerCase().replace(/^@/, "");
    if (!USERNAME_RE.test(username)) throw new ApiError(400, "Никнейм: 3–24 символа, латиница, цифры и _");
    const [taken] = await db.select({ id: users.id }).from(users).where(and(eq(users.username, username), ne(users.id, me.id))).limit(1);
    if (taken) throw new ApiError(409, "Этот никнейм уже занят");
    patch.username = username;
  }
  if (body.avatarUrl !== undefined) {
    patch.avatarUrl = body.avatarUrl === null ? null : safeFileUrl(body.avatarUrl);
    if (body.avatarUrl !== null && !patch.avatarUrl) throw new ApiError(400, "Некорректный аватар");
  }
  if (body.status !== undefined) patch.status = oneOf(body.status, ["online", "away", "dnd", "invisible"] as const, "status");
  if (body.settings && typeof body.settings === "object") {
    patch.settings = mergeSettings(me.settings, body.settings as Record<string, Record<string, unknown>>);
  }
  if (Object.keys(patch).length) {
    patch.lastSeen = new Date();
    await db.update(users).set(patch).where(eq(users.id, me.id));
  }
  if (patch.status || patch.avatarUrl !== undefined || patch.displayName) await broadcastPresence(me.id);
  const [fresh] = await db.select().from(users).where(eq(users.id, me.id)).limit(1);
  return selfDTO(fresh);
});
