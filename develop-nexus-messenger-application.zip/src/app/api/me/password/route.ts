import { and, eq, ne } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { ApiError, rateLimit, readJson, route, str } from "@/lib/api";
import { hashPassword, requireUser, SESSION_COOKIE, verifyPassword } from "@/lib/auth";

export const POST = route(async (req) => {
  const me = await requireUser();
  rateLimit(`pw:${me.id}`, 6, 15 * 60_000);
  const body = await readJson(req);
  const current = str(body.current, "Текущий пароль", { max: 128 });
  const next = str(body.next, "Новый пароль", { min: 8, max: 128 });
  if (!verifyPassword(current, me.passwordHash)) throw new ApiError(400, "Текущий пароль неверен");
  await db.update(users).set({ passwordHash: hashPassword(next) }).where(eq(users.id, me.id));
  const token = (await cookies()).get(SESSION_COOKIE)?.value ?? "";
  await db.delete(sessions).where(and(eq(sessions.userId, me.id), ne(sessions.token, token)));
  return { ok: true };
});
