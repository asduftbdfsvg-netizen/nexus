import { route } from "@/lib/api";
import { getSettings } from "@/lib/platform";

export const GET = route(async () => {
  const s = await getSettings();
  return { rules: s.rules, registrationOpen: s.registrationOpen === "true" };
});
