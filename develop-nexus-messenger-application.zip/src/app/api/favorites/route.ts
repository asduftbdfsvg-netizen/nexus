import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, favorites, messages } from "@/db/schema";
import { route } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { serializeMessages } from "@/lib/chat";
import { and, inArray, isNull } from "drizzle-orm";

export const GET = route(async () => {
  const me = await requireUser();
  const mine = db.select({ id: chatMembers.chatId }).from(chatMembers).where(eq(chatMembers.userId, me.id));
  const rows = await db
    .select({ m: messages })
    .from(favorites)
    .innerJoin(messages, eq(messages.id, favorites.messageId))
    .where(and(eq(favorites.userId, me.id), isNull(messages.deletedAt), inArray(messages.chatId, mine)))
    .orderBy(desc(favorites.createdAt))
    .limit(200);
  return { messages: await serializeMessages(rows.map((r) => r.m), me.id) };
});
