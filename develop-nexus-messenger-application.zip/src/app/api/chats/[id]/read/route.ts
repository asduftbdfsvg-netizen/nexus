import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers } from "@/db/schema";
import { route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { memberIds, requireMember } from "@/lib/chat";
import { publish } from "@/lib/events";

export const POST = route<{ id: string }>(async (_req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  await requireMember(id, me.id);
  const now = new Date();
  await db
    .update(chatMembers)
    .set({ lastReadAt: now, lastDeliveredAt: now })
    .where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, me.id)));
  const others = (await memberIds(id)).filter((u) => u !== me.id);
  publish(others, { type: "receipt", chatId: id, userId: me.id });
  publish([me.id], { type: "chats" });
  return { ok: true };
});
