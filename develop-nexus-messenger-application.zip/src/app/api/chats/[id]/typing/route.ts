import { rateLimit, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { memberIds, requireMember } from "@/lib/chat";
import { publish } from "@/lib/events";

export const POST = route<{ id: string }>(async (_req, { params }) => {
  const me = await requireUser();
  rateLimit(`typing:${me.id}`, 60, 60_000);
  const id = uuid(params.id);
  await requireMember(id, me.id);
  if (me.settings?.privacy?.typing === false) return { ok: true };
  const others = (await memberIds(id)).filter((u) => u !== me.id);
  publish(others, { type: "typing", chatId: id, userId: me.id, name: me.displayName });
  return { ok: true };
});
