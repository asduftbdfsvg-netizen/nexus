import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, users } from "@/db/schema";
import { ApiError, isUuid, oneOf, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { can, isBlockedBetween, isStaff, memberIds, notify, requireMember } from "@/lib/chat";
import { publish } from "@/lib/events";
import { systemMessage } from "@/lib/messages";
import { getSetting } from "@/lib/platform";

type P = { id: string };

export const POST = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const { chat, member } = await requireMember(id, me.id);
  if (chat.type !== "group") throw new ApiError(400, "Участников можно добавлять только в группы");
  if (!can(chat, member.role, "membersCanInvite")) throw new ApiError(403, "Недостаточно прав для добавления участников");
  const body = await readJson(req);
  const wanted = Array.isArray(body.userIds) ? [...new Set(body.userIds.filter(isUuid))] : [];
  if (!wanted.length) throw new ApiError(400, "Выберите пользователей");
  const existing = await memberIds(id);
  const max = Number(await getSetting("maxGroupMembers")) || 200;
  const fresh = wanted.filter((u) => !existing.includes(u));
  if (existing.length + fresh.length > max) throw new ApiError(400, `Максимум ${max} участников`);
  const found = fresh.length ? await db.select().from(users).where(and(inArray(users.id, fresh), eq(users.isBanned, false))) : [];
  for (const u of found) {
    if (await isBlockedBetween(me.id, u.id)) continue;
    await db.insert(chatMembers).values({ chatId: id, userId: u.id }).onConflictDoNothing();
    await systemMessage(id, `${me.displayName} добавил(а) ${u.displayName}`);
    await notify(u.id, { type: "group_add", title: "Вас добавили в группу", body: `${me.displayName} добавил(а) вас в «${chat.title}»`, data: { chatId: id } }, "groups");
  }
  publish(await memberIds(id), { type: "chats" });
  return { ok: true };
});

export const PATCH = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const { chat, member } = await requireMember(id, me.id);
  if (chat.type !== "group") throw new ApiError(400, "Доступно только для групп");
  if (member.role !== "owner") throw new ApiError(403, "Назначать администраторов может только владелец");
  const body = await readJson(req);
  const userId = uuid(body.userId, "userId");
  const role = oneOf(body.role, ["admin", "member"] as const, "role");
  if (userId === me.id) throw new ApiError(400, "Нельзя изменить собственную роль");
  const [target] = await db.select().from(chatMembers).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, userId))).limit(1);
  if (!target) throw new ApiError(404, "Участник не найден");
  await db.update(chatMembers).set({ role }).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, userId)));
  const [u] = await db.select({ n: users.displayName }).from(users).where(eq(users.id, userId)).limit(1);
  await systemMessage(id, role === "admin" ? `${u?.n} назначен(а) администратором` : `${u?.n} больше не администратор`);
  publish(await memberIds(id), { type: "chats" });
  return { ok: true };
});

export const DELETE = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const { chat, member } = await requireMember(id, me.id);
  if (chat.type !== "group") throw new ApiError(400, "Доступно только для групп");
  if (!isStaff(member.role)) throw new ApiError(403, "Недостаточно прав");
  const userId = uuid(new URL(req.url).searchParams.get("userId"), "userId");
  const [target] = await db.select().from(chatMembers).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, userId))).limit(1);
  if (!target) throw new ApiError(404, "Участник не найден");
  if (target.role === "owner" || (target.role === "admin" && member.role !== "owner")) throw new ApiError(403, "Нельзя удалить этого участника");
  const before = await memberIds(id);
  await db.delete(chatMembers).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, userId)));
  const [u] = await db.select({ n: users.displayName }).from(users).where(eq(users.id, userId)).limit(1);
  await systemMessage(id, `${me.displayName} удалил(а) ${u?.n ?? "участника"} из группы`);
  publish(before, { type: "chats" });
  return { ok: true };
});
