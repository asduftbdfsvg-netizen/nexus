import { and, asc, desc, eq, gt, ilike, isNotNull, isNull, lt, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, messages } from "@/db/schema";
import { rateLimit, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { requireMember, serializeMessages } from "@/lib/chat";
import { validateAndSend } from "@/lib/messages";

type P = { id: string };

export const GET = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  await requireMember(id, me.id);
  const sp = new URL(req.url).searchParams;
  const before = Number(sp.get("before")) || 0;
  const after = Number(sp.get("after")) || 0;
  const q = (sp.get("q") ?? "").trim().slice(0, 100);
  const limit = Math.min(Number(sp.get("limit")) || 40, 100);

  const conds: SQL[] = [eq(messages.chatId, id)];
  if (q) {
    const like = `%${q.replace(/[%_\\]/g, "\\$&")}%`;
    conds.push(isNull(messages.deletedAt), or(ilike(messages.body, like), ilike(messages.attachmentName, like))!);
  }
  if (sp.get("pinned") === "1") conds.push(isNotNull(messages.pinnedAt), isNull(messages.deletedAt));
  if (before) conds.push(lt(messages.seq, before));
  if (after) conds.push(gt(messages.seq, after));

  const rows = after
    ? await db.select().from(messages).where(and(...conds)).orderBy(asc(messages.seq)).limit(200)
    : (await db.select().from(messages).where(and(...conds)).orderBy(desc(messages.seq)).limit(limit)).reverse();

  await db
    .update(chatMembers)
    .set({ lastDeliveredAt: new Date() })
    .where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, me.id)));
  return { messages: await serializeMessages(rows, me.id), hasMore: !after && rows.length === limit };
});

export const POST = route<P>(async (req, { params }) => {
  const me = await requireUser();
  rateLimit(`msg:${me.id}`, 60, 60_000);
  const id = uuid(params.id);
  const body = await readJson(req);
  const row = await validateAndSend(me.id, id, {
    type: body.type,
    text: body.text,
    attachment: (body.attachment as Record<string, unknown> | null) ?? null,
    replyToId: body.replyToId,
  });
  const [msg] = await serializeMessages([row], me.id);
  return { message: msg };
});
