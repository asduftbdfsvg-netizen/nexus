import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, chats, users, defaultPermissions, type ChatPermissions } from "@/db/schema";
import { ApiError, readJson, route, safeFileUrl, str, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { friendIdsOf, isStaff, listChats, memberIds, presentUser, requireMember } from "@/lib/chat";
import { publish } from "@/lib/events";
import { systemMessage } from "@/lib/messages";

type P = { id: string };

export const GET = route<P>(async (_req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  await requireMember(id, me.id);
  const rows = await db
    .select({ m: chatMembers, u: users })
    .from(chatMembers)
    .innerJoin(users, eq(users.id, chatMembers.userId))
    .where(eq(chatMembers.chatId, id))
    .orderBy(asc(chatMembers.joinedAt));
  const friends = await friendIdsOf(me.id);
  return {
    chat: (await listChats(me.id, id))[0],
    members: rows.map((r) => ({ ...presentUser(r.u, me.id, friends), memberRole: r.m.role })),
  };
});

export const PATCH = route<P>(async (req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const { chat, member } = await requireMember(id, me.id);
  const body = await readJson(req);

  // Personal preferences — any member.
  const prefs: Partial<typeof chatMembers.$inferInsert> = {};
  for (const k of ["archived", "muted", "pinned"] as const) if (typeof body[k] === "boolean") prefs[k] = body[k] as boolean;
  if (Object.keys(prefs).length) await db.update(chatMembers).set(prefs).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, me.id)));

  // Group settings — staff only.
  const patch: Partial<typeof chats.$inferInsert> = {};
  const touches = ["title", "description", "avatarUrl", "permissions"].some((k) => body[k] !== undefined);
  if (touches) {
    if (chat.type !== "group") throw new ApiError(400, "Доступно только для групп");
    if (!isStaff(member.role)) throw new ApiError(403, "Только администраторы могут менять настройки группы");
    if (body.title !== undefined) patch.title = str(body.title, "Название", { min: 1, max: 60 });
    if (body.description !== undefined) patch.description = str(body.description, "Описание", { max: 300, optional: true });
    if (body.avatarUrl !== undefined) {
      patch.avatarUrl = body.avatarUrl === null ? null : safeFileUrl(body.avatarUrl);
      if (body.avatarUrl !== null && !patch.avatarUrl) throw new ApiError(400, "Некорректный аватар");
    }
    if (body.permissions && typeof body.permissions === "object") {
      const inp = body.permissions as Record<string, unknown>;
      const next = { ...defaultPermissions, ...chat.permissions } as ChatPermissions;
      for (const k of Object.keys(defaultPermissions) as (keyof ChatPermissions)[]) if (typeof inp[k] === "boolean") next[k] = inp[k] as boolean;
      patch.permissions = next;
    }
    await db.update(chats).set(patch).where(eq(chats.id, id));
    if (patch.title && patch.title !== chat.title) await systemMessage(id, `${me.displayName} изменил(а) название группы на «${patch.title}»`);
  }
  publish(touches ? await memberIds(id) : [me.id], { type: "chats" });
  return { chat: (await listChats(me.id, id))[0] };
});

// Leave a group / remove a direct chat from my list.
export const DELETE = route<P>(async (_req, { params }) => {
  const me = await requireUser();
  const id = uuid(params.id);
  const { chat, member } = await requireMember(id, me.id);
  const all = await db.select().from(chatMembers).where(eq(chatMembers.chatId, id)).orderBy(asc(chatMembers.joinedAt));
  const rest = all.filter((m) => m.userId !== me.id);
  await db.delete(chatMembers).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, me.id)));
  if (chat.type === "group") {
    if (rest.length === 0) {
      await db.delete(chats).where(eq(chats.id, id));
    } else {
      if (member.role === "owner") {
        const heir = rest.find((m) => m.role === "admin") ?? rest[0];
        await db.update(chatMembers).set({ role: "owner" }).where(and(eq(chatMembers.chatId, id), eq(chatMembers.userId, heir.userId)));
      }
      await systemMessage(id, `${me.displayName} покинул(а) группу`);
    }
  }
  publish([me.id, ...rest.map((m) => m.userId)], { type: "chats" });
  return { ok: true };
});
