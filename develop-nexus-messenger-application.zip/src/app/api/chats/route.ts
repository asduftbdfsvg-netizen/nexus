import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, chats, users } from "@/db/schema";
import { ApiError, isUuid, readJson, route, safeFileUrl, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { directKey, friendIdsOf, isBlockedBetween, listChats, notify } from "@/lib/chat";
import { publish } from "@/lib/events";
import { getSetting } from "@/lib/platform";
import { systemMessage } from "@/lib/messages";

export const GET = route(async () => {
  const me = await requireUser();
  const now = new Date();
  await db.update(chatMembers).set({ lastDeliveredAt: now }).where(eq(chatMembers.userId, me.id));
  return { chats: await listChats(me.id) };
});

export const POST = route(async (req) => {
  const me = await requireUser();
  const body = await readJson(req);

  if (body.type === "direct") {
    if (!isUuid(body.userId)) throw new ApiError(400, "Некорректный пользователь");
    if (body.userId === me.id) throw new ApiError(400, "Нельзя написать самому себе");
    const [other] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
    if (!other || other.isBanned) throw new ApiError(404, "Пользователь не найден");
    if (await isBlockedBetween(me.id, other.id)) throw new ApiError(403, "Чат недоступен: пользователь заблокирован");
    if (other.settings?.privacy?.messages === "friends" && !(await friendIdsOf(me.id)).has(other.id))
      throw new ApiError(403, "Пользователь принимает сообщения только от друзей");
    const key = directKey(me.id, other.id);
    let [chat] = await db.select().from(chats).where(eq(chats.directKey, key)).limit(1);
    if (!chat) {
      [chat] = await db.insert(chats).values({ type: "direct", directKey: key, createdBy: me.id }).returning();
      await db.insert(chatMembers).values([
        { chatId: chat.id, userId: me.id, role: "member" },
        { chatId: chat.id, userId: other.id, role: "member" },
      ]);
    } else {
      await db
        .insert(chatMembers)
        .values([
          { chatId: chat.id, userId: me.id, role: "member" },
          { chatId: chat.id, userId: other.id, role: "member" },
        ])
        .onConflictDoNothing();
      await db
        .update(chatMembers)
        .set({ archived: false })
        .where(and(eq(chatMembers.chatId, chat.id), eq(chatMembers.userId, me.id)));
    }
    publish([me.id, other.id], { type: "chats" });
    return { chat: (await listChats(me.id, chat.id))[0] };
  }

  if (body.type === "group") {
    const title = str(body.title, "Название", { min: 1, max: 60 });
    const description = str(body.description, "Описание", { max: 300, optional: true });
    const avatarUrl = body.avatarUrl ? safeFileUrl(body.avatarUrl) : null;
    const wanted = Array.isArray(body.memberIds) ? [...new Set(body.memberIds.filter(isUuid))].filter((id) => id !== me.id) : [];
    const max = Number(await getSetting("maxGroupMembers")) || 200;
    if (wanted.length + 1 > max) throw new ApiError(400, `Максимум ${max} участников`);
    const found = wanted.length ? await db.select({ id: users.id }).from(users).where(and(inArray(users.id, wanted), eq(users.isBanned, false))) : [];
    const [chat] = await db.insert(chats).values({ type: "group", title, description, avatarUrl, createdBy: me.id }).returning();
    await db.insert(chatMembers).values([
      { chatId: chat.id, userId: me.id, role: "owner" },
      ...found.map((f) => ({ chatId: chat.id, userId: f.id, role: "member" })),
    ]);
    await systemMessage(chat.id, `${me.displayName} создал(а) группу «${title}»`);
    for (const f of found) await notify(f.id, { type: "group_add", title: "Вас добавили в группу", body: `${me.displayName} добавил(а) вас в «${title}»`, data: { chatId: chat.id } }, "groups");
    publish([me.id, ...found.map((f) => f.id)], { type: "chats" });
    return { chat: (await listChats(me.id, chat.id))[0] };
  }
  throw new ApiError(400, "Неизвестный тип чата");
});
