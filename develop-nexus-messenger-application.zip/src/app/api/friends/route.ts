import { and, eq, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { friendships, users } from "@/db/schema";
import { ApiError, oneOf, rateLimit, readJson, route, uuid } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { friendIdsOf, isBlockedBetween, notify, presentUsers } from "@/lib/chat";
import { publish } from "@/lib/events";

export const GET = route(async () => {
  const me = await requireUser();
  const rows = await db
    .select()
    .from(friendships)
    .where(or(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, me.id)));
  const otherIds = rows.map((r) => (r.requesterId === me.id ? r.addresseeId : r.requesterId));
  const people = otherIds.length ? await db.select().from(users).where(and(inArray(users.id, otherIds), eq(users.isBanned, false))) : [];
  const dtos = new Map((await presentUsers(people, me.id)).map((u) => [u.id, u]));
  const friends: unknown[] = [];
  const incoming: unknown[] = [];
  const outgoing: unknown[] = [];
  for (const r of rows) {
    const u = dtos.get(r.requesterId === me.id ? r.addresseeId : r.requesterId);
    if (!u) continue;
    if (r.status === "accepted") friends.push(u);
    else if (r.addresseeId === me.id) incoming.push({ id: r.id, user: u });
    else outgoing.push({ id: r.id, user: u });
  }
  return { friends, incoming, outgoing };
});

// Send a friend request (by username or userId).
export const POST = route(async (req) => {
  const me = await requireUser();
  rateLimit(`fr:${me.id}`, 30, 10 * 60_000);
  const body = await readJson(req);
  let target;
  if (typeof body.username === "string") {
    [target] = await db.select().from(users).where(eq(users.username, body.username.trim().toLowerCase().replace(/^@/, ""))).limit(1);
  } else {
    [target] = await db.select().from(users).where(eq(users.id, uuid(body.userId, "userId"))).limit(1);
  }
  if (!target || target.isBanned) throw new ApiError(404, "Пользователь не найден");
  if (target.id === me.id) throw new ApiError(400, "Нельзя добавить самого себя");
  if (await isBlockedBetween(me.id, target.id)) throw new ApiError(403, "Невозможно отправить заявку");
  if ((await friendIdsOf(me.id)).has(target.id)) throw new ApiError(409, "Вы уже друзья");

  const [reverse] = await db
    .select()
    .from(friendships)
    .where(and(eq(friendships.requesterId, target.id), eq(friendships.addresseeId, me.id)))
    .limit(1);
  if (reverse) {
    await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, reverse.id));
    await notify(target.id, { type: "friend_accept", title: "Заявка принята", body: `${me.displayName} теперь в друзьях`, data: { userId: me.id } }, "friendRequests");
    publish([me.id, target.id], { type: "friends" });
    return { status: "accepted" };
  }
  const inserted = await db.insert(friendships).values({ requesterId: me.id, addresseeId: target.id }).onConflictDoNothing().returning();
  if (inserted.length) {
    await notify(target.id, { type: "friend_request", title: "Новая заявка в друзья", body: `${me.displayName} (@${me.username}) хочет добавить вас в друзья`, data: { userId: me.id } }, "friendRequests");
  }
  publish([me.id, target.id], { type: "friends" });
  return { status: "pending" };
});

export const PATCH = route(async (req) => {
  const me = await requireUser();
  const body = await readJson(req);
  const id = uuid(body.id);
  const action = oneOf(body.action, ["accept", "decline"] as const, "action");
  const [fr] = await db
    .select()
    .from(friendships)
    .where(and(eq(friendships.id, id), eq(friendships.addresseeId, me.id), eq(friendships.status, "pending")))
    .limit(1);
  if (!fr) throw new ApiError(404, "Заявка не найдена");
  if (action === "accept") {
    await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, id));
    await notify(fr.requesterId, { type: "friend_accept", title: "Заявка принята", body: `${me.displayName} принял(а) вашу заявку`, data: { userId: me.id } }, "friendRequests");
  } else {
    await db.delete(friendships).where(eq(friendships.id, id));
  }
  publish([me.id, fr.requesterId], { type: "friends" });
  return { ok: true };
});

// Remove a friend / cancel an outgoing request.
export const DELETE = route(async (req) => {
  const me = await requireUser();
  const userId = uuid(new URL(req.url).searchParams.get("userId"), "userId");
  await db
    .delete(friendships)
    .where(or(and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, userId)), and(eq(friendships.requesterId, userId), eq(friendships.addresseeId, me.id))));
  publish([me.id, userId], { type: "friends" });
  return { ok: true };
});
