import { eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, reports, users } from "@/db/schema";
import { ApiError, isUuid, rateLimit, readJson, route, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { requireMember } from "@/lib/chat";

export const POST = route(async (req) => {
  const me = await requireUser();
  rateLimit(`report:${me.id}`, 10, 60 * 60_000);
  const body = await readJson(req);
  const reason = str(body.reason, "Причина", { min: 3, max: 500 });
  let targetUserId: string | null = null;
  let messageId: string | null = null;
  let chatId: string | null = null;
  if (isUuid(body.messageId)) {
    const [m] = await db.select().from(messages).where(eq(messages.id, body.messageId)).limit(1);
    if (!m) throw new ApiError(404, "Сообщение не найдено");
    await requireMember(m.chatId, me.id);
    messageId = m.id;
    chatId = m.chatId;
    targetUserId = m.senderId;
  } else if (isUuid(body.userId)) {
    const [u] = await db.select({ id: users.id }).from(users).where(eq(users.id, body.userId)).limit(1);
    if (!u) throw new ApiError(404, "Пользователь не найден");
    targetUserId = u.id;
  } else throw new ApiError(400, "Не указан объект жалобы");
  if (targetUserId === me.id) throw new ApiError(400, "Нельзя пожаловаться на себя");
  await db.insert(reports).values({ reporterId: me.id, targetUserId, messageId, chatId, reason });
  return { ok: true };
});
