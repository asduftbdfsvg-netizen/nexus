import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "NEXUS — мессенджер",
  description: "NEXUS — современный мессенджер: личные и групповые чаты, звонки, файлы, реакции.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b0d14",
};

// Applies the saved theme before first paint to avoid a flash.
const themeScript = `(function(){try{var d=document.documentElement;var t=localStorage.getItem('nexus-theme')||'dark';if(t==='system')t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';d.dataset.theme=t;d.dataset.accent=localStorage.getItem('nexus-accent')||'violet';d.dataset.font=localStorage.getItem('nexus-font')||'md';}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" data-theme="dark" data-accent="violet" data-font="md" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
