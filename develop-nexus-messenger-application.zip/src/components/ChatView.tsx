"use client";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { api, fmtDay, fmtLastSeen, fmtTime, uploadFile, type Uploaded } from "@/lib/client";
import type { MessageDTO } from "@/lib/chat";
import { useApp, type ChatDTO } from "./app-context";
import Bubble, { type MsgActions } from "./MessageBubble";
import Composer, { type SendPayload } from "./Composer";
import { previewText } from "./Sidebar";
import { Avatar, Empty, Icon, Spinner, useToast } from "./ui";

function upsert(list: MessageDTO[], incoming: MessageDTO[]) {
  const map = new Map(list.map((m) => [m.id, m]));
  for (const m of incoming) map.set(m.id, m);
  return [...map.values()].sort((a, b) => a.seq - b.seq);
}

export default function ChatView({ chat }: { chat: ChatDTO }) {
  const { me, openChat, subscribe, showInfo, setShowInfo, chatName, chatAvatar, startCall, joinCall, inCallChatId, setModal, refreshChats } = useApp();
  const toast = useToast();
  const [messages, setMessages] = useState<MessageDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(false);
  const [replyTo, setReplyTo] = useState<MessageDTO | null>(null);
  const [editing, setEditing] = useState<MessageDTO | null>(null);
  const [typing, setTyping] = useState<Record<string, string>>({});
  const [pinned, setPinned] = useState<MessageDTO[]>([]);
  const [pinIdx, setPinIdx] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);
  const [sq, setSq] = useState("");
  const [results, setResults] = useState<MessageDTO[] | null>(null);
  const [uploading, setUploading] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [atBottom, setAtBottom] = useState(true);
  const [flash, setFlash] = useState<string | null>(null);

  const msgsRef = useRef(messages);
  msgsRef.current = messages;
  const scroller = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const restore = useRef<{ h: number; t: number } | null>(null);
  const jumpTarget = useRef<string | null>(null);
  const lastTyping = useRef(0);
  const loadingMore = useRef(false);
  const unreadRef = useRef(chat.unread);
  unreadRef.current = chat.unread;

  const isGroup = chat.type === "group";
  const staff = chat.myRole === "owner" || chat.myRole === "admin";
  const canSend = !isGroup || staff || chat.permissions.membersCanSend;
  const canPin = !isGroup || staff || chat.permissions.membersCanPin;
  const canCall = !isGroup || staff || chat.permissions.membersCanStartCalls;
  const base = `/api/chats/${chat.id}`;

  const loadPinned = useCallback(async () => {
    try {
      const r = await api<{ messages: MessageDTO[] }>(`${base}/messages?pinned=1&limit=50`);
      setPinned(r.messages.sort((a, b) => (b.pinnedAt ?? "").localeCompare(a.pinnedAt ?? "")));
      setPinIdx(0);
    } catch { /* ignore */ }
  }, [base]);

  const loadInitial = useCallback(async () => {
    try {
      const r = await api<{ messages: MessageDTO[]; hasMore: boolean }>(`${base}/messages?limit=40`);
      stick.current = true;
      setMessages(r.messages);
      setHasMore(r.hasMore);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Не удалось загрузить сообщения", "error");
    } finally {
      setLoading(false);
    }
  }, [base, toast]);

  const fetchAfter = useCallback(async () => {
    const last = msgsRef.current.at(-1)?.seq ?? 0;
    try {
      const r = await api<{ messages: MessageDTO[] }>(`${base}/messages?after=${last}`);
      if (r.messages.length) setMessages((l) => upsert(l, r.messages));
    } catch { /* ignore */ }
  }, [base]);

  const refreshRecent = useCallback(async () => {
    try {
      const r = await api<{ messages: MessageDTO[] }>(`${base}/messages?limit=50`);
      setMessages((l) => upsert(l, r.messages));
    } catch { /* ignore */ }
  }, [base]);

  const refreshOne = useCallback(async (id: string) => {
    try {
      const r = await api<{ message: MessageDTO }>(`/api/messages/${id}`);
      setMessages((l) => upsert(l, [r.message]));
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    loadInitial();
    loadPinned();
  }, [loadInitial, loadPinned]);

  // realtime events for this chat
  useEffect(
    () =>
      subscribe((e) => {
        if (e.type === "message" && e.chatId === chat.id) {
          fetchAfter();
          const uid = e.senderId as string;
          setTyping((t) => { const n = { ...t }; delete n[uid]; return n; });
        } else if (e.type === "message-update" && e.chatId === chat.id) {
          refreshOne(e.messageId as string);
          loadPinned();
        } else if (e.type === "receipt" && (!e.chatId || e.chatId === chat.id)) {
          refreshRecent();
        } else if (e.type === "typing" && e.chatId === chat.id) {
          const uid = e.userId as string;
          setTyping((t) => ({ ...t, [uid]: e.name as string }));
          setTimeout(() => setTyping((t) => { const n = { ...t }; delete n[uid]; return n; }), 4000);
        } else if (e.type === "reconnected") {
          fetchAfter();
        }
      }),
    [subscribe, chat.id, fetchAfter, refreshOne, refreshRecent, loadPinned],
  );

  // mark as read
  useEffect(() => {
    const mark = () => {
      if (document.hidden || unreadRef.current <= 0) return;
      unreadRef.current = 0;
      api(`${base}/read`, { method: "POST" }).catch(() => {});
    };
    mark();
    window.addEventListener("focus", mark);
    document.addEventListener("visibilitychange", mark);
    return () => {
      window.removeEventListener("focus", mark);
      document.removeEventListener("visibilitychange", mark);
    };
  }, [base, chat.unread, messages.length]);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el) return;
    if (restore.current) {
      el.scrollTop = el.scrollHeight - restore.current.h + restore.current.t;
      restore.current = null;
    } else if (jumpTarget.current) {
      const t = document.getElementById(`msg-${jumpTarget.current}`);
      if (t) {
        t.scrollIntoView({ block: "center" });
        setFlash(jumpTarget.current);
        setTimeout(() => setFlash(null), 1600);
        jumpTarget.current = null;
      }
    } else if (stick.current) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages, loading, typing]);

  async function loadOlder() {
    if (loadingMore.current || !hasMore) return;
    const first = msgsRef.current[0];
    if (!first) return;
    loadingMore.current = true;
    try {
      const r = await api<{ messages: MessageDTO[]; hasMore: boolean }>(`${base}/messages?before=${first.seq}&limit=40`);
      const el = scroller.current;
      if (el) restore.current = { h: el.scrollHeight, t: el.scrollTop };
      setMessages((l) => upsert(l, r.messages));
      setHasMore(r.hasMore);
    } finally {
      loadingMore.current = false;
    }
  }

  function onScroll() {
    const el = scroller.current;
    if (!el) return;
    const bottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    stick.current = bottom;
    setAtBottom(bottom);
    if (el.scrollTop < 100) loadOlder();
  }

  async function jump(id: string) {
    const el = document.getElementById(`msg-${id}`);
    if (el) {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
      setFlash(id);
      setTimeout(() => setFlash(null), 1600);
      return;
    }
    try {
      const one = await api<{ message: MessageDTO }>(`/api/messages/${id}`);
      const r = await api<{ messages: MessageDTO[] }>(`${base}/messages?after=${Math.max(0, one.message.seq - 25)}`);
      jumpTarget.current = id;
      stick.current = false;
      setMessages(r.messages);
      setHasMore(true);
      setSearchOpen(false);
      setResults(null);
      setSq("");
    } catch {
      toast("Сообщение недоступно", "error");
    }
  }

  async function send(p: SendPayload) {
    try {
      const body: Record<string, unknown> = { type: p.type, text: p.text, attachment: p.attachment, replyToId: replyTo?.id };
      const r = await api<{ message: MessageDTO }>(`${base}/messages`, { body });
      stick.current = true;
      setReplyTo(null);
      setMessages((l) => upsert(l, [r.message]));
      refreshChats();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Не удалось отправить", "error");
      throw e;
    }
  }

  async function sendFiles(files: File[]) {
    const list = files.slice(0, 10);
    setUploading((n) => n + list.length);
    for (const f of list) {
      try {
        const up: Uploaded = await uploadFile(f);
        await send({ type: up.kind, attachment: { url: up.url, name: up.name, size: up.size, mime: up.mime } as SendPayload["attachment"] });
      } catch (e) {
        toast(e instanceof Error ? e.message : "Не удалось отправить файл", "error");
      } finally {
        setUploading((n) => n - 1);
      }
    }
  }

  async function submitEdit(text: string) {
    if (!editing) return;
    try {
      const r = await api<{ message: MessageDTO }>(`/api/messages/${editing.id}`, { method: "PATCH", body: { text } });
      setMessages((l) => upsert(l, [r.message]));
      setEditing(null);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
      throw e;
    }
  }

  function notifyTyping() {
    const now = Date.now();
    if (now - lastTyping.current < 3000) return;
    lastTyping.current = now;
    api(`${base}/typing`, { method: "POST", body: {} }).catch(() => {});
  }

  const actions: MsgActions = useMemo(() => {
    const call = async (path: string, body?: unknown, method = "POST", id?: string) => {
      try {
        await api(path, { method, body: body ?? {} });
        if (id) await refreshOne(id);
      } catch (e) {
        toast(e instanceof Error ? e.message : "Ошибка", "error");
      }
    };
    return {
      reply: (m) => { setEditing(null); setReplyTo(m); },
      edit: (m) => { setReplyTo(null); setEditing(m); },
      remove: (m) => { if (confirm("Удалить сообщение для всех?")) call(`/api/messages/${m.id}`, undefined, "DELETE", m.id).then(loadPinned); },
      forward: (m) => setModal({ kind: "forward", messageId: m.id }),
      pin: (m) => call(`/api/messages/${m.id}/pin`, { pinned: !m.pinnedAt }, "POST", m.id).then(loadPinned),
      favorite: async (m) => {
        await call(`/api/messages/${m.id}/favorite`, {}, "POST", m.id);
        toast(m.favorite ? "Удалено из избранного" : "Добавлено в избранное", "success");
      },
      react: (m, emoji) => call(`/api/messages/${m.id}/react`, { emoji }, "POST", m.id),
      report: (m) => setModal({ kind: "report", messageId: m.id }),
      copy: (m) => { navigator.clipboard?.writeText(m.body).then(() => toast("Скопировано", "success")).catch(() => {}); },
      jump,
      openProfile: (userId) => setModal({ kind: "profile", userId }),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshOne, setModal, toast, loadPinned, base]);

  // search
  useEffect(() => {
    const term = sq.trim();
    if (!searchOpen || !term) { setResults(null); return; }
    const t = setTimeout(async () => {
      try {
        const r = await api<{ messages: MessageDTO[] }>(`${base}/messages?q=${encodeURIComponent(term)}&limit=50`);
        setResults(r.messages.reverse());
      } catch { setResults([]); }
    }, 300);
    return () => clearTimeout(t);
  }, [sq, searchOpen, base]);

  const typingNames = Object.values(typing);
  const name = chatName(chat);
  const peer = chat.peer;
  const subtitle = typingNames.length
    ? null
    : isGroup
      ? `${chat.memberCount} участн.`
      : peer
        ? fmtLastSeen(peer.presence, peer.lastSeen)
        : "";

  const restriction = chat.blockedMe
    ? "Пользователь ограничил переписку с вами"
    : !canSend
      ? "Писать в этот чат могут только администраторы"
      : null;

  const items = useMemo(() => {
    const out: React.ReactNode[] = [];
    const list = messages;
    list.forEach((m, i) => {
      const prev = list[i - 1];
      const next = list[i + 1];
      const day = new Date(m.createdAt).toDateString();
      const newDay = !prev || new Date(prev.createdAt).toDateString() !== day;
      if (newDay) {
        out.push(
          <div key={`d-${m.id}`} className="sticky top-1 z-10 my-3 flex justify-center">
            <span className="rounded-full bg-panel/90 px-3 py-1 text-xs font-semibold text-muted shadow backdrop-blur">{fmtDay(m.createdAt)}</span>
          </div>,
        );
      }
      const sameRun = (a?: MessageDTO, b?: MessageDTO) =>
        !!a && !!b && a.type !== "system" && b.type !== "system" && a.sender?.id === b.sender?.id && new Date(a.createdAt).toDateString() === new Date(b.createdAt).toDateString() && Math.abs(+new Date(b.createdAt) - +new Date(a.createdAt)) < 5 * 60_000;
      out.push(
        <Bubble
          key={m.id}
          m={m}
          mine={m.sender?.id === me.id}
          isGroup={isGroup}
          first={!sameRun(prev, m)}
          last={!sameRun(m, next)}
          square={me.settings.appearance.bubbles === "square"}
          canModerate={isGroup && staff}
          canPin={canPin}
          highlight={flash === m.id}
          actions={actions}
        />,
      );
    });
    return out;
  }, [messages, me.id, me.settings.appearance.bubbles, isGroup, staff, canPin, flash, actions]);

  return (
    <div
      className="relative flex min-w-0 flex-1 flex-col bg-app"
      onDragOver={(e) => { if (e.dataTransfer.types.includes("Files")) { e.preventDefault(); setDragging(true); } }}
      onDragLeave={(e) => { if (e.currentTarget === e.target) setDragging(false); }}
      onDrop={(e) => { e.preventDefault(); setDragging(false); if (e.dataTransfer.files.length && canSend && !restriction) sendFiles([...e.dataTransfer.files]); }}
    >
      {/* header */}
      <header className="flex items-center gap-2 border-b border-line bg-panel px-3 py-2.5 md:px-4">
        <button className="icon-btn md:hidden" onClick={() => openChat(null)} aria-label="Назад"><Icon name="back" /></button>
        <button className="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-1 text-left transition hover:bg-panel2" onClick={() => setShowInfo(!showInfo)}>
          <Avatar name={name} src={chatAvatar(chat)} size={42} presence={peer?.presence} group={isGroup} />
          <div className="min-w-0">
            <div className="truncate font-bold leading-tight">{name}</div>
            <div className={`truncate text-xs ${typingNames.length || peer?.presence === "online" ? "text-accent" : "text-muted"}`}>
              {typingNames.length ? (
                <span className="inline-flex items-center gap-1.5">
                  {isGroup ? `${typingNames.join(", ")} печатает` : "печатает"}
                  <span className="inline-flex gap-0.5"><i className="typing-dot" /><i className="typing-dot" /><i className="typing-dot" /></span>
                </span>
              ) : subtitle}
            </div>
          </div>
        </button>
        <button className={`icon-btn ${searchOpen ? "!bg-panel3 !text-accent" : ""}`} title="Поиск по переписке" onClick={() => { setSearchOpen((v) => !v); setSq(""); }}><Icon name="search" /></button>
        {canCall && !chat.blockedMe && !chat.blockedByMe && (
          <>
            <button className="icon-btn" title={isGroup ? "Голосовая комната" : "Голосовой звонок"} onClick={() => (chat.activeCall ? joinCall(chat.id, chat.activeCall.kind) : startCall(chat.id, "voice"))}><Icon name="phone" /></button>
            <button className="icon-btn" title="Видеозвонок" onClick={() => (chat.activeCall ? joinCall(chat.id, "video") : startCall(chat.id, "video"))}><Icon name="video" /></button>
          </>
        )}
        <button className={`icon-btn ${showInfo ? "!bg-panel3 !text-accent" : ""}`} title="Информация" onClick={() => setShowInfo(!showInfo)}><Icon name="info" /></button>
      </header>

      {searchOpen && (
        <div className="anim-up flex items-center gap-2 border-b border-line bg-panel px-4 py-2">
          <Icon name="search" size={17} className="text-muted" />
          <input autoFocus className="min-w-0 flex-1 bg-transparent py-1.5 outline-none placeholder:text-muted" placeholder="Поиск по сообщениям и файлам…" value={sq} onChange={(e) => setSq(e.target.value)} />
          <button className="icon-btn !h-8 !w-8" onClick={() => { setSearchOpen(false); setSq(""); }}><Icon name="x" size={17} /></button>
        </div>
      )}

      {chat.activeCall && inCallChatId !== chat.id && (
        <div className="anim-up flex items-center gap-3 border-b border-line bg-ok/10 px-4 py-2 text-sm">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-ok text-white"><Icon name={chat.activeCall.kind === "video" ? "video" : "phone"} size={16} /></span>
          <div className="min-w-0 flex-1"><b>{isGroup ? "Идёт групповой звонок" : "Входящий звонок"}</b><span className="text-muted"> · {chat.activeCall.participants} в звонке</span></div>
          <button className="btn btn-primary !py-1.5" onClick={() => joinCall(chat.id, chat.activeCall!.kind)}>Присоединиться</button>
        </div>
      )}

      {pinned.length > 0 && !searchOpen && (
        <div className="anim-up flex items-center gap-3 border-b border-line bg-panel px-4 py-1.5">
          <button className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={() => { jump(pinned[pinIdx % pinned.length].id); setPinIdx((i) => (i + 1) % pinned.length); }}>
            <span className="h-8 w-[3px] shrink-0 rounded-full bg-accent" />
            <div className="min-w-0 text-sm">
              <div className="flex items-center gap-1 text-xs font-bold text-accent"><Icon name="pin" size={12} />Закреплено{pinned.length > 1 ? ` · ${(pinIdx % pinned.length) + 1}/${pinned.length}` : ""}</div>
              <div className="truncate text-muted">{previewText(pinned[pinIdx % pinned.length].type, pinned[pinIdx % pinned.length].body)}</div>
            </div>
          </button>
          {canPin && <button className="icon-btn !h-8 !w-8" title="Открепить" onClick={() => actions.pin(pinned[pinIdx % pinned.length])}><Icon name="x" size={16} /></button>}
        </div>
      )}

      {/* messages */}
      <div className="relative min-h-0 flex-1">
        {searchOpen && sq.trim() ? (
          <div className="absolute inset-0 overflow-y-auto p-3 md:p-5">
            {results === null ? <div className="grid place-items-center py-10"><Spinner /></div> : results.length === 0 ? (
              <Empty icon="search" title="Ничего не найдено" text="Попробуйте другой запрос" />
            ) : (
              <div className="mx-auto max-w-2xl space-y-1">
                {results.map((m) => (
                  <button key={m.id} onClick={() => jump(m.id)} className="anim-fade flex w-full items-start gap-3 rounded-xl p-3 text-left transition hover:bg-panel">
                    <Avatar name={m.sender?.displayName ?? "?"} src={m.sender?.avatarUrl} size={36} />
                    <div className="min-w-0 flex-1">
                      <div className="flex justify-between text-xs text-muted"><b className="text-fg">{m.sender?.displayName ?? "Система"}</b><span>{fmtDay(m.createdAt)}, {fmtTime(m.createdAt)}</span></div>
                      <div className="truncate text-sm">{m.body || m.attachment?.name || previewText(m.type, m.body)}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div ref={scroller} onScroll={onScroll} className="absolute inset-0 overflow-y-auto px-2 py-3 md:px-6">
            <div className="mx-auto max-w-3xl">
              {loading && <div className="grid place-items-center py-10"><Spinner size={26} /></div>}
              {hasMore && !loading && <div className="grid place-items-center py-3"><button className="btn btn-ghost !py-1.5 text-xs" onClick={loadOlder}>Загрузить ранние сообщения</button></div>}
              {!loading && messages.length === 0 && (
                <Empty icon="send" title="Сообщений пока нет" text={isGroup ? "Напишите первое сообщение в группе" : `Начните переписку с ${name}`} />
              )}
              {items}
              {typingNames.length > 0 && (
                <div className="anim-fade mt-2 flex">
                  <div className="flex items-center gap-1 rounded-2xl rounded-bl-md border border-line bg-bubble-in px-4 py-3 text-muted"><i className="typing-dot" /><i className="typing-dot" /><i className="typing-dot" /></div>
                </div>
              )}
              <div className="h-2" />
            </div>
          </div>
        )}
        {!atBottom && !searchOpen && (
          <button
            className="anim-pop absolute bottom-4 right-5 grid h-11 w-11 place-items-center rounded-full border border-line bg-panel text-fg shadow-lg transition hover:scale-105"
            onClick={() => { const el = scroller.current; if (el) { el.scrollTo({ top: el.scrollHeight, behavior: "smooth" }); } }}
            aria-label="Вниз"
          >
            <Icon name="chevron" className="rotate-90" />
            {chat.unread > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-white">{chat.unread}</span>}
          </button>
        )}
      </div>

      {chat.blockedByMe ? (
        <div className="flex items-center justify-center gap-3 border-t border-line bg-panel px-4 py-3 text-sm">
          <span className="text-muted">Вы заблокировали этого пользователя</span>
          <button className="btn btn-ghost !py-1.5" onClick={async () => { await api(`/api/blocks?userId=${chat.peer?.id}`, { method: "DELETE" }); refreshChats(); }}>Разблокировать</button>
        </div>
      ) : (
        <Composer
          replyTo={replyTo}
          editing={editing}
          onCancelReply={() => setReplyTo(null)}
          onCancelEdit={() => setEditing(null)}
          onSend={send}
          onEdit={submitEdit}
          onFiles={sendFiles}
          onTyping={notifyTyping}
          uploading={uploading}
          restriction={restriction}
        />
      )}

      {dragging && (
        <div className="anim-fade pointer-events-none absolute inset-0 z-40 grid place-items-center bg-accent/20 backdrop-blur-sm">
          <div className="rounded-3xl border-2 border-dashed border-accent bg-panel/90 px-10 py-8 text-center">
            <Icon name="paperclip" size={36} className="mx-auto text-accent" />
            <div className="mt-2 text-lg font-bold">Отпустите, чтобы отправить файлы</div>
          </div>
        </div>
      )}
    </div>
  );
}
