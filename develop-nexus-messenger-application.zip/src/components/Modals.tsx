"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, fmtDay, fmtLastSeen, fmtShort, fmtTime, uploadFile } from "@/lib/client";
import type { MessageDTO, UserDTO } from "@/lib/chat";
import type { ChatPermissions } from "@/db/schema";
import { useApp, type ChatDTO } from "./app-context";
import SettingsModal from "./SettingsModal";
import { previewText } from "./Sidebar";
import { Avatar, Empty, Icon, Modal, Spinner, Toggle, useToast } from "./ui";

export default function Modals() {
  const { modal, setModal } = useApp();
  if (!modal) return null;
  const close = () => setModal(null);
  switch (modal.kind) {
    case "settings": return <SettingsModal tab={modal.tab} />;
    case "friends": return <FriendsModal tab={modal.tab} onClose={close} />;
    case "newGroup": return <NewGroupModal onClose={close} />;
    case "addMembers": return <AddMembersModal chatId={modal.chatId} onClose={close} />;
    case "groupSettings": return <GroupSettingsModal chatId={modal.chatId} onClose={close} />;
    case "forward": return <ForwardModal messageId={modal.messageId} onClose={close} />;
    case "report": return <ReportModal messageId={modal.messageId} userId={modal.userId} onClose={close} />;
    case "profile": return <ProfileModal userId={modal.userId} onClose={close} />;
    case "notifications": return <NotificationsModal onClose={close} />;
    case "favorites": return <FavoritesModal onClose={close} />;
  }
}

type SearchUser = UserDTO & { relation?: string };

/* ---------- user picker (friends + global search) ---------- */
function UserPicker({ selected, onToggle, exclude = [] }: { selected: Map<string, SearchUser>; onToggle: (u: SearchUser) => void; exclude?: string[] }) {
  const [friends, setFriends] = useState<UserDTO[]>([]);
  const [q, setQ] = useState("");
  const [found, setFound] = useState<SearchUser[]>([]);
  useEffect(() => { api<{ friends: UserDTO[] }>("/api/friends").then((r) => setFriends(r.friends)).catch(() => {}); }, []);
  useEffect(() => {
    if (q.trim().length < 2) { setFound([]); return; }
    const t = setTimeout(() => api<{ users: SearchUser[] }>(`/api/users/search?q=${encodeURIComponent(q.trim())}`).then((r) => setFound(r.users)).catch(() => {}), 300);
    return () => clearTimeout(t);
  }, [q]);
  const list = (q.trim().length >= 2 ? found : friends).filter((u) => !exclude.includes(u.id));
  return (
    <div>
      <input className="input" placeholder="Поиск по никнейму или имени…" value={q} onChange={(e) => setQ(e.target.value)} />
      {selected.size > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {[...selected.values()].map((u) => (
            <button key={u.id} onClick={() => onToggle(u)} className="anim-pop flex items-center gap-1.5 rounded-full bg-accent/15 py-1 pl-1 pr-2.5 text-xs font-semibold text-accent">
              <Avatar name={u.displayName} src={u.avatarUrl} size={20} />{u.displayName}<Icon name="x" size={12} />
            </button>
          ))}
        </div>
      )}
      <div className="mt-2 max-h-64 overflow-y-auto">
        {q.trim().length < 2 && <div className="px-1 py-1.5 text-xs font-bold uppercase tracking-wider text-muted">Друзья</div>}
        {list.map((u) => {
          const on = selected.has(u.id);
          return (
            <button key={u.id} onClick={() => onToggle(u)} className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition hover:bg-panel2">
              <Avatar name={u.displayName} src={u.avatarUrl} size={38} presence={u.presence} />
              <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{u.displayName}</div><div className="truncate text-xs text-muted">@{u.username}</div></div>
              <span className={`grid h-5 w-5 place-items-center rounded-md border-2 ${on ? "grad border-transparent text-white" : "border-line"}`}>{on && <Icon name="check" size={13} />}</span>
            </button>
          );
        })}
        {list.length === 0 && <div className="py-6 text-center text-sm text-muted">{q.trim().length >= 2 ? "Никого не найдено" : "Список друзей пуст — найдите людей по никнейму"}</div>}
      </div>
    </div>
  );
}

/* ---------- friends ---------- */
type FriendsData = { friends: UserDTO[]; incoming: { id: string; user: UserDTO }[]; outgoing: { id: string; user: UserDTO }[] };

function FriendsModal({ tab: initial, onClose }: { tab?: string; onClose: () => void }) {
  const { openDirect, subscribe, setModal } = useApp();
  const toast = useToast();
  const [tab, setTab] = useState(initial ?? "friends");
  const [data, setData] = useState<FriendsData | null>(null);
  const [nick, setNick] = useState("");
  const [q, setQ] = useState("");
  const [found, setFound] = useState<SearchUser[]>([]);

  const load = useCallback(() => api<FriendsData>("/api/friends").then(setData).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => subscribe((e) => { if (e.type === "friends") load(); }), [subscribe, load]);
  useEffect(() => {
    if (q.trim().length < 2) { setFound([]); return; }
    const t = setTimeout(() => api<{ users: SearchUser[] }>(`/api/users/search?q=${encodeURIComponent(q.trim())}`).then((r) => setFound(r.users)).catch(() => {}), 300);
    return () => clearTimeout(t);
  }, [q]);

  const act = async (fn: () => Promise<unknown>, ok?: string) => {
    try { await fn(); if (ok) toast(ok, "success"); await load(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  };
  const add = (userId?: string, username?: string) => act(async () => {
    const r = await api<{ status: string }>("/api/friends", { body: userId ? { userId } : { username } });
    toast(r.status === "accepted" ? "Вы теперь друзья" : "Заявка отправлена", "success");
    if (userId) setFound((l) => l.map((u) => (u.id === userId ? { ...u, relation: r.status === "accepted" ? "friend" : "outgoing" } : u)));
  });
  const inCount = data?.incoming.length ?? 0;

  const person = (u: UserDTO, right: React.ReactNode) => (
    <div key={u.id} className="flex items-center gap-3 rounded-xl p-2.5 hover:bg-panel2">
      <button onClick={() => setModal({ kind: "profile", userId: u.id })}><Avatar name={u.displayName} src={u.avatarUrl} size={42} presence={u.presence} /></button>
      <div className="min-w-0 flex-1"><div className="truncate font-semibold">{u.displayName}</div><div className="truncate text-xs text-muted">@{u.username} · {fmtLastSeen(u.presence, u.lastSeen)}</div></div>
      {right}
    </div>
  );

  return (
    <Modal title="Друзья" onClose={onClose} width="max-w-xl">
      <div className="flex gap-1 border-b border-line px-4 pt-2">
        {([["friends", `Друзья${data ? ` · ${data.friends.length}` : ""}`], ["requests", `Заявки${inCount ? ` · ${inCount}` : ""}`], ["find", "Найти людей"]] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} className={`border-b-2 px-3 py-2.5 text-sm font-semibold transition ${tab === id ? "border-accent text-accent" : "border-transparent text-muted hover:text-fg"}`}>{label}</button>
        ))}
      </div>
      <div className="min-h-[320px] p-4">
        {!data && <div className="grid place-items-center py-10"><Spinner /></div>}
        {data && tab === "friends" && (data.friends.length === 0 ? <Empty icon="users" title="Пока нет друзей" text="Найдите людей по никнейму и отправьте заявку." /> : data.friends.map((u) => person(u, (
          <div className="flex gap-1">
            <button className="icon-btn" title="Написать" onClick={() => openDirect(u.id)}><Icon name="send" size={18} /></button>
            <button className="icon-btn" title="Удалить из друзей" onClick={() => confirm(`Удалить ${u.displayName} из друзей?`) && act(() => api(`/api/friends?userId=${u.id}`, { method: "DELETE" }))}><Icon name="x" size={18} /></button>
          </div>
        ))))}
        {data && tab === "requests" && (
          <div className="space-y-4">
            <div>
              <div className="label">Входящие</div>
              {data.incoming.length === 0 ? <div className="py-2 text-sm text-muted">Нет входящих заявок</div> : data.incoming.map((r) => person(r.user, (
                <div className="flex gap-1.5">
                  <button className="btn btn-primary !px-3 !py-1.5" onClick={() => act(() => api("/api/friends", { method: "PATCH", body: { id: r.id, action: "accept" } }), "Заявка принята")}>Принять</button>
                  <button className="btn btn-ghost !px-3 !py-1.5" onClick={() => act(() => api("/api/friends", { method: "PATCH", body: { id: r.id, action: "decline" } }))}>Отклонить</button>
                </div>
              )))}
            </div>
            <div>
              <div className="label">Исходящие</div>
              {data.outgoing.length === 0 ? <div className="py-2 text-sm text-muted">Нет исходящих заявок</div> : data.outgoing.map((r) => person(r.user, (
                <button className="btn btn-ghost !px-3 !py-1.5" onClick={() => act(() => api(`/api/friends?userId=${r.user.id}`, { method: "DELETE" }))}>Отменить</button>
              )))}
            </div>
          </div>
        )}
        {data && tab === "find" && (
          <div className="space-y-4">
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (nick.trim()) add(undefined, nick.trim()).then(() => setNick("")); }}>
              <div className="relative flex-1"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted">@</span><input className="input !pl-8" placeholder="Точный никнейм" value={nick} onChange={(e) => setNick(e.target.value)} /></div>
              <button className="btn btn-primary" disabled={!nick.trim()}><Icon name="userPlus" size={16} />Добавить</button>
            </form>
            <div>
              <div className="label">Поиск пользователей</div>
              <input className="input" placeholder="Никнейм или имя (от 2 символов)…" value={q} onChange={(e) => setQ(e.target.value)} />
              <div className="mt-2">
                {found.map((u) => person(u, (
                  <div className="flex gap-1">
                    <button className="icon-btn" title="Написать" onClick={() => openDirect(u.id)}><Icon name="send" size={18} /></button>
                    {u.relation === "none" && <button className="btn btn-primary !px-3 !py-1.5" onClick={() => add(u.id)}>В друзья</button>}
                    {u.relation === "outgoing" && <span className="self-center text-xs text-muted">отправлено</span>}
                    {u.relation === "incoming" && <button className="btn btn-primary !px-3 !py-1.5" onClick={() => add(u.id)}>Принять</button>}
                    {u.relation === "friend" && <span className="self-center text-xs text-ok">друг</span>}
                  </div>
                )))}
                {q.trim().length >= 2 && found.length === 0 && <div className="py-4 text-center text-sm text-muted">Никого не найдено</div>}
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}

/* ---------- groups ---------- */
function AvatarPicker({ url, onChange, name }: { url: string | null; onChange: (u: string | null) => void; name: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <div className="flex items-center gap-4">
      <button type="button" onClick={() => ref.current?.click()} className="relative">
        <Avatar name={name || "Группа"} src={url} size={72} group />
        <span className="absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full bg-accent text-white">{busy ? <Spinner size={14} /> : <Icon name="camera" size={14} />}</span>
      </button>
      <input ref={ref} type="file" accept="image/*" hidden onChange={async (e) => {
        const f = e.target.files?.[0]; e.target.value = "";
        if (!f) return;
        setBusy(true);
        try { onChange((await uploadFile(f, "avatar")).url); } catch (err) { toast(err instanceof Error ? err.message : "Ошибка", "error"); } finally { setBusy(false); }
      }} />
      {url && <button type="button" className="btn btn-ghost !py-1.5 text-xs" onClick={() => onChange(null)}>Убрать фото</button>}
    </div>
  );
}

function NewGroupModal({ onClose }: { onClose: () => void }) {
  const { openChat, refreshChats } = useApp();
  const toast = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [sel, setSel] = useState<Map<string, SearchUser>>(new Map());
  const [busy, setBusy] = useState(false);
  const toggle = (u: SearchUser) => setSel((m) => { const n = new Map(m); if (n.has(u.id)) n.delete(u.id); else n.set(u.id, u); return n; });
  async function create() {
    setBusy(true);
    try {
      const r = await api<{ chat: ChatDTO }>("/api/chats", { body: { type: "group", title, description, avatarUrl, memberIds: [...sel.keys()] } });
      await refreshChats();
      openChat(r.chat.id);
      onClose();
    } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
  }
  return (
    <Modal title="Новая группа" onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Отмена</button><button className="btn btn-primary" disabled={!title.trim() || busy} onClick={create}>{busy ? <Spinner size={16} /> : "Создать"}</button></>}>
      <div className="space-y-4 p-5">
        <AvatarPicker url={avatarUrl} onChange={setAvatarUrl} name={title} />
        <div><label className="label">Название</label><input className="input" value={title} maxLength={60} onChange={(e) => setTitle(e.target.value)} autoFocus /></div>
        <div><label className="label">Описание</label><textarea className="input min-h-20 resize-none" maxLength={300} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
        <div><label className="label">Участники</label><UserPicker selected={sel} onToggle={toggle} /></div>
      </div>
    </Modal>
  );
}

function AddMembersModal({ chatId, onClose }: { chatId: string; onClose: () => void }) {
  const { refreshChats } = useApp();
  const toast = useToast();
  const [existing, setExisting] = useState<string[]>([]);
  const [sel, setSel] = useState<Map<string, SearchUser>>(new Map());
  const [busy, setBusy] = useState(false);
  useEffect(() => { api<{ members: UserDTO[] }>(`/api/chats/${chatId}`).then((r) => setExisting(r.members.map((m) => m.id))).catch(() => {}); }, [chatId]);
  const toggle = (u: SearchUser) => setSel((m) => { const n = new Map(m); if (n.has(u.id)) n.delete(u.id); else n.set(u.id, u); return n; });
  return (
    <Modal title="Добавить участников" onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Отмена</button><button className="btn btn-primary" disabled={!sel.size || busy} onClick={async () => {
      setBusy(true);
      try { await api(`/api/chats/${chatId}/members`, { body: { userIds: [...sel.keys()] } }); await refreshChats(); toast("Участники добавлены", "success"); onClose(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
    }}>{busy ? <Spinner size={16} /> : `Добавить${sel.size ? ` (${sel.size})` : ""}`}</button></>}>
      <div className="p-5"><UserPicker selected={sel} onToggle={toggle} exclude={existing} /></div>
    </Modal>
  );
}

const PERMS: [keyof ChatPermissions, string, string][] = [
  ["membersCanSend", "Участники могут писать", "Если выключено — писать могут только администраторы"],
  ["membersCanSendMedia", "Участники могут отправлять медиа", "Фото, видео, файлы, GIF"],
  ["membersCanInvite", "Участники могут добавлять людей", ""],
  ["membersCanPin", "Участники могут закреплять сообщения", ""],
  ["membersCanStartCalls", "Участники могут начинать звонки", "Голосовые комнаты и видеозвонки"],
];

function GroupSettingsModal({ chatId, onClose }: { chatId: string; onClose: () => void }) {
  const { chats, refreshChats } = useApp();
  const toast = useToast();
  const chat = chats.find((c) => c.id === chatId);
  const [title, setTitle] = useState(chat?.title ?? "");
  const [description, setDescription] = useState(chat?.description ?? "");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(chat?.avatarUrl ?? null);
  const [perms, setPerms] = useState<ChatPermissions | null>(chat?.permissions ?? null);
  const [busy, setBusy] = useState(false);
  if (!chat || !perms) return null;
  return (
    <Modal title="Настройки группы" onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Отмена</button><button className="btn btn-primary" disabled={!title.trim() || busy} onClick={async () => {
      setBusy(true);
      try { await api(`/api/chats/${chatId}`, { method: "PATCH", body: { title, description, avatarUrl, permissions: perms } }); await refreshChats(); toast("Сохранено", "success"); onClose(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
    }}>{busy ? <Spinner size={16} /> : "Сохранить"}</button></>}>
      <div className="space-y-4 p-5">
        <AvatarPicker url={avatarUrl} onChange={setAvatarUrl} name={title} />
        <div><label className="label">Название</label><input className="input" value={title} maxLength={60} onChange={(e) => setTitle(e.target.value)} /></div>
        <div><label className="label">Описание</label><textarea className="input min-h-20 resize-none" maxLength={300} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
        <div>
          <div className="label">Разрешения участников</div>
          <div className="divide-y divide-line">
            {PERMS.map(([k, t, d]) => (
              <div key={k} className="flex items-center justify-between gap-4 py-3">
                <div><div className="text-sm font-semibold">{t}</div>{d && <div className="text-xs text-muted">{d}</div>}</div>
                <Toggle checked={perms[k]} onChange={(v) => setPerms({ ...perms, [k]: v })} />
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">Владелец и администраторы всегда имеют все права.</p>
        </div>
      </div>
    </Modal>
  );
}

/* ---------- forward / report / profile ---------- */
function ForwardModal({ messageId, onClose }: { messageId: string; onClose: () => void }) {
  const { chats, chatName, chatAvatar } = useApp();
  const toast = useToast();
  const [sel, setSel] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const list = chats.filter((c) => !c.blockedByMe && !c.blockedMe && (c.type === "direct" || c.myRole !== "member" || c.permissions.membersCanSend));
  return (
    <Modal title="Переслать сообщение" onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Отмена</button><button className="btn btn-primary" disabled={!sel.length || busy} onClick={async () => {
      setBusy(true);
      try { await api(`/api/messages/${messageId}/forward`, { body: { chatIds: sel } }); toast("Сообщение переслано", "success"); onClose(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
    }}>{busy ? <Spinner size={16} /> : `Переслать${sel.length ? ` (${sel.length})` : ""}`}</button></>}>
      <div className="p-3">
        {list.length === 0 && <Empty icon="send" title="Нет доступных чатов" />}
        {list.map((c) => {
          const on = sel.includes(c.id);
          return (
            <button key={c.id} onClick={() => setSel((s) => (on ? s.filter((x) => x !== c.id) : [...s, c.id]))} className="flex w-full items-center gap-3 rounded-xl p-2.5 text-left hover:bg-panel2">
              <Avatar name={chatName(c)} src={chatAvatar(c)} size={40} group={c.type === "group"} />
              <span className="min-w-0 flex-1 truncate font-semibold">{chatName(c)}</span>
              <span className={`grid h-5 w-5 place-items-center rounded-md border-2 ${on ? "grad border-transparent text-white" : "border-line"}`}>{on && <Icon name="check" size={13} />}</span>
            </button>
          );
        })}
      </div>
    </Modal>
  );
}

function ReportModal({ messageId, userId, onClose }: { messageId?: string; userId?: string; onClose: () => void }) {
  const toast = useToast();
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const presets = ["Спам", "Оскорбления", "Мошенничество", "Неприемлемый контент"];
  return (
    <Modal title="Пожаловаться" onClose={onClose} width="max-w-md" footer={<><button className="btn btn-ghost" onClick={onClose}>Отмена</button><button className="btn btn-danger" disabled={reason.trim().length < 3 || busy} onClick={async () => {
      setBusy(true);
      try { await api("/api/reports", { body: { reason, messageId, userId } }); toast("Жалоба отправлена модераторам", "success"); onClose(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
    }}>{busy ? <Spinner size={16} /> : "Отправить"}</button></>}>
      <div className="space-y-3 p-5">
        <div className="flex flex-wrap gap-2">{presets.map((p) => <button key={p} onClick={() => setReason(p)} className={`rounded-full px-3 py-1 text-xs font-semibold ${reason === p ? "grad text-white" : "bg-panel2 text-muted hover:text-fg"}`}>{p}</button>)}</div>
        <textarea className="input min-h-28 resize-none" placeholder="Опишите, что не так…" maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} autoFocus />
      </div>
    </Modal>
  );
}

function ProfileModal({ userId, onClose }: { userId: string; onClose: () => void }) {
  const { me, openDirect, setModal } = useApp();
  const toast = useToast();
  const [u, setU] = useState<(UserDTO & { joinedAt: string; relation: string; blockedByMe: boolean }) | null>(null);
  const load = useCallback(() => api<{ user: NonNullable<typeof u> }>(`/api/users/${userId}`).then((r) => setU(r.user)).catch((e) => { toast(e.message, "error"); onClose(); }), [userId, toast, onClose]);
  useEffect(() => { load(); }, [load]);
  return (
    <Modal onClose={onClose} width="max-w-sm">
      {!u ? <div className="grid place-items-center py-16"><Spinner /></div> : (
        <div className="flex flex-col items-center p-6 text-center">
          <Avatar name={u.displayName} src={u.avatarUrl} size={96} presence={u.presence} />
          <div className="mt-3 text-xl font-extrabold">{u.displayName}</div>
          <div className="text-sm text-muted">@{u.username}</div>
          <div className="mt-1 text-sm text-muted">{fmtLastSeen(u.presence, u.lastSeen)}</div>
          {u.bio && <p className="mt-3 w-full rounded-xl bg-panel2 p-3 text-sm">{u.bio}</p>}
          {u.id !== me.id && (
            <div className="mt-5 grid w-full grid-cols-2 gap-2">
              <button className="btn btn-primary col-span-2" onClick={() => openDirect(u.id)}><Icon name="send" size={16} />Написать</button>
              {u.relation === "none" && <button className="btn btn-ghost" onClick={async () => { await api("/api/friends", { body: { userId: u.id } }).then(() => toast("Заявка отправлена", "success")).catch((e) => toast(e.message, "error")); load(); }}><Icon name="userPlus" size={16} />В друзья</button>}
              {u.relation === "incoming" && <button className="btn btn-ghost" onClick={async () => { await api("/api/friends", { body: { userId: u.id } }).catch(() => {}); load(); }}>Принять заявку</button>}
              {u.relation === "outgoing" && <button className="btn btn-ghost" disabled>Заявка отправлена</button>}
              {u.relation === "friend" && <button className="btn btn-ghost" onClick={async () => { await api(`/api/friends?userId=${u.id}`, { method: "DELETE" }); load(); }}>Убрать из друзей</button>}
              <button className="btn btn-danger" onClick={() => setModal({ kind: "report", userId: u.id })}><Icon name="flag" size={16} />Жалоба</button>
              <button className="btn btn-ghost col-span-2 !text-danger" onClick={async () => { if (u.blockedByMe) await api(`/api/blocks?userId=${u.id}`, { method: "DELETE" }); else if (confirm("Заблокировать пользователя?")) await api("/api/blocks", { body: { userId: u.id } }); load(); }}><Icon name="block" size={16} />{u.blockedByMe ? "Разблокировать" : "Заблокировать"}</button>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}

/* ---------- notifications / favorites ---------- */
type Notif = { id: string; type: string; title: string; body: string; data: Record<string, string>; readAt: string | null; createdAt: string };

function NotificationsModal({ onClose }: { onClose: () => void }) {
  const { setModal, openChat, openDirect } = useApp();
  const [items, setItems] = useState<Notif[] | null>(null);
  useEffect(() => {
    api<{ notifications: Notif[] }>("/api/notifications").then(async (r) => {
      setItems(r.notifications);
      if (r.notifications.some((n) => !n.readAt)) await api("/api/notifications", { body: { all: true } }).catch(() => {});
    }).catch(() => setItems([]));
  }, []);
  const icon: Record<string, string> = { friend_request: "userPlus", friend_accept: "users", group_add: "users", warning: "warning", system: "shield" };
  return (
    <Modal title="Уведомления" onClose={onClose} footer={items && items.length ? <button className="btn btn-ghost" onClick={async () => { await api("/api/notifications", { method: "DELETE" }); setItems([]); }}>Очистить всё</button> : undefined}>
      <div className="min-h-[240px] p-2">
        {!items && <div className="grid place-items-center py-10"><Spinner /></div>}
        {items?.length === 0 && <Empty icon="bell" title="Уведомлений нет" />}
        {items?.map((n) => (
          <button key={n.id} onClick={() => {
            if (n.type === "friend_request") setModal({ kind: "friends", tab: "requests" });
            else if (n.type === "group_add" && n.data.chatId) { openChat(n.data.chatId); onClose(); }
            else if (n.type === "friend_accept" && n.data.userId) openDirect(n.data.userId);
          }} className="anim-fade flex w-full items-start gap-3 rounded-xl p-3 text-left hover:bg-panel2">
            <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-white ${n.type === "warning" ? "bg-warn" : "grad"}`}><Icon name={icon[n.type] ?? "bell"} size={18} /></span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2"><span className="truncate font-semibold">{n.title}</span><span className="shrink-0 text-xs text-muted">{fmtShort(n.createdAt)}</span></div>
              <div className="text-sm text-muted">{n.body}</div>
            </div>
            {!n.readAt && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-accent" />}
          </button>
        ))}
      </div>
    </Modal>
  );
}

function FavoritesModal({ onClose }: { onClose: () => void }) {
  const { chats, chatName, openChat } = useApp();
  const toast = useToast();
  const [items, setItems] = useState<MessageDTO[] | null>(null);
  useEffect(() => { api<{ messages: MessageDTO[] }>("/api/favorites").then((r) => setItems(r.messages)).catch(() => setItems([])); }, []);
  return (
    <Modal title="Избранные сообщения" onClose={onClose}>
      <div className="min-h-[240px] p-2">
        {!items && <div className="grid place-items-center py-10"><Spinner /></div>}
        {items?.length === 0 && <Empty icon="star" title="В избранном пусто" text="Нажмите «⋯» на сообщении и выберите «В избранное»." />}
        {items?.map((m) => {
          const c = chats.find((x) => x.id === m.chatId);
          return (
            <div key={m.id} className="anim-fade flex items-start gap-3 rounded-xl p-3 hover:bg-panel2">
              <button className="flex min-w-0 flex-1 items-start gap-3 text-left" onClick={() => { openChat(m.chatId); onClose(); }}>
                <Avatar name={m.sender?.displayName ?? "?"} src={m.sender?.avatarUrl} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between gap-2 text-xs text-muted"><span className="truncate"><b className="text-fg">{m.sender?.displayName}</b> · {c ? chatName(c) : "чат"}</span><span className="shrink-0">{fmtDay(m.createdAt)}, {fmtTime(m.createdAt)}</span></div>
                  <div className="line-clamp-3 break-words text-sm">{previewText(m.type, m.body) || m.attachment?.name}</div>
                </div>
              </button>
              <button className="icon-btn !h-8 !w-8" title="Убрать из избранного" onClick={async () => { try { await api(`/api/messages/${m.id}/favorite`, { body: {} }); setItems((l) => l?.filter((x) => x.id !== m.id) ?? []); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } }}><Icon name="star" size={16} fill className="text-warn" /></button>
            </div>
          );
        })}
      </div>
    </Modal>
  );
}
