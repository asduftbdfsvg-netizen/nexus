"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, applyTheme, beep } from "@/lib/client";
import type { MessageDTO } from "@/lib/chat";
import { AppContext, type ChatDTO, type Modal, type SelfDTO, type ServerEvent } from "./app-context";
import CallLayer, { type CallApi } from "./CallLayer";
import ChatView from "./ChatView";
import InfoPanel from "./InfoPanel";
import Modals from "./Modals";
import Sidebar from "./Sidebar";
import { Icon, ToastProvider, useToast } from "./ui";

export default function Messenger({ initialMe }: { initialMe: SelfDTO }) {
  return (
    <ToastProvider>
      <Shell initialMe={initialMe} />
    </ToastProvider>
  );
}

function Shell({ initialMe }: { initialMe: SelfDTO }) {
  const toast = useToast();
  const [me, setMe] = useState(initialMe);
  const [chats, setChats] = useState<ChatDTO[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [modal, setModal] = useState<Modal>(null);
  const [showInfo, setShowInfo] = useState(false);
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [inCallChatId, setInCallChatId] = useState<string | null>(null);
  const listeners = useRef(new Set<(e: ServerEvent) => void>());
  const callRef = useRef<CallApi>(null);
  const stateRef = useRef({ me, chats, activeId });
  stateRef.current = { me, chats, activeId };

  const subscribe = useCallback((fn: (e: ServerEvent) => void) => {
    listeners.current.add(fn);
    return () => {
      listeners.current.delete(fn);
    };
  }, []);

  const refreshChats = useCallback(async () => {
    try {
      const r = await api<{ chats: ChatDTO[] }>("/api/chats");
      setChats(r.chats);
    } catch {
      /* offline */
    } finally {
      setLoaded(true);
    }
  }, []);

  const refreshTimer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const refreshSoon = useCallback(() => {
    clearTimeout(refreshTimer.current);
    refreshTimer.current = setTimeout(refreshChats, 250);
  }, [refreshChats]);

  const refreshNotifs = useCallback(async () => {
    try {
      const r = await api<{ unread: number }>("/api/notifications");
      setUnreadNotifs(r.unread);
    } catch {
      /* ignore */
    }
  }, []);

  // theme
  const ap = me.settings.appearance;
  useEffect(() => {
    applyTheme(ap);
    if (ap.theme !== "system") return;
    const mq = matchMedia("(prefers-color-scheme: light)");
    const h = () => applyTheme(ap);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, [ap]);

  const chatName = useCallback((c: ChatDTO) => (c.type === "group" ? (c.title ?? "Группа") : (c.peer?.displayName ?? "Удалённый аккаунт")), []);
  const chatAvatar = useCallback((c: ChatDTO) => (c.type === "group" ? c.avatarUrl : (c.peer?.avatarUrl ?? null)), []);

  // realtime
  useEffect(() => {
    refreshChats();
    refreshNotifs();
    const es = new EventSource("/api/events");
    let first = true;
    es.onopen = () => {
      if (!first) {
        refreshChats();
        listeners.current.forEach((fn) => fn({ type: "reconnected" }));
      }
      first = false;
    };
    es.onmessage = async (ev) => {
      let e: ServerEvent;
      try {
        e = JSON.parse(ev.data);
      } catch {
        return;
      }
      const { me: m, chats: cs, activeId: aid } = stateRef.current;
      switch (e.type) {
        case "banned":
          window.location.href = "/login";
          return;
        case "chats":
        case "presence":
        case "friends":
        case "receipt":
          refreshSoon();
          break;
        case "notification": {
          setUnreadNotifs((n) => n + 1);
          const n = e.notification as { title: string; body: string };
          toast(n.body, "info", { title: n.title });
          if (m.settings.notifications.sound && m.status !== "dnd") beep("message");
          break;
        }
        case "message": {
          refreshSoon();
          if (e.senderId === m.id) break;
          const chat = cs.find((c) => c.id === e.chatId);
          if (chat?.muted || m.status === "dnd" || !m.settings.notifications.messages) break;
          const visible = !document.hidden && aid === e.chatId;
          if (visible) break;
          let text = "Новое сообщение";
          let title = chat ? (chat.type === "group" ? (chat.title ?? "Группа") : (chat.peer?.displayName ?? "Сообщение")) : "NEXUS";
          if (m.settings.notifications.preview) {
            try {
              const r = await api<{ message: MessageDTO }>(`/api/messages/${e.messageId}`);
              const msg = r.message;
              const label = msg.type === "image" ? "📷 Фото" : msg.type === "video" ? "🎬 Видео" : msg.type === "file" ? "📎 Файл" : msg.type === "audio" ? "🎵 Аудио" : msg.type === "gif" ? "GIF" : msg.type === "sticker" ? msg.body : msg.body;
              text = (chat?.type === "group" && msg.sender ? `${msg.sender.displayName}: ` : "") + label;
              if (!chat) title = msg.sender?.displayName ?? title;
            } catch {
              /* ignore */
            }
          }
          toast(text, "info", { title, onClick: () => setActiveId(e.chatId as string) });
          if (m.settings.notifications.sound) beep("message");
          if (m.settings.notifications.desktop && document.hidden && "Notification" in window && Notification.permission === "granted") {
            new Notification(title, { body: text });
          }
          break;
        }
      }
      listeners.current.forEach((fn) => fn(e));
    };
    const poll = setInterval(refreshChats, 30_000);
    return () => {
      es.close();
      clearInterval(poll);
    };
  }, [refreshChats, refreshSoon, refreshNotifs, toast]);

  // refresh notification badge when the notifications modal closes
  useEffect(() => {
    if (!modal) refreshNotifs();
  }, [modal, refreshNotifs]);

  const activeChat = useMemo(() => chats.find((c) => c.id === activeId) ?? null, [chats, activeId]);
  const totalUnread = chats.reduce((n, c) => n + (c.muted || c.archived ? 0 : c.unread), 0);
  useEffect(() => {
    document.title = totalUnread ? `(${totalUnread}) NEXUS` : "NEXUS — мессенджер";
  }, [totalUnread]);

  // if the active chat disappears (left / deleted) go back to the list
  useEffect(() => {
    if (loaded && activeId && !chats.some((c) => c.id === activeId)) setActiveId(null);
  }, [loaded, chats, activeId]);

  const openDirect = useCallback(
    async (userId: string) => {
      try {
        const r = await api<{ chat: ChatDTO }>("/api/chats", { body: { type: "direct", userId } });
        await refreshChats();
        setActiveId(r.chat.id);
        setModal(null);
      } catch (e) {
        toast(e instanceof Error ? e.message : "Ошибка", "error");
      }
    },
    [refreshChats, toast],
  );

  const logout = useCallback(async () => {
    await api("/api/auth/logout", { method: "POST" }).catch(() => {});
    window.location.href = "/login";
  }, []);

  const ctx = {
    me, setMe, chats, refreshChats, activeChat,
    openChat: (id: string | null) => { setActiveId(id); },
    openDirect, modal, setModal, subscribe, showInfo, setShowInfo, chatName, chatAvatar,
    startCall: (chatId: string, kind: "voice" | "video") => callRef.current?.start(chatId, kind),
    joinCall: (chatId: string, kind: string) => callRef.current?.joinExisting(chatId, kind),
    inCallChatId, logout,
  };

  return (
    <AppContext.Provider value={ctx}>
      <div className={`flex h-dvh w-full overflow-hidden bg-app ${ap.compact ? "compact-ui" : ""}`}>
        <aside className={`${activeId ? "hidden md:flex" : "flex"} w-full shrink-0 flex-col border-r border-line bg-panel md:w-[340px] lg:w-[380px]`}>
          <Sidebar loaded={loaded} unreadNotifs={unreadNotifs} />
        </aside>
        <main className={`${activeId ? "flex" : "hidden md:flex"} min-w-0 flex-1`}>
          {activeChat ? (
            <ChatView key={activeChat.id} chat={activeChat} />
          ) : (
            <Welcome />
          )}
        </main>
        {activeChat && showInfo && (
          <>
            <div className="fixed inset-0 z-30 bg-black/40 xl:hidden" onClick={() => setShowInfo(false)} />
            <InfoPanel key={`info-${activeChat.id}`} chat={activeChat} />
          </>
        )}
      </div>
      <Modals />
      <CallLayer ref={callRef} me={me} chats={chats} subscribe={subscribe} onActive={setInCallChatId} />
    </AppContext.Provider>
  );
}

function Welcome() {
  return (
    <div className="anim-fade relative grid w-full place-items-center overflow-hidden p-6 text-center">
      <div className="absolute left-1/2 top-1/3 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full opacity-25 blur-3xl grad" />
      <div className="relative">
        <div className="grad mx-auto grid h-20 w-20 place-items-center rounded-3xl text-4xl font-black text-white" style={{ boxShadow: "0 20px 50px color-mix(in srgb, var(--accent) 40%, transparent)" }}>N</div>
        <h2 className="mt-6 text-2xl font-extrabold">Добро пожаловать в NEXUS</h2>
        <p className="mx-auto mt-2 max-w-sm text-muted">Выберите чат слева или найдите человека по никнейму, чтобы начать общение.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm text-muted">
          {[["send", "Сообщения в реальном времени"], ["video", "Видеозвонки"], ["users", "Группы"]].map(([i, t]) => (
            <span key={t} className="flex items-center gap-2 rounded-full bg-panel px-3 py-1.5"><Icon name={i} size={15} />{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
