"use client";

import { useCallback, useEffect, useImperativeHandle, useRef, useState, type Ref } from "react";
import { api, beep } from "@/lib/client";
import type { ChatDTO, SelfDTO, ServerEvent } from "./app-context";
import { Avatar, Icon, useToast } from "./ui";

export type CallApi = {
  start: (chatId: string, kind: "voice" | "video") => void;
  joinExisting: (chatId: string, kind: string) => void;
};

type MediaState = { mic: boolean; cam: boolean; screenId: string | null };
type Peer = {
  id: string;
  name: string;
  avatarUrl: string | null;
  pc: RTCPeerConnection;
  streams: MediaStream[];
  state: MediaState;
  polite: boolean;
  makingOffer: boolean;
  ignoreOffer: boolean;
  queue: Promise<void>;
  screenSenders: RTCRtpSender[];
};
type Active = { callId: string; chatId: string; kind: string; title: string; isGroup: boolean };
type Incoming = { id: string; chatId: string; kind: string; isGroup: boolean; chatTitle: string | null; from: { id: string; name: string; avatarUrl: string | null } };
type CallInfo = { id: string; chatId: string; kind: string; isGroup: boolean; title: string | null };
type Person = { id: string; displayName: string; avatarUrl: string | null };

const ICE: RTCConfiguration = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    ...(process.env.NEXT_PUBLIC_TURN_URL
      ? [{ urls: process.env.NEXT_PUBLIC_TURN_URL, username: process.env.NEXT_PUBLIC_TURN_USERNAME, credential: process.env.NEXT_PUBLIC_TURN_CREDENTIAL }]
      : []),
  ],
};

function StreamEl({ stream, muted = false, mirror = false, kind }: { stream: MediaStream | null; muted?: boolean; mirror?: boolean; kind: "video" | "audio" }) {
  const ref = useRef<HTMLVideoElement & HTMLAudioElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream;
  }, [stream]);
  if (kind === "audio") return <audio ref={ref} autoPlay muted={muted} />;
  return <video ref={ref} autoPlay playsInline muted={muted} className={`h-full w-full object-cover ${mirror ? "-scale-x-100" : ""}`} />;
}

export default function CallLayer({
  ref, me, chats, subscribe, onActive,
}: {
  ref?: Ref<CallApi>;
  me: SelfDTO;
  chats: ChatDTO[];
  subscribe: (fn: (e: ServerEvent) => void) => () => void;
  onActive: (chatId: string | null) => void;
}) {
  const toast = useToast();
  const [active, setActive] = useState<Active | null>(null);
  const [incoming, setIncoming] = useState<Incoming | null>(null);
  const [, setTick] = useState(0);
  const tick = useCallback(() => setTick((n) => n + 1), []);
  const [mic, setMic] = useState(true);
  const [cam, setCam] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [busy, setBusy] = useState(false);

  const activeRef = useRef<Active | null>(null);
  const peers = useRef(new Map<string, Peer>());
  const known = useRef(new Map<string, Person>());
  const local = useRef<MediaStream | null>(null);
  const screen = useRef<MediaStream | null>(null);
  const noAnswer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const ringTimer = useRef<ReturnType<typeof setInterval>>(undefined);
  const incomingRef = useRef<Incoming | null>(null);
  const chatsRef = useRef(chats);
  chatsRef.current = chats;
  activeRef.current = active;
  incomingRef.current = incoming;

  const myState = useCallback((): MediaState => {
    const a = local.current?.getAudioTracks()[0];
    const v = local.current?.getVideoTracks()[0];
    return { mic: !!a && a.enabled, cam: !!v && v.enabled && v.readyState === "live", screenId: screen.current?.id ?? null };
  }, []);

  const signal = useCallback((to: string, data: unknown) => {
    const a = activeRef.current;
    if (!a) return;
    api(`/api/calls/${a.callId}/signal`, { body: { to, data } }).catch(() => {});
  }, []);

  const broadcastState = useCallback(() => {
    const st = myState();
    peers.current.forEach((p) => signal(p.id, { state: st }));
  }, [myState, signal]);

  const createPeer = useCallback(
    (id: string): Peer => {
      const existing = peers.current.get(id);
      if (existing) return existing;
      const info = known.current.get(id);
      const pc = new RTCPeerConnection(ICE);
      const peer: Peer = {
        id, name: info?.displayName ?? "Участник", avatarUrl: info?.avatarUrl ?? null, pc, streams: [],
        state: { mic: true, cam: false, screenId: null }, polite: me.id > id, makingOffer: false, ignoreOffer: false,
        queue: Promise.resolve(), screenSenders: [],
      };
      const ls = local.current;
      if (ls) ls.getTracks().forEach((t) => pc.addTrack(t, ls));
      if (!ls || ls.getAudioTracks().length === 0) pc.addTransceiver("audio", { direction: "recvonly" });
      const ss = screen.current;
      if (ss) ss.getTracks().forEach((t) => peer.screenSenders.push(pc.addTrack(t, ss)));

      pc.onicecandidate = (e) => { if (e.candidate) signal(id, { candidate: e.candidate.toJSON() }); };
      pc.ontrack = (e) => {
        const s = e.streams[0];
        if (!s) return;
        if (!peer.streams.includes(s)) peer.streams.push(s);
        s.onremovetrack = () => {
          if (s.getTracks().length === 0) peer.streams = peer.streams.filter((x) => x !== s);
          tick();
        };
        tick();
      };
      pc.onnegotiationneeded = async () => {
        try {
          peer.makingOffer = true;
          await pc.setLocalDescription();
          signal(id, { description: pc.localDescription });
        } catch (err) {
          console.warn("negotiation", err);
        } finally {
          peer.makingOffer = false;
        }
      };
      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === "failed") pc.restartIce();
        tick();
      };
      pc.onconnectionstatechange = tick;
      peers.current.set(id, peer);
      signal(id, { state: myState() });
      tick();
      return peer;
    },
    [me.id, signal, tick, myState],
  );

  const removePeer = useCallback((id: string) => {
    const p = peers.current.get(id);
    if (!p) return;
    try { p.pc.close(); } catch { /* ignore */ }
    peers.current.delete(id);
    tick();
  }, [tick]);

  const cleanup = useCallback(() => {
    clearTimeout(noAnswer.current);
    peers.current.forEach((p) => { try { p.pc.close(); } catch { /* ignore */ } });
    peers.current.clear();
    local.current?.getTracks().forEach((t) => t.stop());
    screen.current?.getTracks().forEach((t) => t.stop());
    local.current = null;
    screen.current = null;
    activeRef.current = null;
    setActive(null);
    setSharing(false);
    setCam(false);
    setMic(true);
    setElapsed(0);
    onActive(null);
  }, [onActive]);

  const hangup = useCallback(async (silent = false) => {
    const a = activeRef.current;
    cleanup();
    if (a) await api(`/api/calls/${a.callId}/leave`, { method: "POST", body: {} }).catch(() => {});
    if (!silent && a) toast("Звонок завершён", "info");
  }, [cleanup, toast]);

  async function getLocalMedia(kind: string): Promise<MediaStream | null> {
    if (!navigator.mediaDevices?.getUserMedia) {
      toast("Звонки требуют HTTPS или localhost. Вы будете только слушать.", "error");
      return null;
    }
    try {
      return await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: kind === "video" });
    } catch {
      if (kind === "video") {
        try {
          const s = await navigator.mediaDevices.getUserMedia({ audio: true });
          toast("Камера недоступна — звонок только с голосом", "info");
          return s;
        } catch { /* fallthrough */ }
      }
      toast("Нет доступа к микрофону — вы будете только слушать", "error");
      return null;
    }
  }

  const enter = useCallback((call: CallInfo, participants: Person[], stream: MediaStream | null) => {
    local.current = stream;
    const a: Active = { callId: call.id, chatId: call.chatId, kind: call.kind, title: call.title ?? "Звонок", isGroup: call.isGroup };
    activeRef.current = a;
    participants.forEach((p) => known.current.set(p.id, p));
    setActive(a);
    onActive(call.chatId);
    setMic(!!stream?.getAudioTracks().length);
    setCam(!!stream?.getVideoTracks().length);
    setElapsed(0);
    participants.forEach((p) => createPeer(p.id));
    if (!call.isGroup) {
      clearTimeout(noAnswer.current);
      noAnswer.current = setTimeout(() => {
        if (activeRef.current?.callId === call.id && peers.current.size === 0) {
          toast("Нет ответа", "info");
          hangup(true);
        }
      }, 45_000);
    }
  }, [createPeer, hangup, onActive, toast]);

  const startOrJoin = useCallback(async (chatId: string, kind: string) => {
    if (activeRef.current) return toast("Вы уже участвуете в звонке", "info");
    if (busy) return;
    setBusy(true);
    const stream = await getLocalMedia(kind);
    try {
      const r = await api<{ call: CallInfo; participants: Person[] }>("/api/calls", { body: { chatId, kind: kind === "video" ? "video" : "voice" } });
      enter(r.call, r.participants, stream);
    } catch (e) {
      stream?.getTracks().forEach((t) => t.stop());
      toast(e instanceof Error ? e.message : "Не удалось начать звонок", "error");
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busy, enter, toast]);

  useImperativeHandle(ref, () => ({
    start: (chatId, kind) => { startOrJoin(chatId, kind); },
    joinExisting: (chatId, kind) => { startOrJoin(chatId, kind); },
  }), [startOrJoin]);

  async function acceptIncoming() {
    const inc = incomingRef.current;
    if (!inc) return;
    stopRing();
    setIncoming(null);
    if (activeRef.current) return;
    const stream = await getLocalMedia(inc.kind);
    try {
      const r = await api<{ call: CallInfo; participants: Person[] }>(`/api/calls/${inc.id}/join`, { body: {} });
      enter(r.call, r.participants, stream);
    } catch (e) {
      stream?.getTracks().forEach((t) => t.stop());
      toast(e instanceof Error ? e.message : "Звонок уже завершён", "error");
    }
  }

  function stopRing() {
    clearInterval(ringTimer.current);
  }

  const handleSignal = useCallback((from: string, data: { description?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit; state?: MediaState }) => {
    const peer = createPeer(from);
    if (data.state) { peer.state = data.state; tick(); return; }
    peer.queue = peer.queue.then(async () => {
      const pc = peer.pc;
      try {
        if (data.description) {
          const collision = data.description.type === "offer" && (peer.makingOffer || pc.signalingState !== "stable");
          peer.ignoreOffer = !peer.polite && collision;
          if (peer.ignoreOffer) return;
          await pc.setRemoteDescription(data.description);
          if (data.description.type === "offer") {
            await pc.setLocalDescription();
            signal(from, { description: pc.localDescription });
          }
        } else if (data.candidate) {
          try { await pc.addIceCandidate(data.candidate); } catch (err) { if (!peer.ignoreOffer) console.warn("ice", err); }
        }
      } catch (err) {
        console.warn("signal", err);
      }
    });
  }, [createPeer, signal, tick]);

  // server events
  useEffect(() => subscribe((e) => {
    const a = activeRef.current;
    switch (e.type) {
      case "call-incoming": {
        const call = e.call as Incoming;
        if (activeRef.current || incomingRef.current) return;
        setIncoming(call);
        if (me.status !== "dnd") {
          beep("ring");
          clearInterval(ringTimer.current);
          ringTimer.current = setInterval(() => beep("ring"), 2200);
        }
        setTimeout(() => { if (incomingRef.current?.id === call.id) { stopRing(); setIncoming(null); } }, 45_000);
        break;
      }
      case "call-ended":
        if (incomingRef.current?.id === e.callId) { stopRing(); setIncoming(null); }
        break;
      case "call-joined":
        if (a && a.callId === e.callId) {
          known.current.set(e.userId as string, { id: e.userId as string, displayName: e.name as string, avatarUrl: null });
          createPeer(e.userId as string);
          clearTimeout(noAnswer.current);
        }
        break;
      case "call-left":
        if (a && a.callId === e.callId) {
          removePeer(e.userId as string);
          if (!a.isGroup) { toast("Собеседник завершил звонок", "info"); hangup(true); }
        }
        break;
      case "signal":
        if (a && a.callId === e.callId) handleSignal(e.from as string, e.data as Parameters<typeof handleSignal>[1]);
        break;
    }
  }), [subscribe, createPeer, removePeer, handleSignal, hangup, toast, me.status]);

  // timer
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => setElapsed((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, [active]);

  // leave on tab close
  useEffect(() => {
    const h = () => { const a = activeRef.current; if (a) navigator.sendBeacon(`/api/calls/${a.callId}/leave`, new Blob(["{}"], { type: "application/json" })); };
    window.addEventListener("pagehide", h);
    return () => window.removeEventListener("pagehide", h);
  }, []);
  useEffect(() => () => { clearInterval(ringTimer.current); clearTimeout(noAnswer.current); }, []);

  function toggleMic() {
    const t = local.current?.getAudioTracks()[0];
    if (!t) return toast("Микрофон недоступен", "error");
    t.enabled = !t.enabled;
    setMic(t.enabled);
    broadcastState();
  }

  async function toggleCam() {
    const v = local.current?.getVideoTracks()[0];
    if (v) {
      v.enabled = !v.enabled;
      setCam(v.enabled);
      broadcastState();
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      const track = s.getVideoTracks()[0];
      if (!local.current) local.current = new MediaStream();
      local.current.addTrack(track);
      peers.current.forEach((p) => p.pc.addTrack(track, local.current!));
      setCam(true);
      broadcastState();
      tick();
    } catch {
      toast("Нет доступа к камере", "error");
    }
  }

  async function toggleScreen() {
    if (screen.current) return stopScreen();
    if (!navigator.mediaDevices?.getDisplayMedia) return toast("Демонстрация экрана не поддерживается этим браузером", "error");
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      screen.current = s;
      s.getVideoTracks()[0].onended = () => stopScreen();
      peers.current.forEach((p) => s.getTracks().forEach((t) => p.screenSenders.push(p.pc.addTrack(t, s))));
      setSharing(true);
      broadcastState();
      tick();
    } catch {
      /* user cancelled */
    }
  }

  function stopScreen() {
    const s = screen.current;
    if (!s) return;
    s.getTracks().forEach((t) => t.stop());
    peers.current.forEach((p) => {
      p.screenSenders.forEach((snd) => { try { p.pc.removeTrack(snd); } catch { /* ignore */ } });
      p.screenSenders = [];
    });
    screen.current = null;
    setSharing(false);
    broadcastState();
    tick();
  }

  /* ---------------- UI ---------------- */
  const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const peerList = [...peers.current.values()];

  type Tile = { key: string; name: string; avatarUrl: string | null; stream: MediaStream | null; micOn: boolean; label?: string; local?: boolean; video: boolean };
  const tiles: Tile[] = [];
  for (const p of peerList) {
    const main = p.streams.find((s) => s.id !== p.state.screenId) ?? null;
    const scr = p.streams.find((s) => s.id === p.state.screenId) ?? null;
    const hasVideo = !!main && p.state.cam && main.getVideoTracks().length > 0;
    tiles.push({ key: p.id, name: p.name, avatarUrl: p.avatarUrl, stream: main, micOn: p.state.mic, video: hasVideo });
    if (scr) tiles.push({ key: `${p.id}-screen`, name: p.name, avatarUrl: p.avatarUrl, stream: scr, micOn: true, label: "Экран", video: true });
  }
  const remoteTiles = tiles.length;
  const myTile: Tile = { key: "me", name: "Вы", avatarUrl: me.avatarUrl, stream: local.current, micOn: mic, local: true, video: cam && !!local.current?.getVideoTracks().length };
  const connected = peerList.some((p) => ["connected", "completed"].includes(p.pc.iceConnectionState));

  const renderTile = (t: Tile, big = false) => (
    <div key={t.key} className={`anim-pop relative overflow-hidden rounded-2xl bg-[#11131c] ${big ? "h-full w-full" : "aspect-video"}`}>
      {t.video ? (
        <StreamEl stream={t.stream} muted={!!t.local} mirror={!!t.local && !t.label} kind="video" />
      ) : (
        <div className="grid h-full w-full place-items-center">
          <Avatar name={t.name} src={t.avatarUrl} size={big ? 120 : 72} />
        </div>
      )}
      {!t.local && t.stream && <StreamEl stream={t.stream} kind="audio" />}
      <div className="absolute bottom-2 left-2 flex items-center gap-1.5 rounded-full bg-black/60 px-2.5 py-1 text-xs font-semibold backdrop-blur">
        {!t.micOn && <Icon name="micOff" size={13} className="text-danger" />}
        {t.name}{t.label ? ` · ${t.label}` : ""}
      </div>
    </div>
  );

  return (
    <>
      {incoming && !active && (
        <div className="anim-pop fixed left-1/2 top-4 z-[95] w-[min(92vw,380px)] -translate-x-1/2 rounded-3xl border border-line bg-panel p-5 text-center" style={{ boxShadow: "var(--shadow)" }}>
          <div className="relative mx-auto mb-3 w-fit rounded-full anim-ring"><Avatar name={incoming.from.name} src={incoming.from.avatarUrl} size={72} /></div>
          <div className="text-lg font-bold">{incoming.isGroup ? (incoming.chatTitle ?? "Группа") : incoming.from.name}</div>
          <div className="mb-4 text-sm text-muted">
            {incoming.isGroup ? `${incoming.from.name} начал(а) ${incoming.kind === "video" ? "видеозвонок" : "голосовой звонок"}` : incoming.kind === "video" ? "Входящий видеозвонок…" : "Входящий голосовой звонок…"}
          </div>
          <div className="flex justify-center gap-6">
            <button onClick={() => { stopRing(); setIncoming(null); }} className="grid h-14 w-14 place-items-center rounded-full bg-danger text-white transition hover:scale-110" aria-label="Отклонить"><Icon name="phoneOff" size={24} /></button>
            <button onClick={acceptIncoming} className="grid h-14 w-14 place-items-center rounded-full bg-ok text-white transition hover:scale-110" aria-label="Принять"><Icon name={incoming.kind === "video" ? "video" : "phone"} size={24} /></button>
          </div>
        </div>
      )}

      {active && (
        <div className="anim-fade fixed inset-0 z-[80] flex flex-col bg-[#05060a] text-white">
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="min-w-0 flex-1">
              <div className="truncate text-lg font-bold">{active.title}</div>
              <div className="text-xs text-white/60">
                {active.isGroup ? "Групповой звонок · " : ""}{peerList.length === 0 ? "Вызов…" : connected ? fmt(elapsed) : "Соединение…"} · {peerList.length + 1} в звонке
              </div>
            </div>
            <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold">{active.kind === "video" ? "Видео" : "Голос"}</span>
          </div>

          <div className="relative min-h-0 flex-1 p-3">
            {remoteTiles === 0 ? (
              <div className="grid h-full place-items-center">
                <div className="text-center">
                  <div className="anim-ring mx-auto w-fit rounded-full"><Avatar name={active.title} src={chatsRef.current.find((c) => c.id === active.chatId)?.peer?.avatarUrl ?? chatsRef.current.find((c) => c.id === active.chatId)?.avatarUrl} size={110} /></div>
                  <div className="mt-5 text-white/70">{active.isGroup ? "Ждём участников…" : "Ожидание ответа…"}</div>
                </div>
              </div>
            ) : remoteTiles === 1 ? (
              <>
                {renderTile(tiles[0], true)}
                <div className="absolute bottom-6 right-6 w-36 sm:w-52">{renderTile(myTile)}</div>
              </>
            ) : (
              <div className={`grid h-full auto-rows-fr content-center gap-3 ${remoteTiles + 1 <= 4 ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-2 lg:grid-cols-3"}`}>
                {[...tiles, myTile].map((t) => renderTile(t))}
              </div>
            )}
            {remoteTiles === 0 && myTile.video && <div className="absolute bottom-6 right-6 w-36 sm:w-52">{renderTile(myTile)}</div>}
          </div>

          <div className="flex items-center justify-center gap-3 px-4 pb-6 pt-2 sm:gap-4">
            <CtrlBtn on={mic} onClick={toggleMic} icon={mic ? "mic" : "micOff"} label={mic ? "Микрофон" : "Включить"} />
            <CtrlBtn on={cam} onClick={toggleCam} icon={cam ? "video" : "videoOff"} label={cam ? "Камера" : "Включить"} />
            <CtrlBtn on={!sharing} accent={sharing} onClick={toggleScreen} icon="screen" label={sharing ? "Остановить" : "Экран"} />
            <button onClick={() => hangup()} className="grid h-14 w-14 place-items-center rounded-full bg-danger transition hover:scale-110" aria-label="Завершить"><Icon name="phoneOff" size={24} /></button>
          </div>
        </div>
      )}
    </>
  );
}

function CtrlBtn({ on, accent, onClick, icon, label }: { on: boolean; accent?: boolean; onClick: () => void; icon: string; label: string }) {
  return (
    <button onClick={onClick} title={label} className="flex flex-col items-center gap-1.5">
      <span className={`grid h-14 w-14 place-items-center rounded-full transition hover:scale-110 ${accent ? "grad" : on ? "bg-white/15" : "bg-white text-black"}`}><Icon name={icon} size={22} /></span>
      <span className="text-[11px] text-white/70">{label}</span>
    </button>
  );
}
