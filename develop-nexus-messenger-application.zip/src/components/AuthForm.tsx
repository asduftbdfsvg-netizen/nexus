"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { api } from "@/lib/client";
import { Icon, Spinner } from "./ui";

type Mode = "login" | "register" | "forgot" | "reset";

const TITLES: Record<Mode, [string, string]> = {
  login: ["С возвращением", "Войдите, чтобы продолжить общение"],
  register: ["Создайте аккаунт", "Присоединяйтесь к NEXUS за минуту"],
  forgot: ["Восстановление пароля", "Укажите email — мы отправим ссылку для сброса"],
  reset: ["Новый пароль", "Придумайте надёжный пароль для аккаунта"],
};

export default function AuthForm({ mode, token }: { mode: Mode; token?: string }) {
  const [f, setF] = useState({ login: "", email: "", password: "", username: "", displayName: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [rules, setRules] = useState<{ rules: string; registrationOpen: boolean } | null>(null);
  const [accepted, setAccepted] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }));

  useEffect(() => {
    if (mode === "register") api<{ rules: string; registrationOpen: boolean }>("/api/rules").then(setRules).catch(() => {});
  }, [mode]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");
    if (mode === "register" && !accepted) return setError("Примите правила платформы");
    setBusy(true);
    try {
      if (mode === "login") {
        await api("/api/auth/login", { body: { login: f.login, password: f.password } });
        window.location.href = "/";
      } else if (mode === "register") {
        await api("/api/auth/register", { body: { email: f.email, password: f.password, username: f.username, displayName: f.displayName } });
        window.location.href = "/";
      } else if (mode === "forgot") {
        const r = await api<{ delivery: string }>("/api/auth/forgot", { body: { email: f.email } });
        setInfo(
          r.delivery === "email"
            ? "Если такой аккаунт существует, мы отправили письмо со ссылкой для сброса пароля."
            : "Если такой аккаунт существует, ссылка создана. Почтовый сервис на сервере не настроен — получите ссылку у администратора платформы (он может сгенерировать её в админ-панели).",
        );
      } else {
        await api("/api/auth/reset", { body: { token, password: f.password } });
        setInfo("Пароль изменён. Теперь можно войти.");
        setTimeout(() => (window.location.href = "/login"), 1500);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка");
    } finally {
      setBusy(false);
    }
  }

  const [title, sub] = TITLES[mode];
  return (
    <div className="page-scroll">
      <div className="grid min-h-full lg:grid-cols-[1.05fr_1fr]">
        <aside className="relative hidden overflow-hidden p-12 lg:flex lg:flex-col lg:justify-between" style={{ background: "linear-gradient(145deg, var(--accent), var(--accent2))" }}>
          <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-black/20 blur-3xl" />
          <div className="relative flex items-center gap-3 text-white">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/20 text-xl font-black backdrop-blur">N</div>
            <span className="text-2xl font-extrabold tracking-wide">NEXUS</span>
          </div>
          <div className="relative text-white">
            <h1 className="text-4xl font-extrabold leading-tight">Общайтесь быстро,<br />красиво и безопасно</h1>
            <ul className="mt-8 space-y-4 text-white/90">
              {[
                ["send", "Мгновенные сообщения, реакции, ответы и пересылка"],
                ["video", "Голосовые и видеозвонки, демонстрация экрана"],
                ["users", "Группы, голосовые комнаты и роли участников"],
                ["lock", "Приватность и полный контроль над аккаунтом"],
              ].map(([i, t]) => (
                <li key={t} className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/20"><Icon name={i} size={18} /></span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="relative text-sm text-white/70">© NEXUS Messenger</div>
        </aside>

        <main className="grid place-items-center p-5 sm:p-10">
          <form onSubmit={submit} className="anim-up w-full max-w-md">
            <div className="mb-8 flex items-center gap-3 lg:hidden">
              <div className="grad grid h-10 w-10 place-items-center rounded-2xl text-lg font-black text-white">N</div>
              <span className="text-xl font-extrabold tracking-wide">NEXUS</span>
            </div>
            <h2 className="text-3xl font-extrabold">{title}</h2>
            <p className="mb-7 mt-2 text-muted">{sub}</p>

            <div className="space-y-4">
              {mode === "login" && (
                <div>
                  <label className="label">Email или никнейм</label>
                  <input className="input" autoComplete="username" value={f.login} onChange={set("login")} required autoFocus />
                </div>
              )}
              {mode === "register" && (
                <>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="label">Имя</label>
                      <input className="input" value={f.displayName} onChange={set("displayName")} maxLength={50} required />
                    </div>
                    <div>
                      <label className="label">Никнейм</label>
                      <input className="input" value={f.username} onChange={set("username")} placeholder="nick_name" maxLength={24} required />
                    </div>
                  </div>
                </>
              )}
              {(mode === "register" || mode === "forgot") && (
                <div>
                  <label className="label">Email</label>
                  <input className="input" type="email" autoComplete="email" value={f.email} onChange={set("email")} required />
                </div>
              )}
              {mode !== "forgot" && (
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label">{mode === "reset" ? "Новый пароль" : "Пароль"}</label>
                    {mode === "login" && <Link href="/forgot" className="mb-1 text-xs font-semibold text-accent hover:underline">Забыли пароль?</Link>}
                  </div>
                  <input className="input" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={f.password} onChange={set("password")} minLength={mode === "login" ? 1 : 8} required />
                  {mode !== "login" && <p className="mt-1 text-xs text-muted">Минимум 8 символов</p>}
                </div>
              )}
              {mode === "register" && (
                <div className="text-sm">
                  <label className="flex cursor-pointer items-start gap-2">
                    <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-1 accent-[var(--accent)]" />
                    <span>
                      Я принимаю{" "}
                      <button type="button" className="font-semibold text-accent hover:underline" onClick={() => setShowRules((v) => !v)}>
                        правила платформы
                      </button>
                    </span>
                  </label>
                  {showRules && rules && <pre className="anim-fade mt-2 max-h-40 overflow-auto whitespace-pre-wrap rounded-xl bg-panel2 p-3 font-sans text-xs text-muted">{rules.rules}</pre>}
                  {rules && !rules.registrationOpen && <p className="mt-2 text-danger">Регистрация временно закрыта администрацией.</p>}
                </div>
              )}
            </div>

            {error && <div className="anim-pop mt-4 rounded-xl bg-danger/15 px-4 py-3 text-sm text-danger">{error}</div>}
            {info && <div className="anim-pop mt-4 rounded-xl bg-ok/15 px-4 py-3 text-sm text-ok">{info}</div>}

            <button className="btn btn-primary mt-6 w-full py-3 text-base" disabled={busy}>
              {busy ? <Spinner size={18} /> : mode === "login" ? "Войти" : mode === "register" ? "Создать аккаунт" : mode === "forgot" ? "Отправить ссылку" : "Сохранить пароль"}
            </button>

            <p className="mt-6 text-center text-sm text-muted">
              {mode === "login" ? (
                <>Нет аккаунта? <Link href="/register" className="font-semibold text-accent hover:underline">Зарегистрироваться</Link></>
              ) : (
                <>Уже есть аккаунт? <Link href="/login" className="font-semibold text-accent hover:underline">Войти</Link></>
              )}
            </p>
          </form>
        </main>
      </div>
    </div>
  );
}
