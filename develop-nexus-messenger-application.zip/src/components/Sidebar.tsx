"use client";

import { useEffect, useMemo, useState } from "react";
import { api, fmtShort } from "@/lib/client";
import type { UserDTO } from "@/lib/chat";
import { useApp, type ChatDTO } from "./app-context";
import { Avatar, Empty, Icon, Spinner, useClickOutside, useToast } from "./ui";

export function previewText(type: string, body: string, deleted = false) {
  if (deleted) return "Сообщение удалено";
  switch (type) {
    case "image": return "📷 Фото";
    case "video": return "🎬 Видео";
    case "audio": return "🎵 Аудио";
    case "file": return "📎 Файл";
    case "gif": return "GIF";
    case "sticker": return `${body} Стикер`;
    default: return body;
  }
}

const STATUSES = [
  { id: "online", label: "В сети", color: "bg-ok" },
  { id: "away", label: "Отошёл", color: "bg-warn" },
  { id: "dnd", label: "Не беспокоить", color: "bg-danger" },
  { id: "invisible", label: "Невидимка", color: "bg-muted" },
];

type Tab = "all" | "direct" | "group" | "archive";

export default function Sidebar({ loaded, unreadNotifs }: { loaded: boolean; unreadNotifs: number }) {
  const { me, setMe, chats, activeChat, openChat, openDirect, setModal, chatName, chatAvatar, refreshChats, logout } = useApp();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<Tab>("all");
  const [people, setPeople] = useState<(UserDTO & { relation: string })[]>([]);
  const [searching, setSearching] = useState(false);
  const [menu, setMenu] = useState(false);
  const menuRef = useClickOutside<HTMLDivElement>(() => setMenu(false));

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) {
      setPeople([]);
      return;
    }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const r = await api<{ users: (UserDTO & { relation: string })[] }>(`/api/users/search?q=${encodeURIComponent(term)}`);
        setPeople(r.users);
      } catch {
        setPeople([]);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [q]);

  const archivedCount = chats.filter((c) => c.archived).length;
  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    return chats.filter((c) => {
      if (tab === "archive" ? !c.archived : c.archived) return false;
      if (tab === "direct" && c.type !== "direct") return false;
      if (tab === "group" && c.type !== "group") return false;
      if (!term) return true;
      return chatName(c).toLowerCase().includes(term) || (c.peer?.username ?? "").includes(term.replace(/^@/, ""));
    });
  }, [chats, tab, q, chatName]);

  async function setStatus(status: string) {
    setMenu(false);
    try {
      const u = await api<typeof me>("/api/me", { method: "PATCH", body: { status } });
      setMe(u);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  async function patchChat(c: ChatDTO, patch: Record<string, boolean>, e: React.MouseEvent) {
    e.stopPropagation();
    try {
      await api(`/api/chats/${c.id}`, { method: "PATCH", body: patch });
      await refreshChats();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Ошибка", "error");
    }
  }

  async function addFriend(u: UserDTO, e: React.MouseEvent) {
    e.stopPropagation();
    try {
      const r = await api<{ status: string }>("/api/friends", { body: { userId: u.id } });
      toast(r.status === "accepted" ? `Вы теперь друзья с ${u.displayName}` : "Заявка отправлена", "success");
      setPeople((l) => l.map((p) => (p.id === u.id ? { ...p, relation: r.status === "accepted" ? "friend" : "outgoing" } : p)));
    } catch (err) {
      toast(err instanceof Error ? err.message : "Ошибка", "error");
    }
  }

  const cur = STATUSES.find((s) => s.id === me.status) ?? STATUSES[0];
  const tabs: [Tab, string][] = [["all", "Все"], ["direct", "Личные"], ["group", "Группы"], ["archive", `Архив${archivedCount ? ` ${archivedCount}` : ""}`]];

  return (
    <>
      {/* header */}
      <div className="flex items-center gap-2 px-4 pb-2 pt-4">
        <div className="relative" ref={menuRef}>
          <button onClick={() => setMenu((v) => !v)} className="flex items-center gap-2 rounded-xl p-1 transition hover:bg-panel2" aria-label="Профиль">
            <div className="relative">
              <Avatar name={me.displayName} src={me.avatarUrl} size={40} />
              <span className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-panel ${cur.color}`} />
            </div>
          </button>
          {menu && (
            <div className="anim-pop absolute left-0 top-12 z-40 w-64 overflow-hidden rounded-2xl border border-line bg-panel" style={{ boxShadow: "var(--shadow)" }}>
              <div className="border-b border-line p-4">
                <div className="truncate font-bold">{me.displayName}</div>
                <div className="truncate text-sm text-muted">@{me.username}</div>
              </div>
              <div className="p-1.5">
                {STATUSES.map((s) => (
                  <button key={s.id} onClick={() => setStatus(s.id)} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm hover:bg-panel2">
                    <span className={`h-2.5 w-2.5 rounded-full ${s.color}`} />
                    <span className="flex-1 text-left">{s.label}</span>
                    {me.status === s.id && <Icon name="check" size={16} className="text-accent" />}
                  </button>
                ))}
              </div>
              <div className="border-t border-line p-1.5">
                <button onClick={() => { setMenu(false); setModal({ kind: "settings" }); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm hover:bg-panel2"><Icon name="settings" size={17} />Настройки</button>
                {me.role === "admin" && (
                  <a href="/admin" className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm hover:bg-panel2"><Icon name="shield" size={17} />Админ-панель</a>
                )}
                <button onClick={logout} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-danger hover:bg-danger/10"><Icon name="logout" size={17} />Выйти</button>
              </div>
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1 px-1">
          <div className="grad-text text-lg font-extrabold leading-tight tracking-wide">NEXUS</div>
        </div>
        <button className="icon-btn" title="Избранное" onClick={() => setModal({ kind: "favorites" })}><Icon name="star" size={19} /></button>
        <button className="icon-btn relative" title="Уведомления" onClick={() => setModal({ kind: "notifications" })}>
          <Icon name="bell" size={19} />
          {unreadNotifs > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">{unreadNotifs > 9 ? "9+" : unreadNotifs}</span>}
        </button>
        <button className="icon-btn" title="Друзья и поиск людей" onClick={() => setModal({ kind: "friends" })}><Icon name="userPlus" size={19} /></button>
        <button className="icon-btn" title="Новая группа" onClick={() => setModal({ kind: "newGroup" })}><Icon name="users" size={19} /></button>
      </div>

      {/* search */}
      <div className="px-4 pb-2">
        <div className="relative">
          <Icon name="search" size={17} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input className="input !rounded-xl !pl-10" placeholder="Поиск чатов и людей…" value={q} onChange={(e) => setQ(e.target.value)} />
          {q && <button className="absolute right-2 top-1/2 -translate-y-1/2 text-muted hover:text-fg" onClick={() => setQ("")}><Icon name="x" size={16} /></button>}
        </div>
      </div>

      {/* tabs */}
      <div className="flex gap-1 overflow-x-auto px-4 pb-2">
        {tabs.map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${tab === id ? "grad text-white" : "bg-panel2 text-muted hover:text-fg"}`}>{label}</button>
        ))}
      </div>

      {/* list */}
      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-3">
        {!loaded && Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 p-3"><div className="skeleton h-12 w-12 rounded-full" /><div className="flex-1 space-y-2"><div className="skeleton h-3 w-1/2 rounded" /><div className="skeleton h-3 w-3/4 rounded" /></div></div>
        ))}
        {loaded && list.map((c) => {
          const active = activeChat?.id === c.id;
          const lm = c.lastMessage;
          const mine = lm?.senderId === me.id;
          return (
            <div
              key={c.id}
              role="button"
              tabIndex={0}
              onClick={() => openChat(c.id)}
              onKeyDown={(e) => e.key === "Enter" && openChat(c.id)}
              className={`group relative mb-0.5 flex cursor-pointer items-center gap-3 rounded-2xl p-3 transition ${active ? "grad text-white" : "hover:bg-panel2"}`}
            >
              <Avatar name={chatName(c)} src={chatAvatar(c)} size={48} presence={c.peer?.presence} group={c.type === "group"} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="truncate font-semibold">{chatName(c)}</span>
                  {c.type === "group" && <Icon name="users" size={13} className={active ? "text-white/70" : "text-muted"} />}
                  {c.pinned && <Icon name="pin" size={12} className={active ? "text-white/80" : "text-muted"} />}
                  {c.muted && <Icon name="mute" size={12} className={active ? "text-white/80" : "text-muted"} />}
                  <span className={`ml-auto shrink-0 text-[11px] ${active ? "text-white/80" : "text-muted"}`}>{lm ? fmtShort(lm.createdAt) : ""}</span>
                </div>
                <div className="mt-0.5 flex items-center gap-2">
                  <span className={`truncate text-sm ${active ? "text-white/85" : "text-muted"}`}>
                    {c.activeCall ? (
                      <span className="inline-flex items-center gap-1 font-semibold text-ok"><Icon name="phone" size={13} />Идёт звонок</span>
                    ) : lm ? (
                      <>
                        {lm.senderId && c.type === "group" && !mine ? `${lm.senderName.split(" ")[0]}: ` : mine ? "Вы: " : ""}
                        {previewText(lm.type, lm.body, lm.deleted)}
                      </>
                    ) : (
                      "Нет сообщений"
                    )}
                  </span>
                  {c.unread > 0 && (
                    <span className={`ml-auto grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1.5 text-[11px] font-bold ${active ? "bg-white text-accent" : c.muted ? "bg-panel3 text-muted" : "grad text-white"}`}>{c.unread > 99 ? "99+" : c.unread}</span>
                  )}
                </div>
              </div>
              <div className="absolute right-2 top-2 hidden gap-0.5 rounded-xl border border-line bg-panel p-0.5 text-fg group-hover:flex">
                <button className="icon-btn !h-7 !w-7" title={c.pinned ? "Открепить" : "Закрепить"} onClick={(e) => patchChat(c, { pinned: !c.pinned }, e)}><Icon name="pin" size={14} /></button>
                <button className="icon-btn !h-7 !w-7" title={c.muted ? "Включить звук" : "Без звука"} onClick={(e) => patchChat(c, { muted: !c.muted }, e)}><Icon name="mute" size={14} /></button>
                <button className="icon-btn !h-7 !w-7" title={c.archived ? "Из архива" : "В архив"} onClick={(e) => patchChat(c, { archived: !c.archived }, e)}><Icon name="archive" size={14} /></button>
              </div>
            </div>
          );
        })}
        {loaded && list.length === 0 && !q && (
          <Empty icon={tab === "archive" ? "archive" : "send"} title={tab === "archive" ? "Архив пуст" : "Пока нет чатов"} text={tab === "archive" ? "Заархивированные чаты появятся здесь." : "Найдите людей по никнейму через поиск или добавьте друзей."} />
        )}

        {q.trim().length >= 2 && (
          <div className="anim-fade mt-2">
            <div className="flex items-center gap-2 px-3 py-2 text-xs font-bold uppercase tracking-wider text-muted">Люди {searching && <Spinner size={12} />}</div>
            {people.map((u) => (
              <div key={u.id} onClick={() => openDirect(u.id)} className="flex cursor-pointer items-center gap-3 rounded-2xl p-3 hover:bg-panel2">
                <Avatar name={u.displayName} src={u.avatarUrl} size={44} presence={u.presence} />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold">{u.displayName}</div>
                  <div className="truncate text-sm text-muted">@{u.username}</div>
                </div>
                {u.relation === "none" && <button className="icon-btn" title="Добавить в друзья" onClick={(e) => addFriend(u, e)}><Icon name="userPlus" size={18} /></button>}
                {u.relation === "outgoing" && <span className="text-xs text-muted">заявка отправлена</span>}
                {u.relation === "incoming" && <button className="btn btn-ghost !px-3 !py-1 text-xs" onClick={(e) => addFriend(u, e)}>Принять</button>}
                {u.relation === "friend" && <Icon name="check" size={16} className="text-ok" />}
              </div>
            ))}
            {!searching && people.length === 0 && <div className="px-3 py-3 text-sm text-muted">Пользователи не найдены</div>}
          </div>
        )}
      </div>
    </>
  );
}
