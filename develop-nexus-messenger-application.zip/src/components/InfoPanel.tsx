"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtLastSeen } from "@/lib/client";
import type { UserDTO } from "@/lib/chat";
import { useApp, type ChatDTO } from "./app-context";
import { Avatar, Icon, Spinner, useToast } from "./ui";

type Member = UserDTO & { memberRole: string };
type Profile = UserDTO & { joinedAt: string; relation: string; blockedByMe: boolean };

export default function InfoPanel({ chat }: { chat: ChatDTO }) {
  const { me, setShowInfo, chatName, chatAvatar, refreshChats, openChat, setModal, startCall, joinCall, inCallChatId, subscribe, openDirect } = useApp();
  const toast = useToast();
  const [members, setMembers] = useState<Member[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const isGroup = chat.type === "group";
  const staff = chat.myRole === "owner" || chat.myRole === "admin";
  const isOwner = chat.myRole === "owner";
  const canInvite = staff || chat.permissions.membersCanInvite;
  const peerId = chat.peer?.id;

  const load = useCallback(async () => {
    try {
      if (isGroup) {
        const r = await api<{ members: Member[] }>(`/api/chats/${chat.id}`);
        setMembers(r.members);
      } else if (peerId) {
        const r = await api<{ user: Profile }>(`/api/users/${peerId}`);
        setProfile(r.user);
      }
    } catch { /* ignore */ } finally {
      setLoading(false);
    }
  }, [chat.id, isGroup, peerId]);

  useEffect(() => { load(); }, [load, chat.memberCount]);
  useEffect(() => subscribe((e) => { if (["chats", "presence", "friends"].includes(e.type)) load(); }), [subscribe, load]);

  async function run(fn: () => Promise<unknown>, ok?: string) {
    try {
      await fn();
      if (ok) toast(ok, "success");
      await Promise.all([load(), refreshChats()]);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  const patchChat = (patch: Record<string, boolean>) => run(() => api(`/api/chats/${chat.id}`, { method: "PATCH", body: patch }));
  const leave = () => {
    if (!confirm(isGroup ? "Покинуть группу?" : "Удалить чат из списка? История у собеседника сохранится.")) return;
    run(async () => { await api(`/api/chats/${chat.id}`, { method: "DELETE" }); openChat(null); });
  };

  const online = members.filter((m) => m.presence !== "offline").length;
  const name = chatName(chat);

  return (
    <aside className="anim-left fixed inset-y-0 right-0 z-40 flex w-full max-w-sm flex-col border-l border-line bg-panel xl:static xl:z-auto xl:w-80 xl:max-w-none xl:shrink-0">
      <div className="flex items-center justify-between border-b border-line px-4 py-3.5">
        <h3 className="font-bold">{isGroup ? "Информация о группе" : "Профиль"}</h3>
        <button className="icon-btn" onClick={() => setShowInfo(false)}><Icon name="x" /></button>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="flex flex-col items-center px-5 pb-4 pt-6 text-center">
          <Avatar name={name} src={chatAvatar(chat)} size={96} presence={chat.peer?.presence} group={isGroup} />
          <div className="mt-3 text-xl font-extrabold">{name}</div>
          {!isGroup && chat.peer && (
            <>
              <div className="text-sm text-muted">@{chat.peer.username}</div>
              <div className={`mt-1 text-sm ${chat.peer.presence === "online" ? "text-accent" : "text-muted"}`}>{fmtLastSeen(chat.peer.presence, chat.peer.lastSeen)}</div>
            </>
          )}
          {isGroup && <div className="mt-1 text-sm text-muted">{chat.memberCount} участников{members.length ? `, в сети ${online}` : ""}</div>}
          {(isGroup ? chat.description : profile?.bio || chat.peer?.bio) && (
            <p className="mt-3 w-full rounded-xl bg-panel2 p-3 text-sm text-fg/90">{isGroup ? chat.description : profile?.bio || chat.peer?.bio}</p>
          )}
        </div>

        {/* quick actions */}
        <div className="grid grid-cols-3 gap-2 px-4 pb-4">
          {!chat.blockedByMe && !chat.blockedMe && (
            <>
              <button className="btn btn-ghost flex-col !gap-1 !py-3 text-xs" onClick={() => (chat.activeCall ? joinCall(chat.id, chat.activeCall.kind) : startCall(chat.id, "voice"))}><Icon name="phone" size={20} />{isGroup ? "Голос. комната" : "Звонок"}</button>
              <button className="btn btn-ghost flex-col !gap-1 !py-3 text-xs" onClick={() => (chat.activeCall ? joinCall(chat.id, "video") : startCall(chat.id, "video"))}><Icon name="video" size={20} />Видео</button>
            </>
          )}
          <button className="btn btn-ghost flex-col !gap-1 !py-3 text-xs" onClick={() => patchChat({ muted: !chat.muted })}><Icon name={chat.muted ? "bell" : "mute"} size={20} />{chat.muted ? "Включить" : "Без звука"}</button>
        </div>
        {inCallChatId === chat.id && <div className="mx-4 mb-3 rounded-xl bg-ok/15 px-3 py-2 text-center text-xs font-semibold text-ok">Вы в звонке</div>}

        <div className="space-y-0.5 px-2 pb-3">
          <Row icon="pin" label={chat.pinned ? "Открепить чат" : "Закрепить чат"} onClick={() => patchChat({ pinned: !chat.pinned })} />
          <Row icon="archive" label={chat.archived ? "Вернуть из архива" : "Архивировать"} onClick={() => patchChat({ archived: !chat.archived })} />
          <Row icon="star" label="Избранные сообщения" onClick={() => setModal({ kind: "favorites" })} />
          {isGroup && canInvite && <Row icon="userPlus" label="Добавить участников" onClick={() => setModal({ kind: "addMembers", chatId: chat.id })} />}
          {isGroup && staff && <Row icon="settings" label="Настройки группы и права" onClick={() => setModal({ kind: "groupSettings", chatId: chat.id })} />}
          {!isGroup && peerId && (
            <>
              {profile?.relation === "none" && <Row icon="userPlus" label="Добавить в друзья" onClick={() => run(() => api("/api/friends", { body: { userId: peerId } }), "Заявка отправлена")} />}
              {profile?.relation === "outgoing" && <Row icon="userPlus" label="Отменить заявку" onClick={() => run(() => api(`/api/friends?userId=${peerId}`, { method: "DELETE" }))} />}
              {profile?.relation === "incoming" && <Row icon="check" label="Принять заявку в друзья" onClick={() => run(() => api("/api/friends", { body: { userId: peerId } }), "Теперь вы друзья")} />}
              {profile?.relation === "friend" && <Row icon="user" label="Удалить из друзей" onClick={() => run(() => api(`/api/friends?userId=${peerId}`, { method: "DELETE" }))} />}
              <Row icon="flag" label="Пожаловаться" danger onClick={() => setModal({ kind: "report", userId: peerId })} />
              {chat.blockedByMe ? (
                <Row icon="block" label="Разблокировать" onClick={() => run(() => api(`/api/blocks?userId=${peerId}`, { method: "DELETE" }), "Пользователь разблокирован")} />
              ) : (
                <Row icon="block" label="Заблокировать" danger onClick={() => { if (confirm(`Заблокировать ${name}?`)) run(() => api("/api/blocks", { body: { userId: peerId } }), "Пользователь заблокирован"); }} />
              )}
            </>
          )}
          <Row icon="logout" label={isGroup ? "Покинуть группу" : "Удалить чат"} danger onClick={leave} />
        </div>

        {isGroup && (
          <div className="border-t border-line px-2 pb-6 pt-3">
            <div className="px-3 pb-2 text-xs font-bold uppercase tracking-wider text-muted">Участники · в сети {online}</div>
            {loading && <div className="grid place-items-center py-6"><Spinner /></div>}
            {[...members].sort((a, b) => Number(b.presence !== "offline") - Number(a.presence !== "offline")).map((m) => {
              const self = m.id === me.id;
              const canRemove = !self && staff && m.memberRole !== "owner" && (isOwner || m.memberRole === "member");
              return (
                <div key={m.id} className="group flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-panel2">
                  <button onClick={() => setModal({ kind: "profile", userId: m.id })}><Avatar name={m.displayName} src={m.avatarUrl} size={38} presence={m.presence} /></button>
                  <button className="min-w-0 flex-1 text-left" onClick={() => !self && openDirect(m.id)}>
                    <div className="flex items-center gap-1.5 truncate text-sm font-semibold">{m.displayName}{self && <span className="text-xs font-normal text-muted">(вы)</span>}</div>
                    <div className="truncate text-xs text-muted">{m.presence === "online" ? "в сети" : fmtLastSeen(m.presence, m.lastSeen)}</div>
                  </button>
                  {m.memberRole !== "member" && <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${m.memberRole === "owner" ? "grad text-white" : "bg-accent/20 text-accent"}`}>{m.memberRole === "owner" ? "владелец" : "админ"}</span>}
                  {isOwner && !self && m.memberRole !== "owner" && (
                    <button className="icon-btn hidden !h-7 !w-7 group-hover:grid" title={m.memberRole === "admin" ? "Снять админа" : "Назначить админом"} onClick={() => run(() => api(`/api/chats/${chat.id}/members`, { method: "PATCH", body: { userId: m.id, role: m.memberRole === "admin" ? "member" : "admin" } }))}><Icon name="shield" size={15} /></button>
                  )}
                  {canRemove && (
                    <button className="icon-btn hidden !h-7 !w-7 group-hover:grid" title="Удалить из группы" onClick={() => { if (confirm(`Удалить ${m.displayName} из группы?`)) run(() => api(`/api/chats/${chat.id}/members?userId=${m.id}`, { method: "DELETE" })); }}><Icon name="x" size={15} className="text-danger" /></button>
                  )}
                </div>
              );
            })}
          </div>
        )}
        {!isGroup && profile && (
          <div className="border-t border-line px-5 py-4 text-sm text-muted">
            На платформе с {new Date(profile.joinedAt).toLocaleDateString("ru-RU", { month: "long", year: "numeric" })}
          </div>
        )}
      </div>
    </aside>
  );
}

function Row({ icon, label, onClick, danger }: { icon: string; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button onClick={onClick} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition hover:bg-panel2 ${danger ? "text-danger" : ""}`}>
      <Icon name={icon} size={18} className={danger ? "" : "text-muted"} />{label}
    </button>
  );
}

