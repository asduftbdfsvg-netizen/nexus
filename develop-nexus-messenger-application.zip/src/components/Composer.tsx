"use client";

import { useEffect, useRef, useState } from "react";
import { api, EMOJI_GROUPS, STICKERS } from "@/lib/client";
import type { MessageDTO } from "@/lib/chat";
import { Icon, Spinner, useClickOutside } from "./ui";
import { previewText } from "./Sidebar";

type Panel = null | "emoji" | "sticker" | "gif";

export type SendPayload = { type: string; text?: string; attachment?: { url: string; name?: string; size?: number; mime?: string } };

export default function Composer({
  replyTo, editing, onCancelReply, onCancelEdit, onSend, onEdit, onFiles, onTyping, uploading, restriction,
}: {
  replyTo: MessageDTO | null;
  editing: MessageDTO | null;
  onCancelReply: () => void;
  onCancelEdit: () => void;
  onSend: (p: SendPayload) => Promise<void>;
  onEdit: (text: string) => Promise<void>;
  onFiles: (files: File[]) => void;
  onTyping: () => void;
  uploading: number;
  restriction: string | null;
}) {
  const [text, setText] = useState("");
  const [panel, setPanel] = useState<Panel>(null);
  const [group, setGroup] = useState(0);
  const [gifs, setGifs] = useState<{ id: string; url: string; preview: string }[]>([]);
  const [gifEnabled, setGifEnabled] = useState<boolean | null>(null);
  const [gifQ, setGifQ] = useState("");
  const [gifUrl, setGifUrl] = useState("");
  const [gifLoading, setGifLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const wrapRef = useClickOutside<HTMLDivElement>(() => setPanel(null));

  useEffect(() => {
    if (editing) {
      setText(editing.body);
      taRef.current?.focus();
    }
  }, [editing]);
  useEffect(() => {
    if (replyTo) taRef.current?.focus();
  }, [replyTo]);

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 160) + "px";
  }, [text]);

  useEffect(() => {
    if (panel !== "gif") return;
    setGifLoading(true);
    const t = setTimeout(async () => {
      try {
        const r = await api<{ enabled: boolean; gifs: typeof gifs }>(`/api/gifs?q=${encodeURIComponent(gifQ)}`);
        setGifEnabled(r.enabled);
        setGifs(r.gifs);
      } catch {
        setGifs([]);
      } finally {
        setGifLoading(false);
      }
    }, gifQ ? 350 : 0);
    return () => clearTimeout(t);
  }, [panel, gifQ]);

  async function submit() {
    const t = text.trim();
    if (!t || sending) return;
    setSending(true);
    try {
      if (editing) await onEdit(t);
      else await onSend({ type: "text", text: t });
      setText("");
    } catch {
      /* toast handled by parent */
    } finally {
      setSending(false);
      taRef.current?.focus();
    }
  }

  if (restriction) {
    return <div className="border-t border-line bg-panel px-4 py-4 text-center text-sm text-muted">{restriction}</div>;
  }

  return (
    <div className="relative border-t border-line bg-panel px-3 pb-3 pt-2 md:px-4" ref={wrapRef}>
      {(replyTo || editing) && (
        <div className="anim-up mb-2 flex items-center gap-3 rounded-xl border-l-[3px] border-accent bg-panel2 px-3 py-2">
          <Icon name={editing ? "edit" : "reply"} size={16} className="text-accent" />
          <div className="min-w-0 flex-1 text-sm">
            <div className="font-semibold text-accent">{editing ? "Редактирование" : `Ответ ${replyTo?.sender?.displayName ?? ""}`}</div>
            <div className="truncate text-muted">{previewText((editing ?? replyTo)!.type, (editing ?? replyTo)!.body)}</div>
          </div>
          <button className="icon-btn !h-7 !w-7" onClick={() => { if (editing) { onCancelEdit(); setText(""); } else onCancelReply(); }}><Icon name="x" size={16} /></button>
        </div>
      )}

      {panel && (
        <div className="anim-pop absolute bottom-full left-3 right-3 z-30 mb-2 overflow-hidden rounded-2xl border border-line bg-panel md:left-4 md:right-auto md:w-[380px]" style={{ boxShadow: "var(--shadow)" }}>
          <div className="flex border-b border-line">
            {([["emoji", "Эмодзи", "smile"], ["sticker", "Стикеры", "sticker"], ["gif", "GIF", "gif"]] as [Panel, string, string][]).map(([id, label, icon]) => (
              <button key={id} onClick={() => setPanel(id)} className={`flex flex-1 items-center justify-center gap-1.5 py-2.5 text-sm font-semibold transition ${panel === id ? "text-accent" : "text-muted hover:text-fg"}`}>
                <Icon name={icon} size={16} />{label}
              </button>
            ))}
          </div>
          {panel === "emoji" && (
            <>
              <div className="flex gap-1 border-b border-line px-2 py-1.5">
                {EMOJI_GROUPS.map((g, i) => (
                  <button key={g.name} title={g.name} onClick={() => setGroup(i)} className={`grid h-8 w-8 place-items-center rounded-lg text-lg ${group === i ? "bg-panel3" : "hover:bg-panel2"}`}>{g.icon}</button>
                ))}
              </div>
              <div className="grid h-60 grid-cols-8 content-start gap-0.5 overflow-y-auto p-2">
                {EMOJI_GROUPS[group].items.map((e) => (
                  <button key={e} onClick={() => { setText((t) => t + e); taRef.current?.focus(); }} className="grid h-9 place-items-center rounded-lg text-xl transition hover:scale-125 hover:bg-panel2">{e}</button>
                ))}
              </div>
            </>
          )}
          {panel === "sticker" && (
            <div className="grid h-72 grid-cols-4 content-start gap-1 overflow-y-auto p-2">
              {STICKERS.map((s) => (
                <button key={s} disabled={!!editing} onClick={async () => { setPanel(null); await onSend({ type: "sticker", text: s }).catch(() => {}); }} className="grid h-[68px] place-items-center rounded-xl text-4xl transition hover:scale-110 hover:bg-panel2">{s}</button>
              ))}
            </div>
          )}
          {panel === "gif" && (
            <div className="h-72 overflow-y-auto p-2">
              {gifEnabled && (
                <input className="input mb-2 !py-2" placeholder="Поиск GIF…" value={gifQ} onChange={(e) => setGifQ(e.target.value)} />
              )}
              {gifEnabled === false && (
                <div className="mb-3 rounded-xl bg-panel2 p-3 text-xs text-muted">
                  Поиск GIF включается переменной <code className="font-mono text-fg">GIPHY_API_KEY</code>. Пока вы можете вставить прямую https-ссылку на GIF:
                </div>
              )}
              <form className="mb-2 flex gap-2" onSubmit={async (e) => { e.preventDefault(); if (!gifUrl.trim()) return; await onSend({ type: "gif", attachment: { url: gifUrl.trim() } }).then(() => { setGifUrl(""); setPanel(null); }).catch(() => {}); }}>
                <input className="input !py-2" placeholder="https://…/image.gif" value={gifUrl} onChange={(e) => setGifUrl(e.target.value)} />
                <button className="btn btn-primary !px-3" disabled={!gifUrl.trim()}><Icon name="send" size={16} /></button>
              </form>
              {gifLoading ? <div className="grid place-items-center py-8"><Spinner /></div> : (
                <div className="columns-2 gap-2">
                  {gifs.map((g) => (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img key={g.id} src={g.preview} alt="gif" loading="lazy" onClick={async () => { setPanel(null); await onSend({ type: "gif", attachment: { url: g.url } }).catch(() => {}); }} className="mb-2 w-full cursor-pointer rounded-lg transition hover:opacity-80" />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      <div className="flex items-end gap-1.5">
        <input ref={fileRef} type="file" multiple hidden onChange={(e) => { if (e.target.files?.length) onFiles([...e.target.files]); e.target.value = ""; }} />
        <button className="icon-btn !h-11 !w-11" title="Прикрепить файл" onClick={() => fileRef.current?.click()} disabled={!!editing}>
          {uploading > 0 ? <Spinner size={18} /> : <Icon name="paperclip" />}
        </button>
        <div className="flex min-w-0 flex-1 items-end rounded-2xl border border-line bg-panel2 transition focus-within:border-accent">
          <textarea
            ref={taRef}
            rows={1}
            value={text}
            maxLength={4000}
            placeholder="Написать сообщение…"
            className="max-h-40 min-h-[44px] flex-1 resize-none bg-transparent px-4 py-3 text-[0.94rem] outline-none placeholder:text-muted"
            onChange={(e) => { setText(e.target.value); if (!editing) onTyping(); }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); }
              if (e.key === "Escape") { if (editing) { onCancelEdit(); setText(""); } else onCancelReply(); }
            }}
            onPaste={(e) => {
              const files = [...e.clipboardData.files];
              if (files.length && !editing) { e.preventDefault(); onFiles(files); }
            }}
          />
          <button className={`icon-btn !h-11 !w-11 ${panel ? "!text-accent" : ""}`} title="Эмодзи, стикеры, GIF" onClick={() => setPanel(panel ? null : "emoji")}><Icon name="smile" /></button>
        </div>
        <button className="btn btn-primary !h-11 !w-11 !rounded-2xl !p-0" onClick={submit} disabled={!text.trim() || sending} title={editing ? "Сохранить" : "Отправить"}>
          {sending ? <Spinner size={18} /> : <Icon name={editing ? "check" : "send"} size={19} />}
        </button>
      </div>
    </div>
  );
}
