"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { api, ACCENTS, uploadFile } from "@/lib/client";
import type { UserDTO } from "@/lib/chat";
import type { UserSettings } from "@/db/schema";
import { useApp, type SelfDTO } from "./app-context";
import { Avatar, Icon, Modal, Spinner, Toggle, useToast } from "./ui";

type Patch = { privacy?: Partial<UserSettings["privacy"]>; notifications?: Partial<UserSettings["notifications"]>; appearance?: Partial<UserSettings["appearance"]> };

const TABS: [string, string, string][] = [
  ["profile", "Профиль", "user"],
  ["privacy", "Конфиденциальность", "lock"],
  ["notifications", "Уведомления", "bell"],
  ["appearance", "Внешний вид", "sun"],
  ["security", "Безопасность", "shield"],
  ["rules", "Правила", "list"],
];

function Row({ title, desc, children }: { title: string; desc?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="min-w-0">
        <div className="text-sm font-semibold">{title}</div>
        {desc && <div className="text-xs text-muted">{desc}</div>}
      </div>
      {children}
    </div>
  );
}

export default function SettingsModal({ tab: initial }: { tab?: string }) {
  const { me, setMe, setModal, logout } = useApp();
  const toast = useToast();
  const [tab, setTab] = useState(initial ?? "profile");
  const s = me.settings;

  async function save(patch: Patch) {
    try {
      const u = await api<SelfDTO>("/api/me", { method: "PATCH", body: { settings: patch } });
      setMe(u);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  return (
    <Modal title="Настройки" onClose={() => setModal(null)} width="max-w-3xl">
      <div className="flex min-h-[460px] flex-col md:flex-row">
        <nav className="flex shrink-0 gap-1 overflow-x-auto border-b border-line p-2 md:w-56 md:flex-col md:border-b-0 md:border-r">
          {TABS.map(([id, label, icon]) => (
            <button key={id} onClick={() => setTab(id)} className={`flex items-center gap-2.5 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold transition ${tab === id ? "grad text-white" : "text-muted hover:bg-panel2 hover:text-fg"}`}>
              <Icon name={icon} size={17} />{label}
            </button>
          ))}
          <button onClick={logout} className="mt-auto flex items-center gap-2.5 whitespace-nowrap rounded-xl px-3 py-2.5 text-sm font-semibold text-danger hover:bg-danger/10"><Icon name="logout" size={17} />Выйти</button>
        </nav>
        <div className="min-w-0 flex-1 p-5">
          {tab === "profile" && <ProfileTab />}
          {tab === "privacy" && <PrivacyTab save={save} />}
          {tab === "notifications" && (
            <div className="anim-fade divide-y divide-line">
              <Row title="Звук уведомлений" desc="Короткий сигнал при новом сообщении"><Toggle checked={s.notifications.sound} onChange={(v) => save({ notifications: { sound: v } })} /></Row>
              <Row title="Уведомления сообщений" desc="Всплывающие уведомления о новых сообщениях"><Toggle checked={s.notifications.messages} onChange={(v) => save({ notifications: { messages: v } })} /></Row>
              <Row title="Показывать текст сообщения" desc="Если выключено — только «Новое сообщение»"><Toggle checked={s.notifications.preview} onChange={(v) => save({ notifications: { preview: v } })} /></Row>
              <Row title="Заявки в друзья" desc="Уведомлять о новых заявках"><Toggle checked={s.notifications.friendRequests} onChange={(v) => save({ notifications: { friendRequests: v } })} /></Row>
              <Row title="Группы" desc="Уведомлять о добавлении в группы"><Toggle checked={s.notifications.groups} onChange={(v) => save({ notifications: { groups: v } })} /></Row>
              <Row title="Системные уведомления браузера" desc="Когда вкладка неактивна">
                <Toggle
                  checked={s.notifications.desktop}
                  onChange={async (v) => {
                    if (v && "Notification" in window) {
                      const p = await Notification.requestPermission();
                      if (p !== "granted") return toast("Разрешите уведомления в настройках браузера", "error");
                    } else if (v) return toast("Браузер не поддерживает уведомления", "error");
                    save({ notifications: { desktop: v } });
                  }}
                />
              </Row>
              <p className="pt-3 text-xs text-muted">Статус «Не беспокоить» полностью отключает всплывающие уведомления и звуки.</p>
            </div>
          )}
          {tab === "appearance" && (
            <div className="anim-fade space-y-5">
              <div>
                <div className="label">Тема</div>
                <div className="grid grid-cols-3 gap-2">
                  {([["dark", "Тёмная", "moon"], ["light", "Светлая", "sun"], ["system", "Системная", "settings"]] as const).map(([id, label, icon]) => (
                    <button key={id} onClick={() => save({ appearance: { theme: id } })} className={`flex flex-col items-center gap-2 rounded-2xl border-2 p-4 text-sm font-semibold transition ${s.appearance.theme === id ? "border-accent bg-accent/10" : "border-line hover:bg-panel2"}`}>
                      <Icon name={icon} size={22} />{label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Акцентный цвет</div>
                <div className="flex flex-wrap gap-3">
                  {ACCENTS.map((a) => (
                    <button key={a.id} title={a.name} onClick={() => save({ appearance: { accent: a.id } })} className={`grid h-10 w-10 place-items-center rounded-full transition hover:scale-110 ${s.appearance.accent === a.id ? "ring-2 ring-offset-2 ring-offset-panel" : ""}`} style={{ background: a.color, ["--tw-ring-color" as string]: a.color }}>
                      {s.appearance.accent === a.id && <Icon name="check" size={18} className="text-white" />}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Размер текста</div>
                <div className="flex gap-2">
                  {([["sm", "Мелкий"], ["md", "Обычный"], ["lg", "Крупный"]] as const).map(([id, l]) => (
                    <button key={id} onClick={() => save({ appearance: { fontSize: id } })} className={`btn flex-1 ${s.appearance.fontSize === id ? "btn-primary" : "btn-ghost"}`}>{l}</button>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Форма сообщений</div>
                <div className="flex gap-2">
                  {([["round", "Скруглённые"], ["square", "Строгие"]] as const).map(([id, l]) => (
                    <button key={id} onClick={() => save({ appearance: { bubbles: id } })} className={`btn flex-1 ${s.appearance.bubbles === id ? "btn-primary" : "btn-ghost"}`}>{l}</button>
                  ))}
                </div>
              </div>
              <Row title="Компактный режим" desc="Меньше отступов между сообщениями"><Toggle checked={s.appearance.compact} onChange={(v) => save({ appearance: { compact: v } })} /></Row>
            </div>
          )}
          {tab === "security" && <SecurityTab />}
          {tab === "rules" && <RulesTab />}
        </div>
      </div>
    </Modal>
  );
}

function ProfileTab() {
  const { me, setMe } = useApp();
  const toast = useToast();
  const [f, setF] = useState({ displayName: me.displayName, username: me.username, bio: me.bio });
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const dirty = f.displayName !== me.displayName || f.username !== me.username || f.bio !== me.bio;

  async function save() {
    setBusy(true);
    try {
      setMe(await api<SelfDTO>("/api/me", { method: "PATCH", body: f }));
      toast("Профиль сохранён", "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    } finally {
      setBusy(false);
    }
  }
  async function avatar(file: File | undefined, remove = false) {
    setUploading(true);
    try {
      const url = remove ? null : (await uploadFile(file!, "avatar")).url;
      setMe(await api<SelfDTO>("/api/me", { method: "PATCH", body: { avatarUrl: url } }));
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    } finally {
      setUploading(false);
    }
  }
  return (
    <div className="anim-fade space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative">
          <Avatar name={me.displayName} src={me.avatarUrl} size={84} />
          {uploading && <div className="absolute inset-0 grid place-items-center rounded-full bg-black/50"><Spinner /></div>}
        </div>
        <div className="flex flex-col gap-2">
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => { avatar(e.target.files?.[0]); e.target.value = ""; }} />
          <button className="btn btn-primary" onClick={() => fileRef.current?.click()}><Icon name="camera" size={16} />Загрузить фото</button>
          {me.avatarUrl && <button className="btn btn-ghost" onClick={() => avatar(undefined, true)}>Удалить</button>}
        </div>
      </div>
      <div><label className="label">Имя</label><input className="input" value={f.displayName} maxLength={50} onChange={(e) => setF({ ...f, displayName: e.target.value })} /></div>
      <div>
        <label className="label">Никнейм</label>
        <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted">@</span><input className="input !pl-8" value={f.username} maxLength={24} onChange={(e) => setF({ ...f, username: e.target.value.toLowerCase() })} /></div>
      </div>
      <div><label className="label">О себе</label><textarea className="input min-h-24 resize-none" value={f.bio} maxLength={300} onChange={(e) => setF({ ...f, bio: e.target.value })} /></div>
      <div className="text-xs text-muted">Email: {me.email}</div>
      <button className="btn btn-primary" disabled={!dirty || busy} onClick={save}>{busy ? <Spinner size={16} /> : "Сохранить"}</button>
    </div>
  );
}

function PrivacyTab({ save }: { save: (p: Patch) => void }) {
  const { me } = useApp();
  const toast = useToast();
  const p = me.settings.privacy;
  const [blocked, setBlocked] = useState<UserDTO[] | null>(null);
  useEffect(() => { api<{ users: UserDTO[] }>("/api/blocks").then((r) => setBlocked(r.users)).catch(() => setBlocked([])); }, []);
  const sel = (key: "lastSeen" | "avatar", opts: [string, string][]) => (
    <select className="input !w-auto !py-2" value={p[key]} onChange={(e) => save({ privacy: { [key]: e.target.value } })}>
      {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
    </select>
  );
  const vis: [string, string][] = [["everyone", "Все"], ["friends", "Только друзья"], ["nobody", "Никто"]];
  return (
    <div className="anim-fade divide-y divide-line">
      <Row title="Время последнего посещения" desc="Кто видит, когда вы были в сети">{sel("lastSeen", vis)}</Row>
      <Row title="Фото профиля" desc="Кто видит ваш аватар">{sel("avatar", vis)}</Row>
      <Row title="Кто может писать мне" desc="Ограничение новых личных диалогов">
        <select className="input !w-auto !py-2" value={p.messages} onChange={(e) => save({ privacy: { messages: e.target.value as "everyone" | "friends" } })}>
          <option value="everyone">Все</option><option value="friends">Только друзья</option>
        </select>
      </Row>
      <Row title="Отчёты о прочтении" desc="Если выключить, вы тоже не увидите «прочитано» у других"><Toggle checked={p.readReceipts} onChange={(v) => save({ privacy: { readReceipts: v } })} /></Row>
      <Row title="Индикатор набора текста" desc="Показывать собеседникам, что вы печатаете"><Toggle checked={p.typing} onChange={(v) => save({ privacy: { typing: v } })} /></Row>
      <div className="pt-4">
        <div className="label">Чёрный список</div>
        {blocked === null ? <Spinner /> : blocked.length === 0 ? <div className="text-sm text-muted">Вы никого не блокировали</div> : blocked.map((u) => (
          <div key={u.id} className="flex items-center gap-3 py-2">
            <Avatar name={u.displayName} src={u.avatarUrl} size={36} />
            <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{u.displayName}</div><div className="truncate text-xs text-muted">@{u.username}</div></div>
            <button className="btn btn-ghost !py-1.5 text-xs" onClick={async () => { try { await api(`/api/blocks?userId=${u.id}`, { method: "DELETE" }); setBlocked((l) => l?.filter((x) => x.id !== u.id) ?? []); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } }}>Разблокировать</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function SecurityTab() {
  const toast = useToast();
  const [f, setF] = useState({ current: "", next: "", again: "" });
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (f.next !== f.again) return toast("Пароли не совпадают", "error");
    setBusy(true);
    try {
      await api("/api/me/password", { body: { current: f.current, next: f.next } });
      toast("Пароль изменён. Другие устройства разлогинены.", "success");
      setF({ current: "", next: "", again: "" });
    } catch (err) {
      toast(err instanceof Error ? err.message : "Ошибка", "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="anim-fade max-w-sm space-y-4">
      <h3 className="font-bold">Смена пароля</h3>
      <div><label className="label">Текущий пароль</label><input className="input" type="password" autoComplete="current-password" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} required /></div>
      <div><label className="label">Новый пароль</label><input className="input" type="password" autoComplete="new-password" minLength={8} value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} required /></div>
      <div><label className="label">Повторите пароль</label><input className="input" type="password" autoComplete="new-password" minLength={8} value={f.again} onChange={(e) => setF({ ...f, again: e.target.value })} required /></div>
      <button className="btn btn-primary" disabled={busy}>{busy ? <Spinner size={16} /> : "Изменить пароль"}</button>
    </form>
  );
}

function RulesTab() {
  const [rules, setRules] = useState<string | null>(null);
  useEffect(() => { api<{ rules: string }>("/api/rules").then((r) => setRules(r.rules)).catch(() => setRules("Не удалось загрузить")); }, []);
  return (
    <div className="anim-fade">
      <h3 className="mb-3 font-bold">Правила платформы</h3>
      {rules === null ? <Spinner /> : <pre className="whitespace-pre-wrap rounded-xl bg-panel2 p-4 font-sans text-sm leading-relaxed">{rules}</pre>}
    </div>
  );
}
