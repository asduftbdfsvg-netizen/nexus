"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { api, fmtDay, fmtTime } from "@/lib/client";
import { Avatar, Empty, Icon, Modal, Spinner, Toggle, ToastProvider, useToast } from "./ui";

const TABS: [string, string, string][] = [
  ["stats", "Обзор", "chart"],
  ["users", "Пользователи", "users"],
  ["reports", "Жалобы", "flag"],
  ["groups", "Группы", "users"],
  ["warnings", "Предупреждения", "warning"],
  ["logs", "Журнал действий", "list"],
  ["settings", "Правила и настройки", "settings"],
];

export default function AdminPanel(props: { adminName: string; adminId: string }) {
  return (
    <ToastProvider>
      <Panel {...props} />
    </ToastProvider>
  );
}

const dt = (iso: string) => `${fmtDay(iso)}, ${fmtTime(iso)}`;

function Panel({ adminName, adminId }: { adminName: string; adminId: string }) {
  const [tab, setTab] = useState("stats");
  const [navOpen, setNavOpen] = useState(false);
  return (
    <div className="flex h-dvh bg-app">
      <aside className={`${navOpen ? "fixed inset-y-0 left-0 z-40 flex" : "hidden"} w-64 shrink-0 flex-col border-r border-line bg-panel md:static md:flex`}>
        <div className="flex items-center gap-3 p-5">
          <div className="grad grid h-10 w-10 place-items-center rounded-2xl font-black text-white">N</div>
          <div><div className="font-extrabold leading-tight">NEXUS</div><div className="text-xs text-muted">Админ-панель</div></div>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {TABS.map(([id, label, icon]) => (
            <button key={id} onClick={() => { setTab(id); setNavOpen(false); }} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition ${tab === id ? "grad text-white" : "text-muted hover:bg-panel2 hover:text-fg"}`}>
              <Icon name={icon} size={18} />{label}
            </button>
          ))}
        </nav>
        <div className="border-t border-line p-4 text-sm">
          <div className="mb-3 text-muted">Вы вошли как <b className="text-fg">{adminName}</b></div>
          <a href="/" className="btn btn-ghost w-full"><Icon name="back" size={16} />К мессенджеру</a>
        </div>
      </aside>
      {navOpen && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setNavOpen(false)} />}
      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-panel/90 px-4 py-3 backdrop-blur md:hidden">
          <button className="icon-btn" onClick={() => setNavOpen(true)}><Icon name="menu" /></button>
          <b>{TABS.find((t) => t[0] === tab)?.[1]}</b>
        </div>
        <div className="mx-auto max-w-6xl p-4 md:p-8">
          <h1 className="mb-6 hidden text-2xl font-extrabold md:block">{TABS.find((t) => t[0] === tab)?.[1]}</h1>
          {tab === "stats" && <StatsTab />}
          {tab === "users" && <UsersTab adminId={adminId} />}
          {tab === "reports" && <ReportsTab />}
          {tab === "groups" && <GroupsTab />}
          {tab === "warnings" && <WarningsTab />}
          {tab === "logs" && <LogsTab />}
          {tab === "settings" && <SettingsTab />}
        </div>
      </main>
    </div>
  );
}

function useLoad<T>(path: string) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try { setData(await api<T>(path)); setError(""); } catch (e) { setError(e instanceof Error ? e.message : "Ошибка"); }
  }, [path]);
  useEffect(() => { load(); }, [load]);
  return { data, error, load, setData };
}

function Loading({ error }: { error?: string }) {
  return error ? <div className="rounded-xl bg-danger/15 p-4 text-danger">{error}</div> : <div className="grid place-items-center py-16"><Spinner size={28} /></div>;
}

function Badge({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "ok" | "danger" | "accent" | "warn" }) {
  const c = { muted: "bg-panel3 text-muted", ok: "bg-ok/15 text-ok", danger: "bg-danger/15 text-danger", accent: "bg-accent/15 text-accent", warn: "bg-warn/15 text-warn" }[tone];
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${c}`}>{children}</span>;
}

/* ---------- stats ---------- */
type Stats = { users: number; messages: number; groups: number; directs: number; active24: number; active5m: number; msg24: number; newWeek: number; banned: number; openReports: number; admins: number; calls: number; daily: { day: string; n: number }[] };

function StatsTab() {
  const { data, error } = useLoad<Stats>("/api/admin/stats");
  if (!data) return <Loading error={error} />;
  const max = Math.max(1, ...data.daily.map((d) => d.n));
  const cards: [string, number, string, string][] = [
    ["Пользователей", data.users, "users", `+${data.newWeek} за 7 дней`],
    ["Сообщений", data.messages, "send", `${data.msg24} за 24 часа`],
    ["Активных за 24 ч", data.active24, "chart", `${data.active5m} онлайн сейчас`],
    ["Групп", data.groups, "users", `${data.directs} личных чатов`],
    ["Открытых жалоб", data.openReports, "flag", "требуют внимания"],
    ["Заблокировано", data.banned, "block", `${data.admins} администратор(ов)`],
    ["Звонков", data.calls, "phone", "за всё время"],
  ];
  return (
    <div className="anim-up space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map(([t, n, icon, sub]) => (
          <div key={t} className="card p-5">
            <div className="flex items-center justify-between text-muted"><span className="text-sm font-semibold">{t}</span><Icon name={icon} size={18} /></div>
            <div className="grad-text mt-2 text-4xl font-extrabold">{n.toLocaleString("ru-RU")}</div>
            <div className="mt-1 text-xs text-muted">{sub}</div>
          </div>
        ))}
      </div>
      <div className="card p-5">
        <div className="mb-4 font-bold">Сообщения за 7 дней</div>
        <div className="flex h-48 items-end gap-3">
          {data.daily.map((d) => (
            <div key={d.day} className="flex flex-1 flex-col items-center gap-2">
              <span className="text-xs font-semibold">{d.n}</span>
              <div className="grad w-full rounded-t-lg transition-all" style={{ height: `${Math.max(4, (d.n / max) * 140)}px` }} />
              <span className="text-[11px] text-muted">{d.day}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- users ---------- */
type AUser = { id: string; email: string; username: string; displayName: string; avatarUrl: string | null; role: string; isBanned: boolean; banReason: string | null; lastSeen: string; createdAt: string; warnings: number; messages: number };

function UsersTab({ adminId }: { adminId: string }) {
  const toast = useToast();
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [data, setData] = useState<{ users: AUser[]; total: number } | null>(null);
  const [link, setLink] = useState<string | null>(null);
  const load = useCallback(async () => {
    try { setData(await api(`/api/admin/users?q=${encodeURIComponent(q)}&page=${page}`)); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }, [q, page, toast]);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  async function act(u: AUser, action: string, extra: Record<string, unknown> = {}) {
    try {
      const r = await api<{ link?: string }>("/api/admin/users", { method: "PATCH", body: { userId: u.id, action, ...extra } });
      if (r.link) setLink(r.link);
      else toast("Готово", "success");
      load();
    } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }
  async function warn(u: AUser) {
    const reason = prompt(`Причина предупреждения для @${u.username}:`);
    if (!reason) return;
    try {
      const r = await api<{ count: number; banned: boolean }>("/api/admin/warnings", { body: { userId: u.id, reason } });
      toast(r.banned ? `Выдано (${r.count}). Пользователь автоматически заблокирован` : `Предупреждение выдано (${r.count})`, "success");
      load();
    } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }

  return (
    <div className="anim-up">
      <div className="relative mb-4 max-w-md">
        <Icon name="search" size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
        <input className="input !pl-10" placeholder="Поиск по имени, никнейму, email…" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
      </div>
      {!data ? <Loading /> : data.users.length === 0 ? <Empty icon="users" title="Никого не найдено" /> : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[820px] text-sm">
            <thead><tr className="border-b border-line text-left text-xs uppercase tracking-wider text-muted">
              <th className="p-3">Пользователь</th><th className="p-3">Статус</th><th className="p-3">Сообщ.</th><th className="p-3">Предупр.</th><th className="p-3">Был(а) в сети</th><th className="p-3 text-right">Действия</th>
            </tr></thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u.id} className="border-b border-line/60 last:border-0 hover:bg-panel2/60">
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      <Avatar name={u.displayName} src={u.avatarUrl} size={38} />
                      <div className="min-w-0"><div className="truncate font-semibold">{u.displayName}</div><div className="truncate text-xs text-muted">@{u.username} · {u.email}</div></div>
                    </div>
                  </td>
                  <td className="p-3"><div className="flex flex-wrap gap-1">{u.role === "admin" && <Badge tone="accent">админ</Badge>}{u.isBanned ? <Badge tone="danger">заблокирован</Badge> : <Badge tone="ok">активен</Badge>}</div>{u.banReason && <div className="mt-1 max-w-[180px] truncate text-xs text-muted" title={u.banReason}>{u.banReason}</div>}</td>
                  <td className="p-3">{u.messages}</td>
                  <td className="p-3">{u.warnings > 0 ? <Badge tone="warn">{u.warnings}</Badge> : "—"}</td>
                  <td className="p-3 text-muted">{dt(u.lastSeen)}</td>
                  <td className="p-3">
                    <div className="flex flex-wrap justify-end gap-1.5">
                      {u.id !== adminId && (
                        <>
                          {u.isBanned ? <button className="btn btn-ghost !px-2.5 !py-1.5 text-xs" onClick={() => act(u, "unban")}>Разблокировать</button> : u.role !== "admin" && <button className="btn btn-danger !px-2.5 !py-1.5 text-xs" onClick={() => { const reason = prompt(`Причина блокировки @${u.username}:`) ; if (reason !== null) act(u, "ban", { reason }); }}>Блокировать</button>}
                          {u.role === "admin" ? <button className="btn btn-ghost !px-2.5 !py-1.5 text-xs" onClick={() => confirm(`Снять права администратора у @${u.username}?`) && act(u, "removeAdmin")}>Снять админа</button> : !u.isBanned && <button className="btn btn-ghost !px-2.5 !py-1.5 text-xs" onClick={() => confirm(`Выдать права администратора @${u.username}?`) && act(u, "makeAdmin")}>Сделать админом</button>}
                          {u.role !== "admin" && <button className="btn btn-ghost !px-2.5 !py-1.5 text-xs" onClick={() => warn(u)}>Предупредить</button>}
                        </>
                      )}
                      <button className="btn btn-ghost !px-2.5 !py-1.5 text-xs" title="Ссылка для сброса пароля" onClick={() => act(u, "resetLink")}><Icon name="link" size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {data && data.total > 30 && (
        <div className="mt-4 flex items-center justify-between text-sm text-muted">
          <span>Всего: {data.total}</span>
          <div className="flex gap-2">
            <button className="btn btn-ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Назад</button>
            <button className="btn btn-ghost" disabled={(page + 1) * 30 >= data.total} onClick={() => setPage((p) => p + 1)}>Вперёд</button>
          </div>
        </div>
      )}
      {link && (
        <Modal title="Ссылка для сброса пароля" onClose={() => setLink(null)} width="max-w-md" footer={<button className="btn btn-primary" onClick={() => { navigator.clipboard?.writeText(link); toast("Скопировано", "success"); }}><Icon name="copy" size={16} />Копировать</button>}>
          <div className="space-y-3 p-5 text-sm">
            <p className="text-muted">Передайте ссылку пользователю по надёжному каналу. Она действует 1 час и одноразовая.</p>
            <input className="input font-mono text-xs" readOnly value={link} onFocus={(e) => e.target.select()} />
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ---------- reports ---------- */
type Report = { id: string; reason: string; status: string; note: string | null; createdAt: string; reporter: string | null; targetId: string | null; target: string | null; targetBanned: boolean | null; messageBody: string | null; messageDeleted: string | null; messageType: string | null };

function ReportsTab() {
  const toast = useToast();
  const [status, setStatus] = useState("open");
  const { data, error, load } = useLoad<{ reports: Report[] }>(`/api/admin/reports?status=${status}`);
  async function resolve(r: Report, st: string) {
    const note = st === "open" ? "" : (prompt("Комментарий (необязательно):") ?? "");
    try { await api("/api/admin/reports", { method: "PATCH", body: { id: r.id, status: st, note } }); load(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }
  async function warn(r: Report) {
    if (!r.targetId) return;
    try { await api("/api/admin/warnings", { body: { userId: r.targetId, reason: `Жалоба: ${r.reason}` } }); toast("Предупреждение выдано", "success"); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }
  async function ban(r: Report) {
    if (!r.targetId) return;
    const reason = prompt("Причина блокировки:", r.reason);
    if (reason === null) return;
    try { await api("/api/admin/users", { method: "PATCH", body: { userId: r.targetId, action: "ban", reason } }); toast("Пользователь заблокирован", "success"); load(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); }
  }
  return (
    <div className="anim-up">
      <div className="mb-4 flex gap-2">
        {([["open", "Открытые"], ["resolved", "Решённые"], ["dismissed", "Отклонённые"], ["all", "Все"]] as const).map(([id, l]) => (
          <button key={id} onClick={() => setStatus(id)} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${status === id ? "grad text-white" : "bg-panel2 text-muted hover:text-fg"}`}>{l}</button>
        ))}
      </div>
      {!data ? <Loading error={error} /> : data.reports.length === 0 ? <Empty icon="flag" title="Жалоб нет" /> : (
        <div className="space-y-3">
          {data.reports.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <Badge tone={r.status === "open" ? "warn" : r.status === "resolved" ? "ok" : "muted"}>{r.status === "open" ? "открыта" : r.status === "resolved" ? "решена" : "отклонена"}</Badge>
                <span className="text-muted">от <b className="text-fg">@{r.reporter ?? "удалён"}</b> на <b className="text-fg">@{r.target ?? "удалён"}</b>{r.targetBanned && " (заблокирован)"}</span>
                <span className="ml-auto text-xs text-muted">{dt(r.createdAt)}</span>
              </div>
              <div className="mt-2 font-semibold">{r.reason}</div>
              {r.messageType && (
                <div className="mt-2 rounded-xl bg-panel2 p-3 text-sm"><span className="text-xs font-bold uppercase text-muted">Сообщение:</span> {r.messageDeleted ? <i className="text-muted">удалено</i> : r.messageBody || `[${r.messageType}]`}</div>
              )}
              {r.note && <div className="mt-2 text-xs text-muted">Комментарий: {r.note}</div>}
              <div className="mt-3 flex flex-wrap gap-2">
                {r.status === "open" ? (
                  <>
                    <button className="btn btn-primary !py-1.5 text-xs" onClick={() => resolve(r, "resolved")}>Решено</button>
                    <button className="btn btn-ghost !py-1.5 text-xs" onClick={() => resolve(r, "dismissed")}>Отклонить</button>
                    {r.targetId && <button className="btn btn-ghost !py-1.5 text-xs" onClick={() => warn(r)}>Предупредить</button>}
                    {r.targetId && !r.targetBanned && <button className="btn btn-danger !py-1.5 text-xs" onClick={() => ban(r)}>Заблокировать</button>}
                  </>
                ) : <button className="btn btn-ghost !py-1.5 text-xs" onClick={() => resolve(r, "open")}>Вернуть в работу</button>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- groups ---------- */
type AGroup = { id: string; title: string | null; description: string; createdAt: string; lastMessageAt: string; members: number; messages: number; owner: string | null };

function GroupsTab() {
  const toast = useToast();
  const { data, error, load } = useLoad<{ groups: AGroup[] }>("/api/admin/groups");
  if (!data) return <Loading error={error} />;
  if (!data.groups.length) return <Empty icon="users" title="Групп пока нет" />;
  return (
    <div className="card anim-up overflow-x-auto">
      <table className="w-full min-w-[640px] text-sm">
        <thead><tr className="border-b border-line text-left text-xs uppercase tracking-wider text-muted"><th className="p-3">Группа</th><th className="p-3">Владелец</th><th className="p-3">Участников</th><th className="p-3">Сообщений</th><th className="p-3">Активность</th><th className="p-3" /></tr></thead>
        <tbody>
          {data.groups.map((g) => (
            <tr key={g.id} className="border-b border-line/60 last:border-0 hover:bg-panel2/60">
              <td className="p-3"><div className="font-semibold">{g.title}</div><div className="max-w-xs truncate text-xs text-muted">{g.description}</div></td>
              <td className="p-3">{g.owner ? `@${g.owner}` : "—"}</td>
              <td className="p-3">{g.members}</td>
              <td className="p-3">{g.messages}</td>
              <td className="p-3 text-muted">{dt(g.lastMessageAt)}</td>
              <td className="p-3 text-right"><button className="btn btn-danger !px-3 !py-1.5 text-xs" onClick={async () => { if (!confirm(`Удалить группу «${g.title}» вместе со всей перепиской?`)) return; try { await api(`/api/admin/groups?id=${g.id}`, { method: "DELETE" }); toast("Группа удалена", "success"); load(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } }}>Удалить</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- warnings ---------- */
function WarningsTab() {
  const toast = useToast();
  const { data, error, load } = useLoad<{ warnings: { id: string; reason: string; createdAt: string; user: string | null; issuedBy: string | null }[] }>("/api/admin/warnings");
  if (!data) return <Loading error={error} />;
  return (
    <div className="anim-up">
      <p className="mb-4 text-sm text-muted">Предупреждения выдаются во вкладке «Пользователи» или из жалобы. При достижении лимита (настраивается в правилах) аккаунт блокируется автоматически.</p>
      {!data.warnings.length ? <Empty icon="warning" title="Предупреждений нет" /> : (
        <div className="space-y-2">
          {data.warnings.map((w) => (
            <div key={w.id} className="card flex items-center gap-3 p-4">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-warn/15 text-warn"><Icon name="warning" size={18} /></span>
              <div className="min-w-0 flex-1"><div className="font-semibold">@{w.user ?? "удалён"}</div><div className="text-sm text-muted">{w.reason}</div></div>
              <div className="hidden text-right text-xs text-muted sm:block">от @{w.issuedBy ?? "?"}<br />{dt(w.createdAt)}</div>
              <button className="icon-btn" title="Отозвать" onClick={async () => { if (!confirm("Отозвать предупреждение?")) return; try { await api(`/api/admin/warnings?id=${w.id}`, { method: "DELETE" }); load(); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } }}><Icon name="trash" size={17} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- logs ---------- */
const ACTIONS: Record<string, string> = {
  ban: "Блокировка", unban: "Разблокировка", auto_ban: "Автоблокировка", grant_admin: "Выдача прав админа", revoke_admin: "Снятие прав админа",
  warn: "Предупреждение", delete_warning: "Отзыв предупреждения", delete_group: "Удаление группы", update_settings: "Изменение настроек",
  reset_link: "Ссылка сброса пароля", report_resolved: "Жалоба решена", report_dismissed: "Жалоба отклонена", report_open: "Жалоба возвращена",
};

function LogsTab() {
  const { data, error } = useLoad<{ logs: { id: string; action: string; details: string; createdAt: string; admin: string | null }[] }>("/api/admin/logs");
  if (!data) return <Loading error={error} />;
  if (!data.logs.length) return <Empty icon="list" title="Журнал пуст" text="Действия администраторов будут записываться здесь." />;
  return (
    <div className="card anim-up divide-y divide-line">
      {data.logs.map((l) => (
        <div key={l.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 p-3.5 text-sm">
          <Badge tone={l.action.includes("ban") && !l.action.includes("unban") ? "danger" : "accent"}>{ACTIONS[l.action] ?? l.action}</Badge>
          <span className="font-semibold">@{l.admin ?? "удалён"}</span>
          <span className="min-w-0 flex-1 truncate text-muted">{l.details}</span>
          <span className="text-xs text-muted">{dt(l.createdAt)}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------- settings / rules ---------- */
function SettingsTab() {
  const toast = useToast();
  const { data, error } = useLoad<{ settings: Record<string, string> }>("/api/admin/settings");
  const [f, setF] = useState<Record<string, string> | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data) setF(data.settings); }, [data]);
  if (!f) return <Loading error={error} />;
  const set = (k: string, v: string) => setF({ ...f, [k]: v });
  const num = (k: string, label: string, hint: string) => (
    <div><label className="label">{label}</label><input className="input" type="number" value={f[k]} onChange={(e) => set(k, e.target.value)} /><p className="mt-1 text-xs text-muted">{hint}</p></div>
  );
  return (
    <div className="anim-up max-w-2xl space-y-5">
      <div className="card p-5">
        <label className="label">Правила платформы</label>
        <textarea className="input min-h-48 resize-y" value={f.rules} onChange={(e) => set("rules", e.target.value)} />
        <p className="mt-1 text-xs text-muted">Показываются при регистрации и в настройках пользователя.</p>
      </div>
      <div className="card space-y-4 p-5">
        <div className="flex items-center justify-between gap-4">
          <div><div className="font-semibold">Открытая регистрация</div><div className="text-xs text-muted">Если выключить, новые аккаунты создать нельзя</div></div>
          <Toggle checked={f.registrationOpen === "true"} onChange={(v) => set("registrationOpen", String(v))} />
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          {num("maxUploadMb", "Лимит файла, МБ", "1–200")}
          {num("maxGroupMembers", "Участников в группе", "2–1000")}
          {num("warningsBeforeBan", "Предупреждений до бана", "1–20")}
        </div>
      </div>
      <button className="btn btn-primary" disabled={busy} onClick={async () => {
        setBusy(true);
        try { await api("/api/admin/settings", { method: "PUT", body: { ...f, registrationOpen: f.registrationOpen === "true" } }); toast("Настройки сохранены", "success"); } catch (e) { toast(e instanceof Error ? e.message : "Ошибка", "error"); } finally { setBusy(false); }
      }}>{busy ? <Spinner size={16} /> : "Сохранить"}</button>
    </div>
  );
}
