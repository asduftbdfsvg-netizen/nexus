"use client";

import { createContext, useContext } from "react";
import type { ChatDTO, SelfDTO, UserDTO } from "@/lib/chat";

export type ServerEvent = { type: string; [key: string]: unknown };

export type Modal =
  | null
  | { kind: "settings"; tab?: string }
  | { kind: "friends"; tab?: string }
  | { kind: "newGroup" }
  | { kind: "notifications" }
  | { kind: "favorites" }
  | { kind: "forward"; messageId: string }
  | { kind: "report"; messageId?: string; userId?: string }
  | { kind: "profile"; userId: string }
  | { kind: "addMembers"; chatId: string }
  | { kind: "groupSettings"; chatId: string };

export type AppCtx = {
  me: SelfDTO;
  setMe: (u: SelfDTO) => void;
  chats: ChatDTO[];
  refreshChats: () => Promise<void>;
  activeChat: ChatDTO | null;
  openChat: (id: string | null) => void;
  openDirect: (userId: string) => Promise<void>;
  modal: Modal;
  setModal: (m: Modal) => void;
  subscribe: (fn: (e: ServerEvent) => void) => () => void;
  showInfo: boolean;
  setShowInfo: (v: boolean) => void;
  chatName: (c: ChatDTO) => string;
  chatAvatar: (c: ChatDTO) => string | null;
  startCall: (chatId: string, kind: "voice" | "video") => void;
  joinCall: (chatId: string, kind: string) => void;
  inCallChatId: string | null;
  logout: () => Promise<void>;
};

export const AppContext = createContext<AppCtx | null>(null);
export function useApp() {
  const v = useContext(AppContext);
  if (!v) throw new Error("AppContext missing");
  return v;
}
export type { ChatDTO, SelfDTO, UserDTO };
