"use client";

import { memo, useState } from "react";
import { fmtSize, fmtTime, QUICK_REACTIONS } from "@/lib/client";
import type { MessageDTO } from "@/lib/chat";
import { Avatar, Icon, useClickOutside } from "./ui";
import { previewText } from "./Sidebar";

export type MsgActions = {
  reply: (m: MessageDTO) => void;
  edit: (m: MessageDTO) => void;
  remove: (m: MessageDTO) => void;
  forward: (m: MessageDTO) => void;
  pin: (m: MessageDTO) => void;
  favorite: (m: MessageDTO) => void;
  react: (m: MessageDTO, emoji: string) => void;
  report: (m: MessageDTO) => void;
  copy: (m: MessageDTO) => void;
  jump: (id: string) => void;
  openProfile: (userId: string) => void;
};

function Linkified({ text }: { text: string }) {
  const parts = text.split(/(https?:\/\/[^\s<>"]+)/g);
  return (
    <>
      {parts.map((p, i) =>
        /^https?:\/\//.test(p) ? (
          <a key={i} href={p} target="_blank" rel="noopener noreferrer nofollow" className="underline underline-offset-2 opacity-95 hover:opacity-100">{p}</a>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

function Ticks({ status, onGrad }: { status: MessageDTO["status"]; onGrad: boolean }) {
  if (!status) return null;
  const read = status === "read";
  return (
    <Icon
      name={status === "sent" ? "check" : "checkCheck"}
      size={15}
      className={read ? (onGrad ? "text-white" : "text-accent") : onGrad ? "text-white/60" : "text-muted"}
    />
  );
}

type Props = {
  m: MessageDTO;
  mine: boolean;
  isGroup: boolean;
  first: boolean;
  last: boolean;
  square: boolean;
  canModerate: boolean;
  canPin: boolean;
  highlight: boolean;
  actions: MsgActions;
};

function Bubble({ m, mine, isGroup, first, last, square, canModerate, canPin, highlight, actions }: Props) {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [zoom, setZoom] = useState(false);
  const ref = useClickOutside<HTMLDivElement>(() => { setMenu(false); setOpen(false); });

  if (m.type === "system") {
    return <div className="anim-fade my-2 flex justify-center"><span className="rounded-full bg-panel2 px-3 py-1 text-xs text-muted">{m.body}</span></div>;
  }

  const deleted = !!m.deletedAt;
  const sticker = m.type === "sticker" && !deleted;
  const mediaOnly = !deleted && (m.type === "gif" || (m.type === "image" && !m.body)) ;
  const r = square ? "rounded-md" : "rounded-2xl";
  const corner = mine ? (last ? (square ? "rounded-br-sm" : "rounded-br-md") : "") : last ? (square ? "rounded-bl-sm" : "rounded-bl-md") : "";
  const onGrad = mine && !sticker;
  const bubbleCls = sticker ? "" : mine ? "grad text-white" : "bg-bubble-in text-bubble-in-fg border border-line";

  return (
    <div className={`msg-row anim-msg group relative flex items-end gap-2 ${mine ? "justify-end" : "justify-start"} ${first ? "mt-2" : "mt-0.5"}`} id={`msg-${m.id}`}>
      {isGroup && !mine && (
        <div className="w-8 shrink-0">
          {last && m.sender && (
            <button onClick={() => m.sender && actions.openProfile(m.sender.id)}><Avatar name={m.sender.displayName} src={m.sender.avatarUrl} size={32} /></button>
          )}
        </div>
      )}
      <div ref={ref} className={`relative max-w-[82%] md:max-w-[68%] ${highlight ? "animate-pulse" : ""}`}>
        {/* floating action bar */}
        {!deleted && (
          <div className={`absolute -top-9 z-20 items-center gap-0.5 rounded-xl border border-line bg-panel p-0.5 shadow-lg ${mine ? "right-0" : "left-0"} ${open || menu ? "flex" : "hidden md:group-hover:flex"}`} style={{ boxShadow: "var(--shadow)" }}>
            {QUICK_REACTIONS.slice(0, 5).map((e) => (
              <button key={e} onClick={() => { actions.react(m, e); setOpen(false); }} className="grid h-7 w-7 place-items-center rounded-lg text-base transition hover:scale-125 hover:bg-panel2">{e}</button>
            ))}
            <button className="icon-btn !h-7 !w-7" title="Ответить" onClick={() => { actions.reply(m); setOpen(false); }}><Icon name="reply" size={15} /></button>
            <button className="icon-btn !h-7 !w-7" title="Ещё" onClick={() => setMenu((v) => !v)}><Icon name="more" size={15} /></button>
          </div>
        )}
        {menu && (
          <div className={`anim-pop absolute top-1 z-30 w-52 overflow-hidden rounded-xl border border-line bg-panel py-1 text-fg ${mine ? "right-0" : "left-0"}`} style={{ boxShadow: "var(--shadow)" }}>
            {QUICK_REACTIONS.length > 5 && (
              <div className="flex justify-around border-b border-line px-2 pb-1.5 pt-1">
                {QUICK_REACTIONS.slice(5).concat(["👏", "🎉", "🙏"]).map((e) => (
                  <button key={e} onClick={() => { actions.react(m, e); setMenu(false); setOpen(false); }} className="text-lg transition hover:scale-125">{e}</button>
                ))}
              </div>
            )}
            {([
              ["reply", "Ответить", () => actions.reply(m), true],
              ["copy", "Копировать текст", () => actions.copy(m), !!m.body],
              ["forward", "Переслать", () => actions.forward(m), true],
              ["edit", "Редактировать", () => actions.edit(m), mine && !["sticker", "gif"].includes(m.type)],
              ["pin", m.pinnedAt ? "Открепить" : "Закрепить", () => actions.pin(m), canPin],
              ["star", m.favorite ? "Убрать из избранного" : "В избранное", () => actions.favorite(m), true],
              ["flag", "Пожаловаться", () => actions.report(m), !mine],
              ["trash", "Удалить", () => actions.remove(m), mine || canModerate],
            ] as [string, string, () => void, boolean][]).filter((i) => i[3]).map(([icon, label, fn]) => (
              <button key={label} onClick={() => { fn(); setMenu(false); setOpen(false); }} className={`flex w-full items-center gap-3 px-3.5 py-2 text-sm hover:bg-panel2 ${icon === "trash" ? "text-danger" : ""}`}>
                <Icon name={icon} size={16} />{label}
              </button>
            ))}
          </div>
        )}

        <div
          onClick={() => !deleted && setOpen((v) => !v)}
          className={`${sticker || mediaOnly ? "" : "px-3.5 py-2"} ${sticker ? "" : `${r} ${corner} ${bubbleCls}`} ${mediaOnly ? `${r} overflow-hidden` : ""} ${deleted ? "!bg-panel2 !text-muted !border-line italic !bg-none" : ""} relative cursor-default shadow-sm`}
        >
          {!deleted && m.forwardedFrom && (
            <div className={`mb-1 flex items-center gap-1 text-xs font-semibold ${onGrad ? "text-white/80" : "text-accent"}`}><Icon name="forward" size={12} />Переслано от {m.forwardedFrom}</div>
          )}
          {isGroup && !mine && first && m.sender && !sticker && (
            <button onClick={(e) => { e.stopPropagation(); m.sender && actions.openProfile(m.sender.id); }} className="mb-0.5 block text-xs font-bold text-accent hover:underline">{m.sender.displayName}</button>
          )}
          {m.replyTo && !deleted && (
            <button
              onClick={(e) => { e.stopPropagation(); actions.jump(m.replyTo!.id); }}
              className={`mb-1.5 block w-full overflow-hidden rounded-lg border-l-[3px] px-2.5 py-1 text-left text-xs ${onGrad ? "border-white/70 bg-white/15" : "border-accent bg-accent/10"}`}
            >
              <div className={`truncate font-bold ${onGrad ? "text-white" : "text-accent"}`}>{m.replyTo.senderName}</div>
              <div className="truncate opacity-80">{previewText(m.replyTo.type, m.replyTo.body, m.replyTo.deleted)}</div>
            </button>
          )}

          {deleted ? (
            <span className="flex items-center gap-1.5 text-sm"><Icon name="block" size={14} />Сообщение удалено</span>
          ) : (
            <>
              {sticker && <div className="text-7xl leading-none drop-shadow-sm">{m.body}</div>}
              {m.attachment && m.type === "image" && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={m.attachment.url} alt={m.attachment.name ?? "image"} loading="lazy" onClick={(e) => { e.stopPropagation(); setZoom(true); }} className={`max-h-80 w-full min-w-[160px] cursor-zoom-in object-cover ${mediaOnly ? "" : "mb-1 rounded-xl"}`} />
              )}
              {m.attachment && m.type === "gif" && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={m.attachment.url} alt="gif" loading="lazy" className="max-h-72 min-w-[160px] object-cover" />
              )}
              {m.attachment && m.type === "video" && <video src={m.attachment.url} controls preload="metadata" playsInline className="mb-1 max-h-80 w-full rounded-xl bg-black" onClick={(e) => e.stopPropagation()} />}
              {m.attachment && m.type === "audio" && <audio src={m.attachment.url} controls preload="metadata" className="mb-1 h-10 w-64 max-w-full" onClick={(e) => e.stopPropagation()} />}
              {m.attachment && m.type === "file" && (
                <a href={m.attachment.url} download={m.attachment.name ?? true} onClick={(e) => e.stopPropagation()} className={`mb-1 flex items-center gap-3 rounded-xl p-2 pr-4 ${onGrad ? "bg-white/15" : "bg-panel2"}`}>
                  <span className={`grid h-10 w-10 place-items-center rounded-xl ${onGrad ? "bg-white/25" : "grad text-white"}`}><Icon name="file" size={20} /></span>
                  <span className="min-w-0">
                    <span className="block max-w-[200px] truncate text-sm font-semibold">{m.attachment.name ?? "Файл"}</span>
                    <span className="block text-xs opacity-70">{fmtSize(m.attachment.size)}</span>
                  </span>
                  <Icon name="download" size={18} className="ml-1 opacity-80" />
                </a>
              )}
              {m.body && !sticker && <div className="whitespace-pre-wrap break-words text-[0.94rem] leading-snug"><Linkified text={m.body} /></div>}
            </>
          )}

          {!sticker && (
            <div className={`mt-0.5 flex items-center justify-end gap-1 text-[11px] leading-none ${mediaOnly ? "absolute bottom-1.5 right-1.5 rounded-full bg-black/55 px-2 py-1 text-white" : onGrad ? "text-white/75" : "text-muted"}`}>
              {m.pinnedAt && <Icon name="pin" size={11} />}
              {m.favorite && <Icon name="star" size={11} fill />}
              {m.editedAt && !deleted && <span>изменено</span>}
              <span>{fmtTime(m.createdAt)}</span>
              {mine && !deleted && <Ticks status={m.status} onGrad={onGrad || mediaOnly} />}
            </div>
          )}
        </div>

        {sticker && (
          <div className={`mt-0.5 flex items-center gap-1 text-[11px] text-muted ${mine ? "justify-end" : ""}`}>
            <span>{fmtTime(m.createdAt)}</span>{mine && <Ticks status={m.status} onGrad={false} />}
          </div>
        )}

        {m.reactions.length > 0 && !deleted && (
          <div className={`mt-1 flex flex-wrap gap-1 ${mine ? "justify-end" : ""}`}>
            {m.reactions.map((r) => (
              <button
                key={r.emoji}
                onClick={() => actions.react(m, r.emoji)}
                className={`anim-pop flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs transition hover:scale-105 ${r.mine ? "border-accent bg-accent/20" : "border-line bg-panel2"}`}
              >
                <span className="text-sm">{r.emoji}</span><span className="font-semibold">{r.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {zoom && m.attachment && (
        <div className="anim-fade fixed inset-0 z-[90] grid place-items-center bg-black/85 p-4" onClick={() => setZoom(false)}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={m.attachment.url} alt="" className="anim-pop max-h-full max-w-full rounded-xl object-contain" />
          <a href={m.attachment.url} download={m.attachment.name ?? true} onClick={(e) => e.stopPropagation()} className="btn btn-primary absolute bottom-6"><Icon name="download" size={16} />Скачать</a>
          <button className="icon-btn absolute right-4 top-4 !text-white" onClick={() => setZoom(false)}><Icon name="x" /></button>
        </div>
      )}
    </div>
  );
}

export default memo(Bubble);
