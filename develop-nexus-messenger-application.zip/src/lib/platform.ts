import { eq } from "drizzle-orm";
import { db } from "@/db";
import { adminLogs, platformSettings } from "@/db/schema";

export const DEFAULT_RULES = `1. Уважайте других участников — оскорбления и травля запрещены.
2. Не рассылайте спам и рекламу без согласия получателей.
3. Запрещён незаконный контент, угрозы и разглашение чужих персональных данных.
4. Не выдавайте себя за других людей.
5. Нарушения приводят к предупреждению или блокировке аккаунта.`;

export const SETTING_DEFAULTS: Record<string, string> = {
  rules: DEFAULT_RULES,
  registrationOpen: "true",
  maxUploadMb: "25",
  maxGroupMembers: "200",
  warningsBeforeBan: "3",
};

export async function getSettings(): Promise<Record<string, string>> {
  const rows = await db.select().from(platformSettings);
  const out = { ...SETTING_DEFAULTS };
  for (const r of rows) out[r.key] = r.value;
  return out;
}

export async function getSetting(key: string) {
  const [row] = await db.select().from(platformSettings).where(eq(platformSettings.key, key)).limit(1);
  return row?.value ?? SETTING_DEFAULTS[key] ?? "";
}

export async function logAdmin(adminId: string, action: string, targetType: string, targetId: string, details = "") {
  await db.insert(adminLogs).values({ adminId, action, targetType, targetId, details });
}
