import { and, eq, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  blocks,
  chatMembers,
  chats,
  favorites,
  friendships,
  messages,
  notifications,
  reactions,
  users,
  type ChatPermissions,
} from "@/db/schema";
import { ApiError } from "./api";
import { isConnected, publish } from "./events";
import type { User } from "./auth";

type UserRow = typeof users.$inferSelect;
type MessageRow = typeof messages.$inferSelect;

export type UserDTO = {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string | null;
  presence: "online" | "away" | "dnd" | "offline";
  lastSeen: string | null;
  role: string;
  isFriend: boolean;
};

export function effectivePresence(u: Pick<UserRow, "id" | "status" | "lastSeen">): UserDTO["presence"] {
  if (u.status === "invisible") return "offline";
  const alive = isConnected(u.id) || Date.now() - u.lastSeen.getTime() < 90_000;
  if (!alive) return "offline";
  return (u.status as UserDTO["presence"]) || "online";
}

export async function friendIdsOf(userId: string): Promise<Set<string>> {
  const rows = await db
    .select()
    .from(friendships)
    .where(and(eq(friendships.status, "accepted"), or(eq(friendships.requesterId, userId), eq(friendships.addresseeId, userId))));
  return new Set(rows.map((r) => (r.requesterId === userId ? r.addresseeId : r.requesterId)));
}

function visible(setting: string, friend: boolean) {
  return setting === "everyone" || (setting === "friends" && friend);
}

export function presentUser(u: UserRow, viewerId: string, friends: Set<string>): UserDTO {
  const self = u.id === viewerId;
  const friend = friends.has(u.id);
  const p = u.settings?.privacy;
  const seeLast = self || visible(p?.lastSeen ?? "everyone", friend);
  const seeAvatar = self || visible(p?.avatar ?? "everyone", friend);
  const real = effectivePresence(u);
  return {
    id: u.id,
    username: u.username,
    displayName: u.displayName,
    bio: u.bio,
    avatarUrl: seeAvatar ? u.avatarUrl : null,
    presence: self ? (u.status === "invisible" ? "offline" : real) : seeLast ? real : "offline",
    lastSeen: seeLast ? u.lastSeen.toISOString() : null,
    role: u.role,
    isFriend: friend,
  };
}

export async function presentUsers(rows: UserRow[], viewerId: string) {
  const friends = await friendIdsOf(viewerId);
  return rows.map((u) => presentUser(u, viewerId, friends));
}

export function directKey(a: string, b: string) {
  return [a, b].sort().join(":");
}

export async function isBlockedBetween(a: string, b: string) {
  const rows = await db
    .select()
    .from(blocks)
    .where(or(and(eq(blocks.blockerId, a), eq(blocks.blockedId, b)), and(eq(blocks.blockerId, b), eq(blocks.blockedId, a))));
  return rows.length > 0;
}

export async function memberIds(chatId: string): Promise<string[]> {
  const rows = await db.select({ id: chatMembers.userId }).from(chatMembers).where(eq(chatMembers.chatId, chatId));
  return rows.map((r) => r.id);
}

export async function requireMember(chatId: string, userId: string) {
  const [row] = await db
    .select({ chat: chats, member: chatMembers })
    .from(chatMembers)
    .innerJoin(chats, eq(chats.id, chatMembers.chatId))
    .where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userId, userId)))
    .limit(1);
  if (!row) throw new ApiError(404, "Чат не найден");
  return row;
}

export function isStaff(role: string) {
  return role === "owner" || role === "admin";
}

export function can(chat: { type: string; permissions: ChatPermissions }, role: string, perm: keyof ChatPermissions) {
  if (chat.type === "direct") return true;
  return isStaff(role) || chat.permissions[perm] === true;
}

export async function notify(
  userId: string,
  n: { type: string; title: string; body?: string; data?: Record<string, string> },
  kind?: "friendRequests" | "groups",
) {
  if (kind) {
    const [u] = await db.select({ s: users.settings }).from(users).where(eq(users.id, userId)).limit(1);
    if (u && u.s?.notifications?.[kind] === false) return;
  }
  const [row] = await db
    .insert(notifications)
    .values({ userId, type: n.type, title: n.title, body: n.body ?? "", data: n.data ?? {} })
    .returning();
  publish([userId], { type: "notification", notification: row });
}

export async function coMemberIds(userId: string): Promise<string[]> {
  const mine = db.select({ id: chatMembers.chatId }).from(chatMembers).where(eq(chatMembers.userId, userId));
  const rows = await db
    .selectDistinct({ id: chatMembers.userId })
    .from(chatMembers)
    .where(inArray(chatMembers.chatId, mine));
  return rows.map((r) => r.id).filter((id) => id !== userId);
}

export async function broadcastPresence(userId: string) {
  publish(await coMemberIds(userId), { type: "presence", userId });
}

export type MessageDTO = {
  id: string;
  chatId: string;
  seq: number;
  type: string;
  body: string;
  attachment: { url: string; name: string | null; size: number | null; mime: string | null } | null;
  sender: { id: string; displayName: string; username: string; avatarUrl: string | null } | null;
  replyTo: { id: string; body: string; type: string; senderName: string; deleted: boolean } | null;
  forwardedFrom: string | null;
  editedAt: string | null;
  deletedAt: string | null;
  pinnedAt: string | null;
  createdAt: string;
  reactions: { emoji: string; count: number; mine: boolean }[];
  favorite: boolean;
  status: "sent" | "delivered" | "read" | null;
};

export async function serializeMessages(rows: MessageRow[], viewerId: string): Promise<MessageDTO[]> {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const chatIds = [...new Set(rows.map((r) => r.chatId))];
  const replyIds = [...new Set(rows.map((r) => r.replyToId).filter((x): x is string => !!x))];

  const [reacts, favs, members, replies] = await Promise.all([
    db.select().from(reactions).where(inArray(reactions.messageId, ids)),
    db.select().from(favorites).where(and(eq(favorites.userId, viewerId), inArray(favorites.messageId, ids))),
    db
      .select({ m: chatMembers, s: users.settings })
      .from(chatMembers)
      .innerJoin(users, eq(users.id, chatMembers.userId))
      .where(inArray(chatMembers.chatId, chatIds)),
    replyIds.length
      ? db
          .select({ m: messages, u: users.displayName })
          .from(messages)
          .leftJoin(users, eq(users.id, messages.senderId))
          .where(inArray(messages.id, replyIds))
      : Promise.resolve([]),
  ]);

  const senderIds = [...new Set(rows.map((r) => r.senderId).filter((x): x is string => !!x))];
  const senderRows = senderIds.length ? await db.select().from(users).where(inArray(users.id, senderIds)) : [];
  const senders = new Map((await presentUsers(senderRows, viewerId)).map((u) => [u.id, u]));
  const replyMap = new Map(replies.map((r) => [r.m.id, r]));
  const favSet = new Set(favs.map((f) => f.messageId));

  return rows.map((m) => {
    const deleted = !!m.deletedAt;
    const rs = reacts.filter((r) => r.messageId === m.id);
    const grouped = new Map<string, { emoji: string; count: number; mine: boolean }>();
    for (const r of rs) {
      const g = grouped.get(r.emoji) ?? { emoji: r.emoji, count: 0, mine: false };
      g.count++;
      if (r.userId === viewerId) g.mine = true;
      grouped.set(r.emoji, g);
    }
    let status: MessageDTO["status"] = null;
    if (m.senderId === viewerId && m.type !== "system") {
      const others = members.filter((x) => x.m.chatId === m.chatId && x.m.userId !== viewerId);
      const read = others.some((o) => o.m.lastReadAt >= m.createdAt && o.s?.privacy?.readReceipts !== false);
      const delivered = others.some((o) => o.m.lastDeliveredAt >= m.createdAt || o.m.lastReadAt >= m.createdAt);
      status = read ? "read" : delivered ? "delivered" : "sent";
    }
    const rep = m.replyToId ? replyMap.get(m.replyToId) : undefined;
    const s = m.senderId ? senders.get(m.senderId) : undefined;
    return {
      id: m.id,
      chatId: m.chatId,
      seq: m.seq,
      type: deleted ? "text" : m.type,
      body: deleted ? "" : m.body,
      attachment:
        !deleted && m.attachmentUrl
          ? { url: m.attachmentUrl, name: m.attachmentName, size: m.attachmentSize, mime: m.attachmentMime }
          : null,
      sender: s ? { id: s.id, displayName: s.displayName, username: s.username, avatarUrl: s.avatarUrl } : null,
      replyTo: rep
        ? {
            id: rep.m.id,
            body: rep.m.deletedAt ? "" : rep.m.body,
            type: rep.m.type,
            senderName: rep.u ?? "Удалённый пользователь",
            deleted: !!rep.m.deletedAt,
          }
        : null,
      forwardedFrom: deleted ? null : m.forwardedFrom,
      editedAt: m.editedAt?.toISOString() ?? null,
      deletedAt: m.deletedAt?.toISOString() ?? null,
      pinnedAt: deleted ? null : (m.pinnedAt?.toISOString() ?? null),
      createdAt: m.createdAt.toISOString(),
      reactions: deleted ? [] : [...grouped.values()],
      favorite: favSet.has(m.id),
      status,
    };
  });
}

export type ChatDTO = {
  id: string;
  type: string;
  title: string | null;
  description: string;
  avatarUrl: string | null;
  permissions: ChatPermissions;
  myRole: string;
  archived: boolean;
  muted: boolean;
  pinned: boolean;
  unread: number;
  memberCount: number;
  lastMessageAt: string;
  lastMessage: { id: string; body: string; type: string; senderId: string | null; senderName: string; deleted: boolean; createdAt: string } | null;
  peer: UserDTO | null;
  blockedByMe: boolean;
  blockedMe: boolean;
  activeCall: { id: string; kind: string; participants: number } | null;
};

const idList = (ids: string[]) => sql.join(ids.map((i) => sql`${i}`), sql`, `);

export async function listChats(userId: string, onlyChatId?: string): Promise<ChatDTO[]> {
  const mems = await db
    .select({ chat: chats, member: chatMembers })
    .from(chatMembers)
    .innerJoin(chats, eq(chats.id, chatMembers.chatId))
    .where(onlyChatId ? and(eq(chatMembers.userId, userId), eq(chatMembers.chatId, onlyChatId)) : eq(chatMembers.userId, userId));
  if (!mems.length) return [];
  const ids = mems.map((m) => m.chat.id);

  const [unreadRes, lastRes, countRes, callRes, peerRows, blockRows, friends] = await Promise.all([
    db.execute(sql`
      select m.chat_id as chat_id, count(*)::int as n
      from messages m join chat_members cm on cm.chat_id = m.chat_id and cm.user_id = ${userId}
      where m.chat_id in (${idList(ids)}) and m.created_at > cm.last_read_at
        and (m.sender_id is null or m.sender_id <> ${userId}) and m.deleted_at is null
      group by m.chat_id`),
    db.execute(sql`
      select distinct on (m.chat_id) m.id, m.chat_id, m.body, m.type, m.sender_id, m.deleted_at, m.created_at, u.display_name as sender_name
      from messages m left join users u on u.id = m.sender_id
      where m.chat_id in (${idList(ids)})
      order by m.chat_id, m.seq desc`),
    db.execute(sql`select chat_id, count(*)::int as n from chat_members where chat_id in (${idList(ids)}) group by chat_id`),
    db.execute(sql`
      select c.id, c.chat_id, c.kind, (select count(*)::int from call_participants p where p.call_id = c.id and p.left_at is null) as n
      from calls c where c.chat_id in (${idList(ids)}) and c.ended_at is null and c.started_at > now() - interval '12 hours'`),
    db
      .select({ chatId: chatMembers.chatId, user: users })
      .from(chatMembers)
      .innerJoin(users, eq(users.id, chatMembers.userId))
      .where(and(inArray(chatMembers.chatId, ids), sql`${chatMembers.userId} <> ${userId}`)),
    db.select().from(blocks).where(or(eq(blocks.blockerId, userId), eq(blocks.blockedId, userId))),
    friendIdsOf(userId),
  ]);

  const unread = new Map((unreadRes.rows as { chat_id: string; n: number }[]).map((r) => [r.chat_id, r.n]));
  const last = new Map(
    (lastRes.rows as { id: string; chat_id: string; body: string; type: string; sender_id: string | null; deleted_at: string | null; created_at: string | Date; sender_name: string | null }[]).map((r) => [r.chat_id, r]),
  );
  const counts = new Map((countRes.rows as { chat_id: string; n: number }[]).map((r) => [r.chat_id, r.n]));
  const callsMap = new Map(
    (callRes.rows as { id: string; chat_id: string; kind: string; n: number }[]).filter((r) => r.n > 0).map((r) => [r.chat_id, r]),
  );
  const peers = new Map(peerRows.map((r) => [r.chatId, r.user]));

  return mems
    .map(({ chat, member }) => {
      const l = last.get(chat.id);
      const peerRow = chat.type === "direct" ? peers.get(chat.id) : undefined;
      const call = callsMap.get(chat.id);
      return {
        id: chat.id,
        type: chat.type,
        title: chat.title,
        description: chat.description,
        avatarUrl: chat.avatarUrl,
        permissions: chat.permissions,
        myRole: member.role,
        archived: member.archived,
        muted: member.muted,
        pinned: member.pinned,
        unread: unread.get(chat.id) ?? 0,
        memberCount: counts.get(chat.id) ?? 0,
        lastMessageAt: chat.lastMessageAt.toISOString(),
        lastMessage: l
          ? {
              id: l.id,
              body: l.deleted_at ? "" : l.body,
              type: l.type,
              senderId: l.sender_id,
              senderName: l.sender_name ?? "",
              deleted: !!l.deleted_at,
              createdAt: new Date(l.created_at).toISOString(),
            }
          : null,
        peer: peerRow ? presentUser(peerRow, userId, friends) : null,
        blockedByMe: !!peerRow && blockRows.some((b) => b.blockerId === userId && b.blockedId === peerRow.id),
        blockedMe: !!peerRow && blockRows.some((b) => b.blockedId === userId && b.blockerId === peerRow.id),
        activeCall: call ? { id: call.id, kind: call.kind, participants: call.n } : null,
      } satisfies ChatDTO;
    })
    .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.lastMessageAt.localeCompare(a.lastMessageAt));
}

export function selfDTO(u: User) {
  return {
    id: u.id,
    email: u.email,
    username: u.username,
    displayName: u.displayName,
    bio: u.bio,
    avatarUrl: u.avatarUrl,
    status: u.status,
    role: u.role,
    settings: u.settings,
    createdAt: u.createdAt.toISOString(),
  };
}

export type SelfDTO = ReturnType<typeof selfDTO>;
