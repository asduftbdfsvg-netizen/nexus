export const USERNAME_RE = /^[a-z0-9_]{3,24}$/;

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export function route<P = Record<string, never>>(fn: (req: Request, ctx: { params: P }) => Promise<unknown>) {
  return async (req: Request, ctx: { params: Promise<P> }): Promise<Response> => {
    try {
      const params = await ctx.params;
      const res = await fn(req, { params });
      if (res instanceof Response) return res;
      return Response.json(res ?? { ok: true });
    } catch (e) {
      if (e instanceof ApiError) return Response.json({ error: e.message }, { status: e.status });
      console.error("[api]", e);
      return Response.json({ error: "Внутренняя ошибка сервера" }, { status: 500 });
    }
  };
}

export async function readJson<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    const data = await req.json();
    if (typeof data !== "object" || data === null) throw new Error();
    return data as T;
  } catch {
    throw new ApiError(400, "Некорректный запрос");
  }
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function isUuid(v: unknown): v is string {
  return typeof v === "string" && UUID_RE.test(v);
}
export function uuid(v: unknown, name = "id"): string {
  if (!isUuid(v)) throw new ApiError(400, `Некорректный ${name}`);
  return v;
}

export function str(v: unknown, name: string, opts: { min?: number; max?: number; optional?: boolean } = {}): string {
  const { min = 0, max = 2000, optional = false } = opts;
  if (v === undefined || v === null) {
    if (optional) return "";
    throw new ApiError(400, `Поле «${name}» обязательно`);
  }
  if (typeof v !== "string") throw new ApiError(400, `Поле «${name}» некорректно`);
  const s = v.trim();
  if (s.length < min) throw new ApiError(400, `Поле «${name}» слишком короткое (минимум ${min})`);
  if (s.length > max) throw new ApiError(400, `Поле «${name}» слишком длинное (максимум ${max})`);
  return s;
}

export function oneOf<T extends string>(v: unknown, allowed: readonly T[], name: string): T {
  if (typeof v === "string" && (allowed as readonly string[]).includes(v)) return v as T;
  throw new ApiError(400, `Некорректное значение «${name}»`);
}

// Very small in-memory rate limiter (per process).
const buckets = new Map<string, { n: number; reset: number }>();
export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) {
    buckets.set(key, { n: 1, reset: now + windowMs });
    if (buckets.size > 5000) for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
    return;
  }
  b.n++;
  if (b.n > limit) throw new ApiError(429, "Слишком много попыток. Попробуйте позже.");
}

export function clientIp(req: Request) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
}

// Only allow upload URLs produced by our own storage endpoint.
export function safeFileUrl(v: unknown): string | null {
  if (typeof v !== "string" || !v) return null;
  return /^\/api\/files\/[a-zA-Z0-9_-]+\.[a-zA-Z0-9]{1,8}$/.test(v) ? v : null;
}
