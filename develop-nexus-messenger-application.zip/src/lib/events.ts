// In-process pub/sub used for realtime delivery over Server-Sent Events
// (messages, typing, presence, notifications, WebRTC signaling).

export type ServerEvent = { type: string; [key: string]: unknown };
type Listener = (e: ServerEvent) => void;

const g = globalThis as typeof globalThis & { __nexusSubs?: Map<string, Set<Listener>> };
const subs: Map<string, Set<Listener>> = (g.__nexusSubs ??= new Map());

export function subscribe(userId: string, fn: Listener) {
  let set = subs.get(userId);
  if (!set) subs.set(userId, (set = new Set()));
  set.add(fn);
  return () => {
    const s = subs.get(userId);
    if (!s) return;
    s.delete(fn);
    if (s.size === 0) subs.delete(userId);
  };
}

export function publish(userIds: Iterable<string>, event: ServerEvent) {
  for (const id of new Set(userIds)) {
    const set = subs.get(id);
    if (!set) continue;
    for (const fn of set) {
      try {
        fn(event);
      } catch {
        /* ignore broken listener */
      }
    }
  }
}

export function isConnected(userId: string) {
  return (subs.get(userId)?.size ?? 0) > 0;
}
