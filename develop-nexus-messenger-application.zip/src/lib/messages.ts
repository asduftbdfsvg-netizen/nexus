import { eq, and, inArray } from "drizzle-orm";
import { db } from "@/db";
import { chatMembers, chats, messages, users } from "@/db/schema";
import { ApiError, safeFileUrl } from "./api";
import { isConnected, publish } from "./events";
import { can, friendIdsOf, isBlockedBetween, memberIds, requireMember } from "./chat";

export const MESSAGE_TYPES = ["text", "image", "video", "audio", "file", "sticker", "gif"] as const;

export type NewMessage = {
  chatId: string;
  senderId: string | null;
  type: string;
  body: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  attachmentSize?: number | null;
  attachmentMime?: string | null;
  replyToId?: string | null;
  forwardedFrom?: string | null;
};

export async function createMessage(m: NewMessage) {
  const [row] = await db
    .insert(messages)
    .values({
      chatId: m.chatId,
      senderId: m.senderId,
      type: m.type,
      body: m.body,
      attachmentUrl: m.attachmentUrl ?? null,
      attachmentName: m.attachmentName ?? null,
      attachmentSize: m.attachmentSize ?? null,
      attachmentMime: m.attachmentMime ?? null,
      replyToId: m.replyToId ?? null,
      forwardedFrom: m.forwardedFrom ?? null,
    })
    .returning();
  await db.update(chats).set({ lastMessageAt: row.createdAt }).where(eq(chats.id, m.chatId));
  const ids = await memberIds(m.chatId);
  const now = new Date();
  if (m.senderId) {
    await db
      .update(chatMembers)
      .set({ lastReadAt: now, lastDeliveredAt: now })
      .where(and(eq(chatMembers.chatId, m.chatId), eq(chatMembers.userId, m.senderId)));
  }
  const online = ids.filter((id) => id !== m.senderId && isConnected(id));
  if (online.length) {
    await db
      .update(chatMembers)
      .set({ lastDeliveredAt: now })
      .where(and(eq(chatMembers.chatId, m.chatId), inArray(chatMembers.userId, online)));
  }
  publish(ids, { type: "message", chatId: m.chatId, messageId: row.id, senderId: m.senderId });
  return row;
}

export async function systemMessage(chatId: string, body: string) {
  return createMessage({ chatId, senderId: null, type: "system", body });
}

// Validates payload from the client and verifies every server-side permission before a message is sent.
export async function validateAndSend(
  userId: string,
  chatId: string,
  input: {
    type?: unknown;
    text?: unknown;
    attachment?: { url?: unknown; name?: unknown; size?: unknown; mime?: unknown } | null;
    replyToId?: unknown;
  },
) {
  const { chat, member } = await requireMember(chatId, userId);
  const type = typeof input.type === "string" && (MESSAGE_TYPES as readonly string[]).includes(input.type) ? input.type : "text";
  const text = typeof input.text === "string" ? input.text.trim() : "";
  if (text.length > 4000) throw new ApiError(400, "Сообщение слишком длинное (максимум 4000 символов)");

  if (chat.type === "group") {
    if (!can(chat, member.role, "membersCanSend")) throw new ApiError(403, "В этом чате писать могут только администраторы");
    if (type !== "text" && type !== "sticker" && !can(chat, member.role, "membersCanSendMedia"))
      throw new ApiError(403, "Отправка медиа ограничена администраторами");
  } else {
    const others = (await memberIds(chatId)).filter((id) => id !== userId);
    const otherId = others[0];
    if (otherId) {
      if (await isBlockedBetween(userId, otherId)) throw new ApiError(403, "Отправка сообщений невозможна: пользователь заблокирован");
      const [o] = await db.select({ s: users.settings }).from(users).where(eq(users.id, otherId)).limit(1);
      if (o?.s?.privacy?.messages === "friends" && !(await friendIdsOf(userId)).has(otherId))
        throw new ApiError(403, "Пользователь принимает сообщения только от друзей");
    }
  }

  let attachmentUrl: string | null = null;
  let attachmentName: string | null = null;
  let attachmentSize: number | null = null;
  let attachmentMime: string | null = null;
  if (type === "gif") {
    const u = input.attachment?.url;
    if (typeof u !== "string" || !/^https:\/\/[^\s]{4,480}$/.test(u)) throw new ApiError(400, "Некорректная ссылка на GIF");
    attachmentUrl = u;
  } else if (["image", "video", "audio", "file"].includes(type)) {
    attachmentUrl = safeFileUrl(input.attachment?.url);
    if (!attachmentUrl) throw new ApiError(400, "Некорректное вложение");
    const a = input.attachment!;
    attachmentName = typeof a.name === "string" ? a.name.slice(0, 200) : null;
    attachmentSize = typeof a.size === "number" ? Math.max(0, Math.floor(a.size)) : null;
    attachmentMime = typeof a.mime === "string" ? a.mime.slice(0, 100) : null;
  } else if (!text) {
    throw new ApiError(400, "Пустое сообщение");
  }
  if (type === "sticker" && (!text || text.length > 16)) throw new ApiError(400, "Некорректный стикер");

  let replyToId: string | null = null;
  if (typeof input.replyToId === "string") {
    const [r] = await db
      .select({ id: messages.id })
      .from(messages)
      .where(and(eq(messages.id, input.replyToId), eq(messages.chatId, chatId)))
      .limit(1);
    if (r) replyToId = r.id;
  }
  return createMessage({ chatId, senderId: userId, type, body: text, attachmentUrl, attachmentName, attachmentSize, attachmentMime, replyToId });
}

export async function loadMessage(id: string, userId: string) {
  const [msg] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!msg) throw new ApiError(404, "Сообщение не найдено");
  const access = await requireMember(msg.chatId, userId);
  return { msg, ...access };
}
