import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { callParticipants, calls, users } from "@/db/schema";
import { ApiError } from "./api";
import { memberIds, requireMember } from "./chat";
import { publish } from "./events";

export async function activeParticipants(callId: string) {
  const rows = await db
    .select({ id: users.id, displayName: users.displayName, avatarUrl: users.avatarUrl })
    .from(callParticipants)
    .innerJoin(users, eq(users.id, callParticipants.userId))
    .where(and(eq(callParticipants.callId, callId), isNull(callParticipants.leftAt)));
  return rows;
}

export async function requireActiveCall(callId: string, userId: string) {
  const [call] = await db.select().from(calls).where(and(eq(calls.id, callId), isNull(calls.endedAt))).limit(1);
  if (!call) throw new ApiError(404, "Звонок завершён");
  const access = await requireMember(call.chatId, userId);
  return { call, ...access };
}

export async function joinCall(callId: string, userId: string, name: string) {
  const existing = await activeParticipants(callId);
  await db
    .insert(callParticipants)
    .values({ callId, userId })
    .onConflictDoUpdate({ target: [callParticipants.callId, callParticipants.userId], set: { leftAt: null, joinedAt: new Date() } });
  publish(
    existing.map((p) => p.id).filter((id) => id !== userId),
    { type: "call-joined", callId, userId, name },
  );
  return existing.filter((p) => p.id !== userId);
}

export async function leaveCall(callId: string, userId: string) {
  await db
    .update(callParticipants)
    .set({ leftAt: new Date() })
    .where(and(eq(callParticipants.callId, callId), eq(callParticipants.userId, userId), isNull(callParticipants.leftAt)));
  const rest = await activeParticipants(callId);
  const [call] = await db.select().from(calls).where(eq(calls.id, callId)).limit(1);
  if (!call) return;
  publish(rest.map((p) => p.id), { type: "call-left", callId, userId });
  const members = await memberIds(call.chatId);
  if (rest.length === 0 && !call.endedAt) {
    await db.update(calls).set({ endedAt: new Date() }).where(eq(calls.id, callId));
    publish(members, { type: "call-ended", callId, chatId: call.chatId });
  }
  publish(members, { type: "chats" });
}

export async function endStaleCalls(chatId: string) {
  const open = await db.select().from(calls).where(and(eq(calls.chatId, chatId), isNull(calls.endedAt)));
  for (const c of open) {
    const p = await activeParticipants(c.id);
    if (p.length === 0 || Date.now() - c.startedAt.getTime() > 12 * 3600_000) {
      await db.update(calls).set({ endedAt: new Date() }).where(eq(calls.id, c.id));
    }
  }
}
