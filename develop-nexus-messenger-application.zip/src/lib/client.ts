"use client";

export async function api<T = Record<string, unknown>>(
  path: string,
  opts: { method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(path, {
    method: opts.method ?? (opts.body !== undefined ? "POST" : "GET"),
    headers: opts.body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* empty body */
  }
  if (!res.ok) {
    const msg = (data as { error?: string } | null)?.error ?? "Ошибка запроса";
    throw new Error(msg);
  }
  return data as T;
}

export type Uploaded = { url: string; name: string; size: number; mime: string; kind: "image" | "video" | "audio" | "file" };

export async function uploadFile(file: File, purpose: "avatar" | "attachment" = "attachment"): Promise<Uploaded> {
  const form = new FormData();
  form.append("file", file);
  form.append("purpose", purpose);
  const res = await fetch("/api/upload", { method: "POST", body: form, credentials: "same-origin" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Не удалось загрузить файл");
  return data as Uploaded;
}

export const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });

export function fmtDay(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Сегодня";
  if (d.toDateString() === y.toDateString()) return "Вчера";
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: d.getFullYear() === today.getFullYear() ? undefined : "numeric" });
}

export function fmtShort(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return fmtTime(iso);
  if (today.getTime() - d.getTime() < 6 * 86400_000) return d.toLocaleDateString("ru-RU", { weekday: "short" });
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "2-digit" });
}

export function fmtLastSeen(presence: string, lastSeen: string | null) {
  if (presence === "online") return "в сети";
  if (presence === "away") return "отошёл";
  if (presence === "dnd") return "не беспокоить";
  if (!lastSeen) return "был(а) недавно";
  const d = new Date(lastSeen);
  const diff = Date.now() - d.getTime();
  if (diff < 60_000) return "был(а) только что";
  if (diff < 3600_000) return `был(а) ${Math.floor(diff / 60_000)} мин. назад`;
  if (d.toDateString() === new Date().toDateString()) return `был(а) сегодня в ${fmtTime(lastSeen)}`;
  return `был(а) ${d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} в ${fmtTime(lastSeen)}`;
}

export function fmtSize(n: number | null) {
  if (!n) return "";
  if (n < 1024) return `${n} Б`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} КБ`;
  return `${(n / 1024 / 1024).toFixed(1)} МБ`;
}

export const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🔥"];

export const EMOJI_GROUPS: { name: string; icon: string; items: string[] }[] = [
  { name: "Смайлы", icon: "😀", items: "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕".split(" ") },
  { name: "Жесты", icon: "👍", items: "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤝 🙏 💪 👏 🙌 👐 🤲 ✍️ 🤳 💅 🫶 🫡 🫰".split(" ") },
  { name: "Сердца", icon: "❤️", items: "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💋 🔥 ✨ ⭐ 🌟 💫 💥 💯 ✅ ❌ ⚡".split(" ") },
  { name: "Природа", icon: "🐱", items: "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦄 🐝 🦋 🐢 🐙 🐬 🐳 🌸 🌹 🌻 🌲 🌴 🍀 🌈 ☀️ 🌙 ⛄ 🌊".split(" ") },
  { name: "Еда", icon: "🍕", items: "🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🥕 🌽 🍞 🧀 🍗 🍔 🍟 🍕 🌭 🌮 🍣 🍜 🍰 🎂 🍫 🍩 🍪 🍿 ☕ 🍵 🍺 🍷 🥂 🍹".split(" ") },
  { name: "Активности", icon: "⚽", items: "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎯 🎮 🎲 🎸 🎹 🎧 🎤 🎬 🎨 🏆 🥇 🚀 ✈️ 🚗 🏠 🎉 🎊 🎁 🎈 💡 📱 💻 📷".split(" ") },
];

export const STICKERS = ["😎", "🥳", "😍", "🤩", "😂", "🤣", "😭", "😡", "🤯", "🥺", "😴", "🤔", "🙄", "😱", "🤗", "🫡", "👍", "👏", "🙏", "💪", "🔥", "❤️", "💯", "🎉", "🚀", "☕", "🍕", "🐱", "🐶", "🦄", "🌈", "👋"];

export const ACCENTS: { id: string; color: string; name: string }[] = [
  { id: "violet", color: "#7c5cff", name: "Фиолетовый" },
  { id: "blue", color: "#2f7bff", name: "Синий" },
  { id: "emerald", color: "#10b981", name: "Изумруд" },
  { id: "rose", color: "#f43f7a", name: "Роза" },
  { id: "amber", color: "#f59e0b", name: "Янтарь" },
  { id: "cyan", color: "#06b6d4", name: "Бирюза" },
];

export function applyTheme(a: { theme: string; accent: string; fontSize: string }) {
  const d = document.documentElement;
  let t = a.theme;
  if (t === "system") t = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  d.dataset.theme = t;
  d.dataset.accent = a.accent;
  d.dataset.font = a.fontSize;
  try {
    localStorage.setItem("nexus-theme", a.theme);
    localStorage.setItem("nexus-accent", a.accent);
    localStorage.setItem("nexus-font", a.fontSize);
  } catch {
    /* ignore */
  }
}

let audioCtx: AudioContext | null = null;
export function beep(kind: "message" | "ring" = "message") {
  try {
    audioCtx ??= new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const ctx = audioCtx;
    const notes = kind === "ring" ? [660, 880] : [880, 1175];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.value = f;
      const t = ctx.currentTime + i * 0.12;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.12, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 0.22);
    });
  } catch {
    /* audio not available */
  }
}
